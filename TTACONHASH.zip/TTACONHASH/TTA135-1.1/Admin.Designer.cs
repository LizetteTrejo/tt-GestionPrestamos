﻿using System.Windows.Forms;

namespace UareUSampleCSharp
{
    partial class Admin
    {
        private System.ComponentModel.IContainer components = null;



        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tableAdmins = new System.Windows.Forms.DataGridView();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnBorrarAdmin = new System.Windows.Forms.Button();
            this.btnEditarAdmin = new System.Windows.Forms.Button();
            this.btnNuevoAdmin = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tableAdmins)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(24, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(203, 29);
            this.label3.TabIndex = 0;
            this.label3.Text = "Administradores";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Arial", 14.25F);
            this.textBox1.Location = new System.Drawing.Point(29, 93);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(601, 29);
            this.textBox1.TabIndex = 2;
            // 
            // tableAdmins
            // 
            this.tableAdmins.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.tableAdmins.BackgroundColor = System.Drawing.Color.White;
            this.tableAdmins.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.tableAdmins.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.tableAdmins.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableAdmins.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column5,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column1});
            this.tableAdmins.EnableHeadersVisualStyles = false;
            this.tableAdmins.GridColor = System.Drawing.Color.Black;
            this.tableAdmins.Location = new System.Drawing.Point(29, 140);
            this.tableAdmins.Name = "tableAdmins";
            this.tableAdmins.RowHeadersVisible = false;
            this.tableAdmins.Size = new System.Drawing.Size(703, 288);
            this.tableAdmins.TabIndex = 5;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "ID";
            this.Column5.Name = "Column5";
            // 
            // Column2
            // 
            this.Column2.FillWeight = 89.54315F;
            this.Column2.HeaderText = "Nombre";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.FillWeight = 89.54315F;
            this.Column3.HeaderText = "A. Paterno";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.FillWeight = 89.54315F;
            this.Column4.HeaderText = "A. Materno";
            this.Column4.Name = "Column4";
            // 
            // Column1
            // 
            this.Column1.FillWeight = 89.54315F;
            this.Column1.HeaderText = "Teléfono";
            this.Column1.Name = "Column1";
            // 
            // btnBorrarAdmin
            // 
            this.btnBorrarAdmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnBorrarAdmin.FlatAppearance.BorderSize = 0;
            this.btnBorrarAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBorrarAdmin.Font = new System.Drawing.Font("Arial", 14.25F);
            this.btnBorrarAdmin.ForeColor = System.Drawing.Color.White;
            this.btnBorrarAdmin.Location = new System.Drawing.Point(512, 450);
            this.btnBorrarAdmin.Name = "btnBorrarAdmin";
            this.btnBorrarAdmin.Size = new System.Drawing.Size(96, 29);
            this.btnBorrarAdmin.TabIndex = 10;
            this.btnBorrarAdmin.Text = "Borrar";
            this.btnBorrarAdmin.UseVisualStyleBackColor = false;
            this.btnBorrarAdmin.Click += new System.EventHandler(this.btnBorrarAdmin_Click);
            // 
            // btnEditarAdmin
            // 
            this.btnEditarAdmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnEditarAdmin.FlatAppearance.BorderSize = 0;
            this.btnEditarAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditarAdmin.Font = new System.Drawing.Font("Arial", 14.25F);
            this.btnEditarAdmin.ForeColor = System.Drawing.Color.White;
            this.btnEditarAdmin.Location = new System.Drawing.Point(382, 450);
            this.btnEditarAdmin.Name = "btnEditarAdmin";
            this.btnEditarAdmin.Size = new System.Drawing.Size(96, 29);
            this.btnEditarAdmin.TabIndex = 9;
            this.btnEditarAdmin.Text = "Editar";
            this.btnEditarAdmin.UseVisualStyleBackColor = false;
            this.btnEditarAdmin.Click += new System.EventHandler(this.btnEditarAdmin_Click);
            // 
            // btnNuevoAdmin
            // 
            this.btnNuevoAdmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnNuevoAdmin.FlatAppearance.BorderSize = 0;
            this.btnNuevoAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNuevoAdmin.Font = new System.Drawing.Font("Arial", 14.25F);
            this.btnNuevoAdmin.ForeColor = System.Drawing.Color.White;
            this.btnNuevoAdmin.Location = new System.Drawing.Point(254, 450);
            this.btnNuevoAdmin.Name = "btnNuevoAdmin";
            this.btnNuevoAdmin.Size = new System.Drawing.Size(96, 29);
            this.btnNuevoAdmin.TabIndex = 8;
            this.btnNuevoAdmin.Text = "Nuevo";
            this.btnNuevoAdmin.UseVisualStyleBackColor = false;
            this.btnNuevoAdmin.Click += new System.EventHandler(this.btnNuevoAdmin_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnSalir.FlatAppearance.BorderSize = 0;
            this.btnSalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalir.Font = new System.Drawing.Font("Arial", 14.25F);
            this.btnSalir.ForeColor = System.Drawing.Color.White;
            this.btnSalir.Location = new System.Drawing.Point(636, 450);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(96, 29);
            this.btnSalir.TabIndex = 11;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = false;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // Admin
            // 
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(754, 491);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnBorrarAdmin);
            this.Controls.Add(this.btnEditarAdmin);
            this.Controls.Add(this.btnNuevoAdmin);
            this.Controls.Add(this.tableAdmins);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label3);
            this.MaximumSize = new System.Drawing.Size(770, 530);
            this.MinimumSize = new System.Drawing.Size(770, 530);
            this.Name = "Admin";
            ((System.ComponentModel.ISupportInitialize)(this.tableAdmins)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Button button1;
        private TextBox textBox1;
        private DataGridView tableAdmins;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column1;
        private Button btnBorrarAdmin;
        private Button btnEditarAdmin;
        private Button btnNuevoAdmin;
        private Button btnSalir;
    }
}
