﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using LectorPrueba.MySQL;
using MySql.Data.MySqlClient;

namespace UareUSampleCSharp
{
    public partial class Prestamos : Form
    {
        private Form_Main _formMain;

        private string boletaAlumno = null;
        private string nombreAlumno = null;
        private Conexion conexionBD = new Conexion();

        private DataTable dtRecursos = new DataTable();

        private long cmdLastId(MySqlConnection conn)
        {
            using (var cmd = new MySqlCommand("SELECT LAST_INSERT_ID();", conn))
            {
                return Convert.ToInt64(cmd.ExecuteScalar());
            }
        }

        public Prestamos(Form_Main formMain)
        {
            InitializeComponent();
            _formMain = formMain;
            DatosAlumno.Text = "";
            this.Load += Prestamos_Load;
            monthCalendar1.DateSelected += monthCalendar1_DateSelected;
            tablaRecursos.SelectionChanged += tablaRecursos_SelectionChanged;
            txtBuscar.TextChanged += txtBuscar_TextChanged;
        }


        private void Prestamos_Load(object sender, EventArgs e)
        {
            // Configurar calendario
            monthCalendar1.FirstDayOfWeek = Day.Monday;
            monthCalendar1.MaxSelectionCount = 1;
            monthCalendar1.MinDate = DateTime.Today.AddDays(1);
            monthCalendar1.MaxDate = DateTime.Today.AddMonths(3);
            monthCalendar1.SetDate(DateTime.Today.AddDays(1));

            // Ocultar etiquetas al inicio
            lblFechaInicio.Visible = false;
            lblFechaFinal.Visible = false;
            lblDiasTotales.Visible = false;

            // Configurar ComboBox
            cmbTipoRecurso.Items.Clear();
            cmbTipoRecurso.Items.Add("Libro");
            cmbTipoRecurso.Items.Add("Material");
            cmbTipoRecurso.SelectedIndex = 0;
            cmbTipoRecurso.SelectedIndexChanged += cmbTipoRecurso_SelectedIndexChanged;

            // Configurar tablaRecursos
            tablaRecursos.RowHeadersVisible = false;
            tablaRecursos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            tablaRecursos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tablaRecursos.MultiSelect = false;
            tablaRecursos.ReadOnly = true;
            tablaRecursos.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12F, FontStyle.Bold);
            tablaRecursos.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(14, 150, 218);
            tablaRecursos.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            tablaRecursos.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tablaRecursos.EnableHeadersVisualStyles = false;
            tablaRecursos.DefaultCellStyle.Font = new Font("Arial", 11F, FontStyle.Regular);
            tablaRecursos.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tablaRecursos.RowTemplate.Height = 28;
            tablaRecursos.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            tablaRecursos.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 240, 240);
            tablaRecursos.AlternatingRowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Label selección inicial vacía
            lblSeleccionRecurso.Text = "";

            // Cargar libros al iniciar
            CargarLibros();
        }

        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {
            DateTime seleccion = monthCalendar1.SelectionStart;

            if (seleccion.DayOfWeek == DayOfWeek.Saturday || seleccion.DayOfWeek == DayOfWeek.Sunday)
            {
                MessageBox.Show("🚫 No se permiten préstamos en sábado o domingo. Selecciona un día hábil.",
                    "Día inhábil", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                monthCalendar1.SetDate(DateTime.Today.AddDays(1));
                return;
            }

            ActualizarFechas();
        }

        private void ActualizarFechas()
        {
            DateTime hoy = DateTime.Today;
            DateTime devolucion = monthCalendar1.SelectionStart;
            int dias = (devolucion - hoy).Days;

            lblFechaInicio.Text = "Fecha inicio: " + hoy.ToShortDateString();
            lblFechaFinal.Text = "Fecha final: " + devolucion.ToShortDateString();
            lblDiasTotales.Text = "Días totales: " + dias;

            lblFechaInicio.Visible = true;
            lblFechaFinal.Visible = true;
            lblDiasTotales.Visible = true;
        }

        private void cmbTipoRecurso_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbTipoRecurso.SelectedItem.ToString() == "Libro")
                CargarLibros();
            else
                CargarMateriales();
        }

        private void CargarLibros()
        {
            try
            {
                using (var conn = conexionBD.Conectar())
                {
                    string query = "SELECT ISBN, Titulo, Autor, Clasificacion, Stock FROM libro";
                    using (var adapter = new MySqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable(); // Usar un DataTable temporal
                        adapter.Fill(dt);
                        tablaRecursos.Columns.Clear(); // Limpiar columnas anteriores
                        dtRecursos = dt; // Actualizar el global para filtros
                        tablaRecursos.DataSource = dtRecursos;
                        // Ajuste de tamaño personalizado para columnas
                        if (tablaRecursos.Columns.Contains("Titulo"))
                            tablaRecursos.Columns["Titulo"].Width = 200;

                        if (tablaRecursos.Columns.Contains("Autor"))
                            tablaRecursos.Columns["Autor"].Width = 150;

                        if (tablaRecursos.Columns.Contains("Stock"))
                            tablaRecursos.Columns["Stock"].Width = 60;

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar libros: " + ex.Message);
            }
        }


        private void CargarMateriales()
        {
            try
            {
                using (var conn = conexionBD.Conectar())
                {
                    string query = "SELECT ID, Nombre, Estado, Marca, Categoria, Stock FROM material";

                    using (var adapter = new MySqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable(); // Usar DataTable local
                        adapter.Fill(dt);
                        tablaRecursos.Columns.Clear(); // Limpiar columnas anteriores
                        dtRecursos = dt; // Asignar al global
                        tablaRecursos.DataSource = dtRecursos;
                        // Ajuste de ancho para columnas de Material
                        if (tablaRecursos.Columns.Contains("Nombre"))
                            tablaRecursos.Columns["Nombre"].Width = 200;
                        if (tablaRecursos.Columns.Contains("ID"))
                            tablaRecursos.Columns["ID"].Width = 100;
                        if (tablaRecursos.Columns.Contains("Stock"))
                            tablaRecursos.Columns["Stock"].Width = 80;


                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar materiales: " + ex.Message);
            }
        }


        private void tablaRecursos_SelectionChanged(object sender, EventArgs e)
        {
            if (tablaRecursos.SelectedRows.Count > 0)
            {
                var fila = tablaRecursos.SelectedRows[0];
                string valor = "";

                if (tablaRecursos.Columns.Contains("Titulo"))
                {
                    valor = fila.Cells["Titulo"].Value?.ToString();
                }
                else if (tablaRecursos.Columns.Contains("Nombre"))
                {
                    valor = fila.Cells["Nombre"].Value?.ToString();
                }

                lblSeleccionRecurso.Text = $"Seleccionado: {valor}";
            }
        }


        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            string filtro = txtBuscar.Text.Trim().Replace("'", "''");

            if (dtRecursos != null)
            {
                DataView dv = new DataView(dtRecursos);
                string campo = cmbTipoRecurso.SelectedItem.ToString() == "Libro" ? "Titulo" : "Nombre";
                dv.RowFilter = $"{campo} LIKE '%{filtro}%'";
                tablaRecursos.DataSource = dv;
            }
        }

        private void btnPrestamo_Click(object sender, EventArgs e)
        {
            if (_formMain.CurrentReader == null)
            {
                MessageBox.Show("🖐️ Primero debes seleccionar un lector de huellas.", "Lector no seleccionado",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (boletaAlumno == null)
            {
                MessageBox.Show("🔒 Debes verificar la huella del alumno antes de registrar un préstamo.",
                    "Huella no verificada", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (tablaRecursos.SelectedRows.Count == 0)
            {
                MessageBox.Show("📦 Selecciona un recurso para prestar.", "Recurso no seleccionado",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DateTime hoy = DateTime.Today;
            DateTime devolucion = monthCalendar1.SelectionStart;
            string tipoRecurso = cmbTipoRecurso.SelectedItem.ToString();

            using (var conn = conexionBD.Conectar())
            {
                if (!int.TryParse(_formMain.IDAdmin, out int idAdministrador))
                {
                    MessageBox.Show("❌ No se pudo obtener el ID del administrador.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                string consultaMultas = "SELECT COUNT(*) FROM multa m JOIN prestamo p ON m.ID_Prestamo = p.ID_Prestamo WHERE p.Boleta = @boleta AND m.Estado = 'Pendiente'";
                using (var cmdMulta = new MySqlCommand(consultaMultas, conn))
                {
                    cmdMulta.Parameters.AddWithValue("@boleta", boletaAlumno);
                    int multasPendientes = Convert.ToInt32(cmdMulta.ExecuteScalar());

                    if (multasPendientes > 0)
                    {
                        MessageBox.Show("❌ No puedes realizar un préstamo. Tienes multas pendientes.",
                                        "Acceso denegado", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }


                // 1. Insertar en `prestamo`
                string insertarPrestamo = @"INSERT INTO prestamo (Boleta, ID_Administrador, Fecha_Prestamo, Fecha_Devolucion, Estado) 
                                    VALUES (@boleta, @admin, @fprestamo, @fdevolucion, @estado)";
                using (var cmd = new MySqlCommand(insertarPrestamo, conn))
                {
                    cmd.Parameters.AddWithValue("@boleta", boletaAlumno);
                    cmd.Parameters.AddWithValue("@admin", idAdministrador);
                    cmd.Parameters.AddWithValue("@fprestamo", hoy);
                    cmd.Parameters.AddWithValue("@fdevolucion", devolucion);
                    cmd.Parameters.AddWithValue("@estado", "Activo");
                    cmd.ExecuteNonQuery();
                }

                // 2. Obtener el ID_Prestamo generado
                long idPrestamo = cmdLastId(conn);

                // 3. Tipo: Libro
                if (tipoRecurso == "Libro")
                {
                    string isbn = tablaRecursos.SelectedRows[0].Cells["ISBN"].Value.ToString();

                    // Verificar stock
                    string verificarStock = "SELECT Stock FROM libro WHERE ISBN = @isbn";
                    int stockDisponible = 0;
                    using (var cmdStock = new MySqlCommand(verificarStock, conn))
                    {
                        cmdStock.Parameters.AddWithValue("@isbn", isbn);
                        object result = cmdStock.ExecuteScalar();

                        if (result == null || !int.TryParse(result.ToString(), out stockDisponible))
                        {
                            MessageBox.Show("⚠️ No se pudo obtener el stock del libro.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        if (stockDisponible <= 0)
                        {
                            MessageBox.Show("❌ Este libro no tiene stock disponible actualmente. Espera a que sea devuelto.",
                                "Sin stock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        if (stockDisponible <= 2)
                        {
                            MessageBox.Show($"⚠️ Solo quedan {stockDisponible} unidades de este libro.",
                                "Stock limitado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }

                    // Insertar en tabla puente
                    string insertarPL = "INSERT INTO prestamo_libro (ID_Prestamo, ISBN) VALUES (@id, @isbn)";
                    using (var cmdLibro = new MySqlCommand(insertarPL, conn))
                    {
                        cmdLibro.Parameters.AddWithValue("@id", idPrestamo);
                        cmdLibro.Parameters.AddWithValue("@isbn", isbn);
                        cmdLibro.ExecuteNonQuery();
                    }

                    // Descontar stock
                    string actualizarStock = "UPDATE libro SET Stock = Stock - 1 WHERE ISBN = @isbn";
                    using (var cmdUpdate = new MySqlCommand(actualizarStock, conn))
                    {
                        cmdUpdate.Parameters.AddWithValue("@isbn", isbn);
                        cmdUpdate.ExecuteNonQuery();
                    }

                    CargarLibros();
                }
                else // Tipo: Material
                {
                    int idMaterial = Convert.ToInt32(tablaRecursos.SelectedRows[0].Cells["ID"].Value);
                    int stockDisponible = 0;

                    // Verificar stock
                    string verificarStock = "SELECT Stock FROM material WHERE ID = @idmat";
                    using (var cmdStock = new MySqlCommand(verificarStock, conn))
                    {
                        cmdStock.Parameters.AddWithValue("@idmat", idMaterial);
                        object result = cmdStock.ExecuteScalar();

                        if (result == null || !int.TryParse(result.ToString(), out stockDisponible))
                        {
                            MessageBox.Show("⚠️ No se pudo obtener el stock del material.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        if (stockDisponible <= 0)
                        {
                            MessageBox.Show("❌ Este material no tiene stock disponible actualmente. Espera a que sea devuelto.",
                                "Sin stock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        if (stockDisponible <= 2)
                        {
                            MessageBox.Show($"⚠️ Solo quedan {stockDisponible} unidades de este material.",
                                "Stock limitado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }

                    // Insertar en tabla puente
                    string insertarPM = "INSERT INTO prestamo_material (ID_Prestamo, ID_Material) VALUES (@id, @idmat)";
                    using (var cmdMat = new MySqlCommand(insertarPM, conn))
                    {
                        cmdMat.Parameters.AddWithValue("@id", idPrestamo);
                        cmdMat.Parameters.AddWithValue("@idmat", idMaterial);
                        cmdMat.ExecuteNonQuery();
                    }

                    // Descontar stock
                    string descontarStock = "UPDATE material SET Stock = Stock - 1 WHERE ID = @idmat";
                    using (var cmdDesc = new MySqlCommand(descontarStock, conn))
                    {
                        cmdDesc.Parameters.AddWithValue("@idmat", idMaterial);
                        cmdDesc.ExecuteNonQuery();
                    }

                    CargarMateriales();
                }
            }

            MessageBox.Show("✅ Préstamo registrado correctamente.", "Confirmación",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Limpiar campos
            boletaAlumno = null;
            nombreAlumno = null;
            DatosAlumno.Text = "";
            lblSeleccionRecurso.Text = "";
            tablaRecursos.ClearSelection();

            // Reiniciar fechas y etiquetas
            monthCalendar1.SetDate(DateTime.Today.AddDays(1));
            lblFechaInicio.Visible = false;
            lblFechaFinal.Visible = false;
            lblDiasTotales.Visible = false;
        }






        private void btnHuella_Click(object sender, EventArgs e)
        {
            if (_formMain.CurrentReader == null)
            {
                MessageBox.Show(
                "🖐️ Primero debes seleccionar un lector de huellas desde la configuración.",
                "Lector no seleccionado",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning

            );
                return;
            }

            Verification verificacion = new Verification();
            verificacion._sender = _formMain;

            if (verificacion.ShowDialog() == DialogResult.OK)
            {
                boletaAlumno = verificacion.BoletaVerificada;
                // Obtener datos del alumno
                using (var conn = conexionBD.Conectar())
                {
                    string query = "SELECT Nombre, A_Paterno, A_Materno FROM alumno WHERE Boleta = @boleta";
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@boleta", boletaAlumno);
                        using (var reader = cmd.ExecuteReader())
                        {
                                reader.Read();
                            
                                string nombre = reader["Nombre"].ToString();
                                string apaterno = reader["A_Paterno"].ToString();
                                string amaterno = reader["A_Materno"].ToString();

                                nombreAlumno = $"{nombre} {apaterno} {amaterno}";

                                // Mostrar en label DatosAlumno
                                DatosAlumno.Text = $"📌 Boleta: {boletaAlumno}\n👤 {nombreAlumno}";
                                DatosAlumno.Visible = true;
                            
                          
                        }
                    }
                }
            }
        }

        private void btnContra_Click(object sender, EventArgs e)
        {
            using (var form = new VerificationContra())
            {
                var result = form.ShowDialog();

                if (result == DialogResult.OK)
                {
                    boletaAlumno = form.Boleta;
                    nombreAlumno = form.NombreCompleto;

                    DatosAlumno.Text = $"📌 Boleta: {boletaAlumno}\n👤 {nombreAlumno}";
                    DatosAlumno.Visible = true;

                    MessageBox.Show("✅ Contraseña verificada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}
