﻿using System;
using System.Text;
using System.Windows.Forms;
using DPUruNet;
using MySql.Data.MySqlClient;

namespace UareUSampleCSharp
{
    public partial class Config : Form
    {
        public Form_Main _sender;
        private Fmd huellaCapturada;

        public Config()
        {
            InitializeComponent();
            this.TopLevel = false;
            this.FormBorderStyle = FormBorderStyle.None;
            this.Dock = DockStyle.Fill;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Config_Load(object sender, EventArgs e)
        {

        }
    }
}