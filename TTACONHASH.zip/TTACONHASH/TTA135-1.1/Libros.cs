﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using LectorPrueba.MySQL;
using MySql.Data.MySqlClient;

namespace UareUSampleCSharp
{
    public partial class Libros : Form
    {
        public Form_Main _sender;
        private Conexion conexionBD = new Conexion();

        public Libros()
        {
            InitializeComponent();
            this.Load += new EventHandler(Libros_Load);

            // Configuración general
            tableLibros.RowHeadersVisible = false; // Oculta columna gris
            tableLibros.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; // Columnas se ajustan
            tableLibros.SelectionMode = DataGridViewSelectionMode.FullRowSelect; // Selección de fila completa
            tableLibros.MultiSelect = false; // No permite múltiples filas seleccionadas
            tableLibros.ReadOnly = true; // Solo lectura

            // Estilo de encabezados
            tableLibros.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12F, FontStyle.Bold);
            tableLibros.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(14, 150, 218);
            tableLibros.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            tableLibros.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tableLibros.EnableHeadersVisualStyles = false; // Permite aplicar estilos personalizados

            // Estilo de celdas normales
            tableLibros.DefaultCellStyle.Font = new Font("Arial", 11F, FontStyle.Regular);
            tableLibros.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Estilo de filas
            tableLibros.RowTemplate.Height = 28; // Altura uniforme
            tableLibros.CellBorderStyle = DataGridViewCellBorderStyle.None; // ❌ Sin líneas entre filas

            // Estilo de filas alternadas (zebra)
            tableLibros.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 240, 240);
            tableLibros.AlternatingRowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;



        }


        private void txtNombreLibro_TextChanged(object sender, EventArgs e)
        {
            FiltrarLibros(txtNombreLibro.Text);
        }

        private void btnNuevoLibro_Click(object sender, EventArgs e)
        {
            RegistroLibros frm = new RegistroLibros(this);
            frm.Show();
        }


        private void btnEditarLibro_Click(object sender, EventArgs e)
        {
            if (tableLibros.CurrentRow == null || tableLibros.CurrentRow.Index < 0)
            {
                MessageBox.Show("Selecciona un libro de la tabla.");
                return;
            }

            string isbn = tableLibros.CurrentRow.Cells["ISBN"].Value.ToString();

            RegistroLibros frm = new RegistroLibros(this, isbn); // modo edición
            frm.Show();
        }


        private void btnBorrarLibro_Click(object sender, EventArgs e)
        {
            if (tableLibros.CurrentRow == null || tableLibros.CurrentRow.Index < 0)
            {
                MessageBox.Show("Selecciona un libro de la tabla.");
                return;
            }

            string isbn = tableLibros.CurrentRow.Cells["ISBN"].Value.ToString();
            string titulo = tableLibros.CurrentRow.Cells["Titulo"].Value.ToString();

            DialogResult result = MessageBox.Show(
                $"¿Deseas borrar el libro:\n\n\"{titulo}\" (ISBN: {isbn})?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result == DialogResult.No) return;

            try
            {
                using (var conn = conexionBD.Conectar())
                {
                    string query = "DELETE FROM libro WHERE ISBN = @isbn";
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@isbn", isbn);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Libro eliminado correctamente.");
                CargarLibros();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar el libro: " + ex.Message);
            }
        }

        private void Libros_Load(object sender, EventArgs e)
        {
            CargarLibros();
            tableLibros.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

        }
        public void CargarLibros()
        {
            try
            {
                using (var conn = conexionBD.Conectar())
                {
                    string query = "SELECT ISBN, Titulo, Autor, Año, Clasificacion, Stock FROM libro";
                    MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    tableLibros.DataSource = null;
                    tableLibros.Columns.Clear();
                    tableLibros.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar libros: " + ex.Message);
            }
            tableLibros.Columns[0].Width = 120;
            tableLibros.Columns[1].Width = 220;
            tableLibros.Columns[2].Width = 110;
            tableLibros.Columns[3].Width = 50;
            tableLibros.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            tableLibros.Columns[4].Width = 80;
            tableLibros.Columns[4].HeaderCell.Style.Font = new Font("Arial", 9, FontStyle.Bold);
            tableLibros.Columns[4].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tableLibros.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            tableLibros.Columns[5].Width = 55;
            tableLibros.Columns[5].HeaderCell.Style.Font = new Font("Arial", 10, FontStyle.Bold);
            tableLibros.Columns[5].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tableLibros.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

        }
        private void FiltrarLibros(string texto)
        {
            try
            {
                using (var conn = conexionBD.Conectar())
                {
                    string query = @"SELECT ISBN, Titulo, Autor, Año, Clasificacion, Stock
                             FROM libro
                             WHERE Titulo LIKE @texto OR Autor LIKE @texto OR Clasificacion LIKE @texto";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@texto", "%" + texto + "%");
                        MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        tableLibros.DataSource = null;
                        tableLibros.Columns.Clear();
                        tableLibros.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al filtrar libros: " + ex.Message);
            }
            tableLibros.Columns[0].Width = 120;
            tableLibros.Columns[1].Width = 220;
            tableLibros.Columns[2].Width = 110;
            tableLibros.Columns[3].Width = 50;
            tableLibros.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            tableLibros.Columns[4].Width = 80;
            tableLibros.Columns[4].HeaderCell.Style.Font = new Font("Arial", 9, FontStyle.Bold);
            tableLibros.Columns[4].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tableLibros.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            tableLibros.Columns[5].Width = 55;
            tableLibros.Columns[5].HeaderCell.Style.Font = new Font("Arial", 10, FontStyle.Bold);
            tableLibros.Columns[5].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tableLibros.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void Libros_Load_1(object sender, EventArgs e)
        {

        }

        private void tableLibros_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}