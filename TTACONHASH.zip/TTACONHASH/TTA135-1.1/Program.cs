﻿using System;
using System.Windows.Forms;

namespace UareUSampleCSharp
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
#if (!WindowsCE)
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
#endif

            // Ejecuta directamente Form_Main con datos de ejemplo
            Application.Run(new Form_Main("1", "Administrador"));
        }
    }
}
