﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using LectorPrueba.MySQL;
using System.Security.Cryptography;
using System.Text;

namespace UareUSampleCSharp
{
    public partial class RegistroUsuarios : Form
    {
        public Form_Main _sender;
        private Usuarios _formUsuarios;
        private Conexion conexionBD = new Conexion();

        private string boletaEdicion = null;
        private bool esEdicion => boletaEdicion != null;

        public RegistroUsuarios(Form_Main sender, Usuarios formUsuarios)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            _sender = sender;
            _formUsuarios = formUsuarios;
        }

        public RegistroUsuarios(Form_Main sender, Usuarios formUsuarios, string boleta)
            : this(sender, formUsuarios)
        {
            boletaEdicion = boleta;
        }

        private void RegistroUsuarios_Load(object sender, EventArgs e)
        {
            if (esEdicion)
            {
                CargarDatosAlumno();
                txtBoleta.ReadOnly = true;
                btnRegistrar.Text = "Guardar Cambios";
            }
        }

        private void CargarDatosAlumno()
        {
            using (var conn = conexionBD.Conectar())
            {
                string query = "SELECT * FROM alumno WHERE Boleta = @boleta";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@boleta", boletaEdicion);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtBoleta.Text = reader["Boleta"].ToString();
                            txtNombre.Text = reader["Nombre"].ToString();
                            txtAPaterno.Text = reader["A_Paterno"].ToString();
                            txtAMaterno.Text = reader["A_Materno"].ToString();
                            txtTelefono.Text = reader["Telefono"].ToString();
                            // No se carga la contraseña por seguridad
                        }
                    }
                }
            }
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBoleta.Text) ||
                string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtAPaterno.Text) ||
                string.IsNullOrWhiteSpace(txtAMaterno.Text) ||
                string.IsNullOrWhiteSpace(txtTelefono.Text) ||
                string.IsNullOrWhiteSpace(txtPassword.Text) ||
                string.IsNullOrWhiteSpace(txtConfirmPassword.Text))
            {
                MessageBox.Show("Por favor llena todos los campos.");
                return;
            }

            if (!int.TryParse(txtBoleta.Text.Trim(), out int _))
            {
                MessageBox.Show("La boleta debe ser un número válido.");
                return;
            }

            if (txtPassword.Text != txtConfirmPassword.Text)
            {
                MessageBox.Show("Las contraseñas no coinciden.");
                return;
            }

            string boleta = txtBoleta.Text.Trim();
            string nombre = txtNombre.Text.Trim();
            string apaterno = txtAPaterno.Text.Trim();
            string amaterno = txtAMaterno.Text.Trim();
            string telefono = txtTelefono.Text.Trim();
            string password = Encrypt.GetSHA256(txtPassword.Text.Trim());


            using (var conn = conexionBD.Conectar())
            {
                if (esEdicion)
                {
                    DialogResult result = MessageBox.Show(
                        "¿Deseas guardar los cambios del alumno?",
                        "Confirmar actualización",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question
                    );

                    if (result == DialogResult.No)
                        return;

                    string updateQuery = @"UPDATE alumno 
                        SET Nombre = @nombre, A_Paterno = @apaterno, A_Materno = @amaterno, 
                            Telefono = @telefono, Pswrd = @password
                        WHERE Boleta = @boleta";

                    using (var cmd = new MySqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@boleta", boleta);
                        cmd.Parameters.AddWithValue("@nombre", nombre);
                        cmd.Parameters.AddWithValue("@apaterno", apaterno);
                        cmd.Parameters.AddWithValue("@amaterno", amaterno);
                        cmd.Parameters.AddWithValue("@telefono", telefono);
                        cmd.Parameters.AddWithValue("@password", password);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Alumno actualizado correctamente.");
                }
                else
                {
                    string verificarQuery = "SELECT COUNT(*) FROM alumno WHERE Boleta = @boleta";
                    using (var verificarCmd = new MySqlCommand(verificarQuery, conn))
                    {
                        verificarCmd.Parameters.AddWithValue("@boleta", boleta);
                        int count = Convert.ToInt32(verificarCmd.ExecuteScalar());
                        if (count > 0)
                        {
                            MessageBox.Show("Ya existe un alumno con esa boleta.");
                            txtBoleta.Clear();
                            return;
                        }
                    }

                    string insertQuery = @"INSERT INTO alumno 
                        (Boleta, Nombre, A_Paterno, A_Materno, Telefono, Pswrd)
                        VALUES (@boleta, @nombre, @apaterno, @amaterno, @telefono, @password)";

                    using (var cmd = new MySqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@boleta", boleta);
                        cmd.Parameters.AddWithValue("@nombre", nombre);
                        cmd.Parameters.AddWithValue("@apaterno", apaterno);
                        cmd.Parameters.AddWithValue("@amaterno", amaterno);
                        cmd.Parameters.AddWithValue("@telefono", telefono);
                        cmd.Parameters.AddWithValue("@password", password);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Alumno registrado correctamente.");
                }
            }

            LimpiarCampos();
            _formUsuarios.RecargarUsuarios();
            this.Hide();
            _formUsuarios.Show();
        }

        private void LimpiarCampos()
        {
            txtBoleta.Clear();
            txtNombre.Clear();
            txtAPaterno.Clear();
            txtAMaterno.Clear();
            txtTelefono.Clear();
            txtPassword.Clear();
            txtConfirmPassword.Clear();
        }

        private void RegistroUsuarios_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        public class Encrypt
        {
            public static string GetSHA256(string str)
            {
                SHA256 sha256 = SHA256Managed.Create();
                ASCIIEncoding encoding = new ASCIIEncoding();
                byte[] stream = sha256.ComputeHash(encoding.GetBytes(str));
                StringBuilder sb = new StringBuilder();
                foreach (byte b in stream)
                    sb.AppendFormat("{0:x2}", b);
                return sb.ToString();
            }
        }
    }
}
