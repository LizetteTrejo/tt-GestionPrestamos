﻿using System;
using System.IO;
using System.Windows.Forms;

namespace UareUSampleCSharp
{
    public partial class AvisoPrivacidadForm : Form
    {
        public AvisoPrivacidadForm()
        {
            InitializeComponent();
            CargarAvisoPrivacidad();
        }

        private void CargarAvisoPrivacidad()
        {
            try
            {
                string rutaAviso = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "aviso_privacidad.rtf");
                if (File.Exists(rutaAviso))
                {
                    richAviso.LoadFile(rutaAviso);
                }
                else
                {
                    MessageBox.Show("No se encontró el archivo de aviso de privacidad.", "Archivo no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar el aviso de privacidad:\n\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

    }
}
