﻿using System;
using System.Data;
using System.Drawing;
using System.Reflection.Emit;
using System.Windows.Forms;
using LectorPrueba.MySQL;
using MySql.Data.MySqlClient;

namespace UareUSampleCSharp
{
    public partial class RegistroLibros : Form
    {
        private Libros _formPadre;
        private string isbnEdicion = null;
        private Conexion conexionBD = new Conexion();

        private bool esEdicion => isbnEdicion != null;

        public RegistroLibros(Libros padre)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;


            _formPadre = padre;
        }

        // Constructor para modo edición
        public RegistroLibros(Libros padre, string isbn)
            : this(padre)
        {
            isbnEdicion = isbn;
        }

        private void RegistroLibros_Load(object sender, EventArgs e)
        {
            if (esEdicion)
            {
                this.Text = "Editar Libro";
                btnGuardar.Text = "Guardar Cambios";
                txtISBN.ReadOnly = true;
                CargarDatosLibro();
            }
            else
            {
                this.Text = "Registrar Libro";
                btnGuardar.Text = "Registrar";
            }
        }

        private void CargarDatosLibro()
        {
            using (var conn = conexionBD.Conectar())
            {
                string query = "SELECT * FROM libro WHERE ISBN = @isbn";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@isbn", isbnEdicion);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtISBN.Text = reader["ISBN"].ToString();
                            txtTitulo.Text = reader["Titulo"].ToString();
                            txtAutor.Text = reader["Autor"].ToString();
                            txtAnio.Text = reader["Año"].ToString();
                            txtClasificacion.Text = reader["Clasificacion"].ToString();
                            txtStock.Text = reader["Stock"].ToString();
                        }
                    }
                }
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtISBN.Text) ||
                string.IsNullOrWhiteSpace(txtTitulo.Text) ||
                string.IsNullOrWhiteSpace(txtAutor.Text) ||
                string.IsNullOrWhiteSpace(txtAnio.Text) ||
                string.IsNullOrWhiteSpace(txtClasificacion.Text) ||
                string.IsNullOrWhiteSpace(txtStock.Text))
            {
                MessageBox.Show("Por favor llena todos los campos.");
                return;
            }

            if (!int.TryParse(txtAnio.Text, out int anio) || !int.TryParse(txtStock.Text, out int stock))
            {
                MessageBox.Show("Año y Stock deben ser numéricos.");
                return;
            }

            using (var conn = conexionBD.Conectar())
            {

                if (esEdicion)
                {
                    DialogResult result = MessageBox.Show(
                        "¿Estás seguro de que deseas guardar los cambios?",
                        "Confirmar actualización",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question
                    );

                    if (result == DialogResult.No)
                    {
                        return;
                    }

                    string updateQuery = @"UPDATE libro SET 
                        Titulo = @titulo, Autor = @autor, Año = @anio, 
                        Clasificacion = @clasificacion, Stock = @stock
                        WHERE ISBN = @isbn";

                    using (var cmd = new MySqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@isbn", txtISBN.Text.Trim());
                        cmd.Parameters.AddWithValue("@titulo", txtTitulo.Text.Trim());
                        cmd.Parameters.AddWithValue("@autor", txtAutor.Text.Trim());
                        cmd.Parameters.AddWithValue("@anio", anio);
                        cmd.Parameters.AddWithValue("@clasificacion", txtClasificacion.Text.Trim());
                        cmd.Parameters.AddWithValue("@stock", stock);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("✅ Libro actualizado correctamente.");
                }

                else
                {
                    string verificarQuery = "SELECT COUNT(*) FROM libro WHERE ISBN = @isbn";
                    using (var cmd = new MySqlCommand(verificarQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@isbn", txtISBN.Text.Trim());
                        int count = Convert.ToInt32(cmd.ExecuteScalar());
                        if (count > 0)
                        {
                            MessageBox.Show("Ya existe un libro con ese ISBN.");
                            return;
                        }
                    }

                    string insertQuery = @"INSERT INTO libro 
                        (ISBN, Titulo, Autor, Año, Clasificacion, Stock)
                        VALUES (@isbn, @titulo, @autor, @anio, @clasificacion, @stock)";

                    using (var cmd = new MySqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@isbn", txtISBN.Text.Trim());
                        cmd.Parameters.AddWithValue("@titulo", txtTitulo.Text.Trim());
                        cmd.Parameters.AddWithValue("@autor", txtAutor.Text.Trim());
                        cmd.Parameters.AddWithValue("@anio", anio);
                        cmd.Parameters.AddWithValue("@clasificacion", txtClasificacion.Text.Trim());
                        cmd.Parameters.AddWithValue("@stock", stock);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Libro registrado correctamente.");
                }
            }

            _formPadre?.CargarLibros();
            this.Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
