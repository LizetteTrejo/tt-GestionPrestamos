﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
using MySql.Data.MySqlClient;
using LectorPrueba.MySQL;

using static UareUSampleCSharp.RegistroUsuarios;


namespace UareUSampleCSharp
{
    public partial class VerificationContra : Form

    {
        public string Boleta { get; private set; }
        public string NombreCompleto { get; private set; }

        private Conexion conexionBD = new Conexion();

        public VerificationContra()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;

        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            string contrasena = txtContra.Text.Trim();

            if (string.IsNullOrEmpty(contrasena))
            {
                MessageBox.Show("🔐 Ingresa tu contraseña.", "Campo vacío", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string hash = Encrypt.GetSHA256(txtContra.Text);


            using (var conn = conexionBD.Conectar())
            {
                string query = "SELECT Boleta, Nombre, A_Paterno, A_Materno FROM alumno WHERE Pswrd = @hash";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@hash", hash);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Propiedades públicas para regresar datos
                            Boleta = reader["Boleta"].ToString();
                            string nombre = reader["Nombre"].ToString();
                            string apaterno = reader["A_Paterno"].ToString();
                            string amaterno = reader["A_Materno"].ToString();
                            NombreCompleto = $"{nombre} {apaterno} {amaterno}";

                            DialogResult = DialogResult.OK;
                            Close();
                        }
                        else
                        {
                            MessageBox.Show(" Contraseña incorrecta. Intenta nuevamente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

    }
}
