﻿using System;
using System.Windows.Forms;
namespace UareUSampleCSharp
{
    public partial class Inicio : Form
    {
        public Form_Main _sender;
        public Inicio()
        {
            InitializeComponent();
            this.Load += Inicio_Load;
        }

        private void Inicio_Load(object sender, EventArgs e)
        {
            string texto1 = "Gestión de Préstamos Autenticado mediante Huellas Dactilares\n\n" +
                           "Este sistema ha sido diseñado como una herramienta de apoyo para el control y administración de préstamos y devoluciones de material bibliográfico en la Escuela Superior de Cómputo (ESCOM).\n\n" +
                           "La aplicación permite optimizar los procesos internos de la biblioteca mediante la automatización del registro de usuarios, préstamos y devoluciones, asegurando la autenticidad de los registros ";

            string texto2 = "mediante el uso de tecnología biométrica basada en huellas dactilares.\n\n" +
                           "Con este enfoque, se elimina la necesidad de identificaciones físicas o contraseñas, lo cual mejora significativamente la seguridad, reduce el tiempo de atención al usuario y evita el uso indebido de recursos por parte de personas no autorizadas.\n\n" +
                           "Este sistema está orientado principalmente al personal administrativo de la biblioteca, brindándoles una interfaz intuitiva para realizar operaciones de gestión de materiales, así como un historial detallado de movimientos por usuario.\n\n" +
                           "Además, se contempla la posibilidad de registrar y categorizar diferentes tipos de material (libros, equipos, entre otros), adaptándose a las necesidades específicas de la institución.";


            SetJustifiedText(richTextBox1, texto1);
            SetJustifiedText(richTextBox2, texto2);
        }

        private void SetJustifiedText(RichTextBox rtb, string texto)
        {
            string rtf = @"{\rtf1\ansi\deff0 {\fonttbl{\f0 Arial;}}\viewkind4\uc1\pard\qj\f0\fs28 " +
                         texto.Replace("\n", "\\par ") + "}";
            rtb.Rtf = rtf;
        }


    }
}
