﻿using System;
using System.Windows.Forms;
using DPUruNet;
using MySql.Data.MySqlClient;
using FmdObject = DPUruNet.Fmd;
using FmdFormat = DPUruNet.Constants.Formats.Fmd;
using LectorPrueba.MySQL;

namespace UareUSampleCSharp
{
    public partial class RegistroUsuarios : Form
    {
        public Form_Main _sender;
        private FmdObject huellaCapturada;
        private Usuarios _formUsuarios;
        private const int PROBABILITY_ONE = 0x7FFFFFFF;
        private Conexion conexionBD = new Conexion();


        private string boletaEdicion = null;
        private bool esEdicion => boletaEdicion != null;

        public RegistroUsuarios(Form_Main sender, Usuarios formUsuarios)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            _sender = sender;
            _formUsuarios = formUsuarios;
        }

        public RegistroUsuarios(Form_Main sender, Usuarios formUsuarios, string boleta)
            : this(sender, formUsuarios)
        {
            boletaEdicion = boleta;
        }

        private void RegistroUsuarios_Load(object sender, EventArgs e)
        {
            txtStatus.Text = string.Empty;

            if (_sender == null)
            {
                MessageBox.Show("ERROR: _sender es null.");
                this.Close();
                return;
            }

            if (esEdicion)
            {
                txtStatus.Text = "Huella guardada, lector apagado";
                CargarDatosAlumno();
                txtBoleta.ReadOnly = true;
                btnRegistrar.Text = "Guardar Cambios";
            }
            else
            {
                if (!_sender.OpenReader() || !_sender.StartCaptureAsync(this.OnCaptured))
                {
                    MessageBox.Show("No se pudo abrir el lector.");
                    this.Close();
                    return;
                }

                txtStatus.Text = "Coloca tu dedo en el lector.";
            }
        }

        private void CargarDatosAlumno()
        {
            using (var conn = conexionBD.Conectar())

            {
                string query = "SELECT * FROM alumno WHERE Boleta = @boleta";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@boleta", boletaEdicion);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtBoleta.Text = reader["Boleta"].ToString();
                            txtNombre.Text = reader["Nombre"].ToString();
                            txtAPaterno.Text = reader["A_Paterno"].ToString();
                            txtAMaterno.Text = reader["A_Materno"].ToString();
                            txtTelefono.Text = reader["Telefono"].ToString();
                        }
                    }
                }
            }
        }

        private void OnCaptured(CaptureResult captureResult)
        {
            if (_sender == null || !_sender.CheckCaptureResult(captureResult)) return;

            var result = FeatureExtraction.CreateFmdFromFid(captureResult.Data, FmdFormat.ANSI);

            if (result.ResultCode == Constants.ResultCode.DP_TOO_SMALL_AREA)
            {
                txtStatus.Invoke(new MethodInvoker(delegate
                {
                    txtStatus.Text = "❗ Área muy pequeña. \nReposiciona el dedo e intenta de nuevo.";
                }));
                return;
            }

            if (result.ResultCode != Constants.ResultCode.DP_SUCCESS)
            {
                txtStatus.Invoke(new MethodInvoker(delegate
                {
                    txtStatus.Text = "❌ Error al capturar huella: " + result.ResultCode;
                }));
                return;
            }

            huellaCapturada = result.Data;

            if (huellaCapturada.Bytes == null || huellaCapturada.Bytes.Length < 100)
            {
                txtStatus.Invoke(new MethodInvoker(delegate
                {
                    txtStatus.Text = "⚠️ Huella capturada inválida. \nIntenta de nuevo.";
                }));
                huellaCapturada = null;
                return;
            }

            txtStatus.Invoke(new MethodInvoker(delegate
            {
                txtStatus.Text = "✅ Huella capturada correctamente. \nYa puedes registrar.";
            }));
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBoleta.Text) ||
                string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtAPaterno.Text) ||
                string.IsNullOrWhiteSpace(txtAMaterno.Text) ||
                string.IsNullOrWhiteSpace(txtTelefono.Text))
            {
                MessageBox.Show("Por favor llena todos los campos.");
                return;
            }

            if (!esEdicion && huellaCapturada == null)
            {
                MessageBox.Show("Primero debes capturar una huella válida.");
                return;
            }
            if (!int.TryParse(txtBoleta.Text.Trim(), out int boletaNum))
            {
                MessageBox.Show("La boleta debe ser valida (No debe contener caracteres)");
                return;
            }
            string boleta = txtBoleta.Text.Trim();
            string nombre = txtNombre.Text.Trim();
            string apaterno = txtAPaterno.Text.Trim();
            string amaterno = txtAMaterno.Text.Trim();
            string telefono = txtTelefono.Text.Trim();

            string xmlHuella = huellaCapturada != null ? FmdObject.SerializeXml(huellaCapturada) : string.Empty;
            string formatoHuella = FmdFormat.ANSI.ToString();

            if (!esEdicion && xmlHuella.Length < 400)
            {
                MessageBox.Show("⚠️ La huella es demasiado corta. Captura nuevamente.");
                return;
            }

            using (var conn = conexionBD.Conectar())
            {

                if (esEdicion)
                {
                    DialogResult result = MessageBox.Show(
                        "¿Deseas guardar los cambios del alumno?",
                        "Confirmar actualización",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question
                    );

                    if (result == DialogResult.No)
                        return;

                    string updateQuery = @"UPDATE alumno 
                        SET Nombre = @nombre, A_Paterno = @apaterno, A_Materno = @amaterno, 
                            Telefono = @telefono
                        WHERE Boleta = @boleta";

                    using (var cmd = new MySqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@boleta", boleta);
                        cmd.Parameters.AddWithValue("@nombre", nombre);
                        cmd.Parameters.AddWithValue("@apaterno", apaterno);
                        cmd.Parameters.AddWithValue("@amaterno", amaterno);
                        cmd.Parameters.AddWithValue("@telefono", telefono);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Alumno actualizado correctamente.");
                }

                else
                {
                    string verificarQuery = "SELECT COUNT(*) FROM alumno WHERE Boleta = @boleta";
                    using (var verificarCmd = new MySqlCommand(verificarQuery, conn))
                    {
                        verificarCmd.Parameters.AddWithValue("@boleta", boleta);
                        int count = Convert.ToInt32(verificarCmd.ExecuteScalar());
                        if (count > 0)
                        {
                            MessageBox.Show("Ya existe un alumno con esa boleta.");
                            txtBoleta.Clear();
                            return;
                        }
                    }

                    // Verificar si la huella ya está registrada
                    string selectHuellas = "SELECT Boleta, Huella_Dactilar FROM alumno WHERE Huella_Dactilar IS NOT NULL";
                    using (var verificarHuellaCmd = new MySqlCommand(selectHuellas, conn))
                    using (var reader = verificarHuellaCmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string boletaExistente = reader["Boleta"].ToString();
                            string huellaXML = reader["Huella_Dactilar"].ToString();

                            try
                            {
                                var huellaExistente = FmdObject.DeserializeXml(huellaXML);
                                var resultadoComparacion = Comparison.Compare(huellaCapturada, 0, huellaExistente, 0);

                                if (resultadoComparacion.ResultCode == Constants.ResultCode.DP_SUCCESS &&
                                    resultadoComparacion.Score < (PROBABILITY_ONE / 1000))
                                {
                                    MessageBox.Show($"❌ La huella ya está registrada para la boleta: {boletaExistente}");
                                    txtStatus.Text = "⚠️ Huella capturada ya registrada. \nIntenta de nuevo.";
                                    return;

                                    

                                }
                            }
                            catch
                            {
                                continue;
                            }
                        }
                    }

                    // Registrar alumno
                    string insertQuery = @"INSERT INTO alumno 
                        (Boleta, Nombre, A_Paterno, A_Materno, Telefono, Huella_Dactilar, FormatoHuella)
                        VALUES (@boleta, @nombre, @apaterno, @amaterno, @telefono, @huella, @formato)";

                    using (var cmd = new MySqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@boleta", boleta);
                        cmd.Parameters.AddWithValue("@nombre", nombre);
                        cmd.Parameters.AddWithValue("@apaterno", apaterno);
                        cmd.Parameters.AddWithValue("@amaterno", amaterno);
                        cmd.Parameters.AddWithValue("@telefono", telefono);
                        cmd.Parameters.AddWithValue("@huella", xmlHuella);
                        cmd.Parameters.AddWithValue("@formato", formatoHuella);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Alumno registrado con huella.");
                }
            }

            LimpiarCampos();
            huellaCapturada = null;
            _formUsuarios.RecargarUsuarios();
            this.Close();
        }

        private void LimpiarCampos()
        {
            txtBoleta.Clear();
            txtNombre.Clear();
            txtAPaterno.Clear();
            txtAMaterno.Clear();
            txtTelefono.Clear();
        }

        private void RegistroUsuarios_FormClosed(object sender, FormClosedEventArgs e)
        {
            _sender?.CancelCaptureAndCloseReader(OnCaptured);
        }

    }
}
