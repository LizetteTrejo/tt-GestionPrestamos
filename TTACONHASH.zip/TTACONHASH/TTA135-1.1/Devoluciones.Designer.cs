﻿using System.Windows.Forms;

namespace UareUSampleCSharp
{
    partial class Devoluciones
    {
        private System.ComponentModel.IContainer components = null;



        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.btnHuella = new System.Windows.Forms.Button();
            this.btnDevolver = new System.Windows.Forms.Button();
            this.tablaPrestamos = new System.Windows.Forms.DataGridView();
            this.lblUsuario = new System.Windows.Forms.Label();
            this.btnContra = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tablaPrestamos)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(24, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(169, 29);
            this.label3.TabIndex = 0;
            this.label3.Text = "Devoluciones";
            // 
            // btnHuella
            // 
            this.btnHuella.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnHuella.FlatAppearance.BorderSize = 0;
            this.btnHuella.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHuella.Font = new System.Drawing.Font("Arial", 14.25F);
            this.btnHuella.ForeColor = System.Drawing.Color.White;
            this.btnHuella.Location = new System.Drawing.Point(29, 86);
            this.btnHuella.Name = "btnHuella";
            this.btnHuella.Size = new System.Drawing.Size(206, 32);
            this.btnHuella.TabIndex = 5;
            this.btnHuella.Text = "Solicitar huella dactilar";
            this.btnHuella.UseVisualStyleBackColor = false;
            this.btnHuella.Click += new System.EventHandler(this.btnHuella_Click);
            // 
            // btnDevolver
            // 
            this.btnDevolver.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(111)))), ((int)(((byte)(159)))));
            this.btnDevolver.FlatAppearance.BorderSize = 0;
            this.btnDevolver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDevolver.Font = new System.Drawing.Font("Arial", 14.25F);
            this.btnDevolver.ForeColor = System.Drawing.Color.White;
            this.btnDevolver.Location = new System.Drawing.Point(29, 394);
            this.btnDevolver.Name = "btnDevolver";
            this.btnDevolver.Size = new System.Drawing.Size(206, 32);
            this.btnDevolver.TabIndex = 6;
            this.btnDevolver.Text = "Realizar devolución";
            this.btnDevolver.UseVisualStyleBackColor = false;
            this.btnDevolver.Click += new System.EventHandler(this.btnDevolver_Click);
            // 
            // tablaPrestamos
            // 
            this.tablaPrestamos.BackgroundColor = System.Drawing.Color.White;
            this.tablaPrestamos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tablaPrestamos.GridColor = System.Drawing.Color.White;
            this.tablaPrestamos.Location = new System.Drawing.Point(29, 163);
            this.tablaPrestamos.Name = "tablaPrestamos";
            this.tablaPrestamos.Size = new System.Drawing.Size(698, 184);
            this.tablaPrestamos.TabIndex = 7;
            // 
            // lblUsuario
            // 
            this.lblUsuario.AutoSize = true;
            this.lblUsuario.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsuario.Location = new System.Drawing.Point(342, 133);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(82, 17);
            this.lblUsuario.TabIndex = 8;
            this.lblUsuario.Text = "lblUsuario";
            // 
            // btnContra
            // 
            this.btnContra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnContra.FlatAppearance.BorderSize = 0;
            this.btnContra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnContra.Font = new System.Drawing.Font("Arial", 14.25F);
            this.btnContra.ForeColor = System.Drawing.Color.White;
            this.btnContra.Location = new System.Drawing.Point(521, 86);
            this.btnContra.Name = "btnContra";
            this.btnContra.Size = new System.Drawing.Size(206, 32);
            this.btnContra.TabIndex = 9;
            this.btnContra.Text = "Solicitar contraseña";
            this.btnContra.UseVisualStyleBackColor = false;
            this.btnContra.Click += new System.EventHandler(this.btnContra_Click);
            // 
            // Devoluciones
            // 
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(754, 491);
            this.Controls.Add(this.btnContra);
            this.Controls.Add(this.tablaPrestamos);
            this.Controls.Add(this.lblUsuario);
            this.Controls.Add(this.btnDevolver);
            this.Controls.Add(this.btnHuella);
            this.Controls.Add(this.label3);
            this.MaximumSize = new System.Drawing.Size(770, 530);
            this.MinimumSize = new System.Drawing.Size(770, 530);
            this.Name = "Devoluciones";
            this.Load += new System.EventHandler(this.Devoluciones_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.tablaPrestamos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Button btnHuella;
        private Button btnDevolver;
        private Button button1;
        private DataGridView tablaPrestamos;
        private Label lblUsuario;
        private Button btnContra;
    }
}
