﻿using System.Windows.Forms;

namespace UareUSampleCSharp
{
    partial class Config
    {
        private System.ComponentModel.IContainer components = null;



        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Config
            // 
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Name = "Config";
            this.Load += new System.EventHandler(this.Config_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Label label1;
        private Label label2;
    }
}
