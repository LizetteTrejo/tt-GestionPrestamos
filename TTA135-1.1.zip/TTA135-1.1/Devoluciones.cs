﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using LectorPrueba.MySQL;
using MySql.Data.MySqlClient;

namespace UareUSampleCSharp
{
    public partial class Devoluciones : Form
    {
        private Form_Main _formMain;
        private string boletaAlumno = null;
        private Conexion conexionBD = new Conexion();

        public Devoluciones(Form_Main formMain)
        {
            InitializeComponent();
            _formMain = formMain;
            this.Load += Devoluciones_Load; // <-- Vincular evento de carga
        }

        private void Devoluciones_Load(object sender, EventArgs e)
        {
            lblUsuario.Text = "";
            tablaPrestamos.RowHeadersVisible = false;
            tablaPrestamos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            tablaPrestamos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tablaPrestamos.MultiSelect = false;
            tablaPrestamos.ReadOnly = true;
            tablaPrestamos.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12F, FontStyle.Bold);
            tablaPrestamos.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(14, 150, 218);
            tablaPrestamos.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            tablaPrestamos.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tablaPrestamos.EnableHeadersVisualStyles = false;
            tablaPrestamos.DefaultCellStyle.Font = new Font("Arial", 11F, FontStyle.Regular);
            tablaPrestamos.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tablaPrestamos.RowTemplate.Height = 28;
            tablaPrestamos.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            tablaPrestamos.AlternatingRowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tablaPrestamos.BorderStyle = BorderStyle.None;
        }



        private void btnHuella_Click(object sender, EventArgs e)
        {
            if (_formMain.CurrentReader == null)
            {
                MessageBox.Show("🖐️ Primero debes seleccionar un lector de huellas desde la configuración.",
                                "Lector no seleccionado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Verification verificacion = new Verification();
            verificacion._sender = _formMain;

            if (verificacion.ShowDialog() == DialogResult.OK)
            {
                boletaAlumno = verificacion.BoletaVerificada;

                if (boletaAlumno == null)
                {
                    MessageBox.Show("❌ Huella no reconocida.");
                    return;
                }

                // Obtener y mostrar datos del alumno en lblUsuario
                using (var conn = conexionBD.Conectar())

                {

                    string query = "SELECT Nombre, A_Paterno, A_Materno FROM alumno WHERE Boleta = @boleta";
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@boleta", boletaAlumno);
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string nombre = reader["Nombre"].ToString();
                                string apaterno = reader["A_Paterno"].ToString();
                                string amaterno = reader["A_Materno"].ToString();
                                lblUsuario.Text = $"👤 {nombre} {apaterno} {amaterno} - 📌 {boletaAlumno}";
                            }
                            else
                            {
                                lblUsuario.Text = "Alumno no encontrado.";
                            }
                        }
                    }
                }

                // Cargar préstamos
                CargarPrestamosDeAlumno();
            }
            else
            {
                MessageBox.Show("❌ No se completó la verificación de huella.");
            }
        }




private void CargarPrestamosDeAlumno()
    {
        try
        {
            Conexion conexionBD = new Conexion(); // 👈 Creas tu conexión

            using (var conn = conexionBD.Conectar()) // 👈 La usas ya abierta
            {
                string query = @"
    SELECT 
        p.ID_Prestamo AS 'N. Préstamo',
        p.Fecha_Prestamo AS 'Salida',
        p.Fecha_Devolucion AS 'Devolución',
        p.Estado,
        l.ISBN AS 'ID o ISBN',
        l.Titulo AS 'Nombre',
        'Libro' AS Tipo
    FROM prestamo p
    JOIN prestamo_libro pl ON p.ID_Prestamo = pl.ID_Prestamo
    JOIN libro l ON pl.ISBN = l.ISBN
    WHERE p.Boleta = @boleta AND p.Estado = 'Activo'

    UNION

    SELECT 
        p.ID_Prestamo AS 'N. Préstamo',
        p.Fecha_Prestamo AS 'Salida',
        p.Fecha_Devolucion AS 'Devolución',
        p.Estado,
        m.ID AS 'ID o ISBN',
        m.Nombre AS 'Nombre',
        'Material' AS Tipo
    FROM prestamo p
    JOIN prestamo_material pm ON p.ID_Prestamo = pm.ID_Prestamo
    JOIN material m ON pm.ID_Material = m.ID
    WHERE p.Boleta = @boleta AND p.Estado = 'Activo'
";

                using (var adapter = new MySqlDataAdapter(query, conn))
                {
                    adapter.SelectCommand.Parameters.AddWithValue("@boleta", boletaAlumno);

                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    tablaPrestamos.DataSource = dt;

                    // PERSONALIZAR COLUMNAS
                    if (tablaPrestamos.Columns.Contains("N. Préstamo"))
                    {
                        tablaPrestamos.Columns["N. Préstamo"].DisplayIndex = 0;
                        tablaPrestamos.Columns["N. Préstamo"].Width = 90;
                    }

                    if (tablaPrestamos.Columns.Contains("ID o ISBN"))
                    {
                        tablaPrestamos.Columns["ID o ISBN"].DisplayIndex = 1;
                        tablaPrestamos.Columns["ID o ISBN"].Width = 120;
                    }

                    if (tablaPrestamos.Columns.Contains("Nombre"))
                    {
                        tablaPrestamos.Columns["Nombre"].DisplayIndex = 2;
                        tablaPrestamos.Columns["Nombre"].Width = 150;
                    }

                    if (tablaPrestamos.Columns.Contains("Salida"))
                    {
                        tablaPrestamos.Columns["Salida"].DisplayIndex = 3;
                        tablaPrestamos.Columns["Salida"].Width = 120;
                    }

                    if (tablaPrestamos.Columns.Contains("Devolución"))
                    {
                        tablaPrestamos.Columns["Devolución"].DisplayIndex = 4;
                        tablaPrestamos.Columns["Devolución"].Width = 120;
                    }

                    if (tablaPrestamos.Columns.Contains("Estado"))
                    {
                        tablaPrestamos.Columns["Estado"].DisplayIndex = 5;
                        tablaPrestamos.Columns["Estado"].Width = 90;
                    }

                    if (tablaPrestamos.Columns.Contains("Tipo"))
                    {
                        tablaPrestamos.Columns["Tipo"].DisplayIndex = 6;
                        tablaPrestamos.Columns["Tipo"].Width = 80;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error al cargar préstamos del alumno:\n" + ex.Message);
        }
    }


    private void btnDevolver_Click(object sender, EventArgs e)
        {
            if (boletaAlumno == null)
            {
                MessageBox.Show("🔒 Verifica primero la huella del alumno.",
                                "Huella no verificada", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (tablaPrestamos.SelectedRows.Count == 0)
            {
                MessageBox.Show("📋 Debes seleccionar un préstamo de la tabla.",
                                "Préstamo no seleccionado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var fila = tablaPrestamos.SelectedRows[0];
            string tipo = fila.Cells["Tipo"].Value.ToString();
            string codigo = fila.Cells["ID o ISBN"].Value.ToString();  // ← Aquí se cambió el nombre de columna

            using (var conn = conexionBD.Conectar())
            {
                string buscarPrestamo = @"
            SELECT ID_Prestamo 
            FROM prestamo 
            WHERE Boleta = @boleta AND Estado = 'Activo' 
            AND ID_Prestamo IN (
                SELECT ID_Prestamo FROM prestamo_libro WHERE ISBN = @codigo
                UNION
                SELECT ID_Prestamo FROM prestamo_material WHERE ID_Material = @codigo
            )";

                long idPrestamo = -1;

                using (var cmd = new MySqlCommand(buscarPrestamo, conn))
                {
                    cmd.Parameters.AddWithValue("@boleta", boletaAlumno);
                    cmd.Parameters.AddWithValue("@codigo", codigo);

                    object result = cmd.ExecuteScalar();
                    if (result == null || !long.TryParse(result.ToString(), out idPrestamo))
                    {
                        MessageBox.Show("❌ No se encontró un préstamo activo para ese recurso.",
                                        "Sin coincidencias", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                // Actualizar estado del préstamo
                using (var cmd = new MySqlCommand("UPDATE prestamo SET Estado = 'Devuelto' WHERE ID_Prestamo = @id", conn))
                {
                    cmd.Parameters.AddWithValue("@id", idPrestamo);
                    cmd.ExecuteNonQuery();
                }

                // Actualizar stock del recurso
                string actualizarStock = (tipo == "Libro")
                    ? "UPDATE libro SET Stock = Stock + 1 WHERE ISBN = @codigo"
                    : "UPDATE material SET Stock = Stock + 1 WHERE ID = @codigo";

                using (var cmd = new MySqlCommand(actualizarStock, conn))
                {
                    cmd.Parameters.AddWithValue("@codigo", codigo);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("✅ Devolución registrada correctamente.",
                                "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);

                CargarPrestamosDeAlumno(); // Refrescar la tabla
            }
        }

    }
}
