﻿using System;
using System.Windows.Forms;
using System.Drawing;

namespace UareUSampleCSharp
{
    public partial class SuperPasswordForm : Form
    {
        public string EnteredPassword => txtPassword.Text;

        public SuperPasswordForm()
        {
            InitializeComponent();
        }
        private void btnAceptar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();

        }
    }
}
