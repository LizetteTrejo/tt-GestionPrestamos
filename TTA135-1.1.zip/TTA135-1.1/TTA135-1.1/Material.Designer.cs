﻿using System.Windows.Forms;

namespace UareUSampleCSharp
{
    partial class Material
    {
        private System.ComponentModel.IContainer components = null;



        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNombreMaterial = new System.Windows.Forms.TextBox();
            this.tableMaterial = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnNuevoMaterial = new System.Windows.Forms.Button();
            this.btnEditarMaterial = new System.Windows.Forms.Button();
            this.btnBorrarMaterial = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tableMaterial)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(24, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Material";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 14.25F);
            this.label2.Location = new System.Drawing.Point(26, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre del material:";
            // 
            // txtNombreMaterial
            // 
            this.txtNombreMaterial.Font = new System.Drawing.Font("Arial", 14.25F);
            this.txtNombreMaterial.Location = new System.Drawing.Point(29, 93);
            this.txtNombreMaterial.Name = "txtNombreMaterial";
            this.txtNombreMaterial.Size = new System.Drawing.Size(577, 29);
            this.txtNombreMaterial.TabIndex = 2;
            this.txtNombreMaterial.TextChanged += new System.EventHandler(this.txtNombreMaterial_TextChanged);
            // 
            // tableMaterial
            // 
            this.tableMaterial.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.tableMaterial.BackgroundColor = System.Drawing.Color.White;
            this.tableMaterial.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.tableMaterial.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.tableMaterial.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableMaterial.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column4,
            this.Column5,
            this.Column6});
            this.tableMaterial.EnableHeadersVisualStyles = false;
            this.tableMaterial.GridColor = System.Drawing.Color.Black;
            this.tableMaterial.Location = new System.Drawing.Point(29, 138);
            this.tableMaterial.Name = "tableMaterial";
            this.tableMaterial.RowHeadersVisible = false;
            this.tableMaterial.Size = new System.Drawing.Size(693, 290);
            this.tableMaterial.TabIndex = 4;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "ID";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Nombre";
            this.Column2.Name = "Column2";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Estado físico";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Marca";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Categoría";
            this.Column6.Name = "Column6";
            // 
            // btnNuevoMaterial
            // 
            this.btnNuevoMaterial.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnNuevoMaterial.FlatAppearance.BorderSize = 0;
            this.btnNuevoMaterial.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNuevoMaterial.Font = new System.Drawing.Font("Arial", 14.25F);
            this.btnNuevoMaterial.ForeColor = System.Drawing.Color.White;
            this.btnNuevoMaterial.Location = new System.Drawing.Point(368, 440);
            this.btnNuevoMaterial.Name = "btnNuevoMaterial";
            this.btnNuevoMaterial.Size = new System.Drawing.Size(96, 29);
            this.btnNuevoMaterial.TabIndex = 5;
            this.btnNuevoMaterial.Text = "Nuevo";
            this.btnNuevoMaterial.UseVisualStyleBackColor = false;
            this.btnNuevoMaterial.Click += new System.EventHandler(this.btnNuevoMaterial_Click);
            // 
            // btnEditarMaterial
            // 
            this.btnEditarMaterial.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnEditarMaterial.FlatAppearance.BorderSize = 0;
            this.btnEditarMaterial.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditarMaterial.Font = new System.Drawing.Font("Arial", 14.25F);
            this.btnEditarMaterial.ForeColor = System.Drawing.Color.White;
            this.btnEditarMaterial.Location = new System.Drawing.Point(496, 440);
            this.btnEditarMaterial.Name = "btnEditarMaterial";
            this.btnEditarMaterial.Size = new System.Drawing.Size(96, 29);
            this.btnEditarMaterial.TabIndex = 6;
            this.btnEditarMaterial.Text = "Editar";
            this.btnEditarMaterial.UseVisualStyleBackColor = false;
            this.btnEditarMaterial.Click += new System.EventHandler(this.btnEditarMaterial_Click);
            // 
            // btnBorrarMaterial
            // 
            this.btnBorrarMaterial.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnBorrarMaterial.FlatAppearance.BorderSize = 0;
            this.btnBorrarMaterial.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBorrarMaterial.Font = new System.Drawing.Font("Arial", 14.25F);
            this.btnBorrarMaterial.ForeColor = System.Drawing.Color.White;
            this.btnBorrarMaterial.Location = new System.Drawing.Point(626, 440);
            this.btnBorrarMaterial.Name = "btnBorrarMaterial";
            this.btnBorrarMaterial.Size = new System.Drawing.Size(96, 29);
            this.btnBorrarMaterial.TabIndex = 7;
            this.btnBorrarMaterial.Text = "Borrar";
            this.btnBorrarMaterial.UseVisualStyleBackColor = false;
            this.btnBorrarMaterial.Click += new System.EventHandler(this.btnBorrarMaterial_Click);
            // 
            // Material
            // 
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(754, 491);
            this.Controls.Add(this.btnBorrarMaterial);
            this.Controls.Add(this.btnEditarMaterial);
            this.Controls.Add(this.btnNuevoMaterial);
            this.Controls.Add(this.tableMaterial);
            this.Controls.Add(this.txtNombreMaterial);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximumSize = new System.Drawing.Size(770, 530);
            this.MinimumSize = new System.Drawing.Size(770, 530);
            this.Name = "Material";
            this.Load += new System.EventHandler(this.MaterialForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tableMaterial)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtNombreMaterial;
        private DataGridView tableMaterial;
        private Button btnNuevoMaterial;
        private Button btnEditarMaterial;
        private Button btnBorrarMaterial;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
    }
}
