﻿using System.Windows.Forms;

namespace UareUSampleCSharp
{
    partial class Login
    {
        private System.ComponentModel.IContainer components = null;



        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lbllogin = new System.Windows.Forms.Label();
            this.lbllogin1 = new System.Windows.Forms.Label();
            this.lblleerhuella = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnConfig = new System.Windows.Forms.Button();
            this.btnRoot = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbllogin
            // 
            this.lbllogin.AutoSize = true;
            this.lbllogin.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold);
            this.lbllogin.ForeColor = System.Drawing.Color.White;
            this.lbllogin.Location = new System.Drawing.Point(9, 32);
            this.lbllogin.Name = "lbllogin";
            this.lbllogin.Size = new System.Drawing.Size(370, 24);
            this.lbllogin.TabIndex = 0;
            this.lbllogin.Text = "Gestion de préstamos autenticados";
            // 
            // lbllogin1
            // 
            this.lbllogin1.AutoSize = true;
            this.lbllogin1.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold);
            this.lbllogin1.ForeColor = System.Drawing.Color.White;
            this.lbllogin1.Location = new System.Drawing.Point(48, 56);
            this.lbllogin1.Name = "lbllogin1";
            this.lbllogin1.Size = new System.Drawing.Size(285, 24);
            this.lbllogin1.TabIndex = 1;
            this.lbllogin1.Text = "mediante huellas dactilares";
            // 
            // lblleerhuella
            // 
            this.lblleerhuella.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblleerhuella.ForeColor = System.Drawing.Color.White;
            this.lblleerhuella.Location = new System.Drawing.Point(12, 219);
            this.lblleerhuella.Name = "lblleerhuella";
            this.lblleerhuella.Size = new System.Drawing.Size(368, 18);
            this.lblleerhuella.TabIndex = 2;
            this.lblleerhuella.Text = "Coloca tu huella en el lector...                                         ";
            this.lblleerhuella.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::LectorPrueba.Properties.Resources.huella;
            this.pictureBox1.Location = new System.Drawing.Point(142, 91);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 101);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // btnConfig
            // 
            this.btnConfig.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(111)))), ((int)(((byte)(159)))));
            this.btnConfig.FlatAppearance.BorderSize = 0;
            this.btnConfig.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfig.Image = global::LectorPrueba.Properties.Resources.config;
            this.btnConfig.Location = new System.Drawing.Point(352, 270);
            this.btnConfig.Margin = new System.Windows.Forms.Padding(359, 3, 3, 3);
            this.btnConfig.Name = "btnConfig";
            this.btnConfig.Size = new System.Drawing.Size(42, 38);
            this.btnConfig.TabIndex = 28;
            this.btnConfig.UseVisualStyleBackColor = false;
            this.btnConfig.Click += new System.EventHandler(this.btnConfig_Click);
            // 
            // btnRoot
            // 
            this.btnRoot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnRoot.FlatAppearance.BorderSize = 0;
            this.btnRoot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRoot.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.btnRoot.ForeColor = System.Drawing.Color.White;
            this.btnRoot.Location = new System.Drawing.Point(-1, 280);
            this.btnRoot.Name = "btnRoot";
            this.btnRoot.Size = new System.Drawing.Size(94, 31);
            this.btnRoot.TabIndex = 29;
            this.btnRoot.Text = "Root";
            this.btnRoot.UseVisualStyleBackColor = false;
            this.btnRoot.Click += new System.EventHandler(this.btnRoot_Click);
            // 
            // Login
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(111)))), ((int)(((byte)(159)))));
            this.ClientSize = new System.Drawing.Size(394, 311);
            this.Controls.Add(this.btnRoot);
            this.Controls.Add(this.btnConfig);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblleerhuella);
            this.Controls.Add(this.lbllogin1);
            this.Controls.Add(this.lbllogin);
            this.MaximumSize = new System.Drawing.Size(410, 350);
            this.MinimumSize = new System.Drawing.Size(410, 350);
            this.Name = "Login";
            this.Text = "Ingreso";
            this.Load += new System.EventHandler(this.Login_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Label lbllogin;
        private Label lbllogin1;
        private Label lblleerhuella;
        private PictureBox pictureBox1;
        private Button btnConfig;
        private Button btnRoot;
    }
}
