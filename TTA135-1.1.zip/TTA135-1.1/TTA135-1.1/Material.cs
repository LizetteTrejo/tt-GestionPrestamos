﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using LectorPrueba.MySQL;
using MySql.Data.MySqlClient;

namespace UareUSampleCSharp
{
    public partial class Material : Form
    {
        public Form_Main _sender;
        private Conexion conexionBD = new Conexion();

        public Material()
        {
            InitializeComponent();
            this.Load += new EventHandler(MaterialForm_Load);
            txtNombreMaterial.TextChanged += txtNombreMaterial_TextChanged;

            // Comportamiento
            tableMaterial.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tableMaterial.MultiSelect = false;
            tableMaterial.ReadOnly = true;
            tableMaterial.RowHeadersVisible = false;
            tableMaterial.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Encabezado
            tableMaterial.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12F, FontStyle.Bold);
            tableMaterial.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(14, 150, 218);
            tableMaterial.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            tableMaterial.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tableMaterial.EnableHeadersVisualStyles = false;

            // Celdas
            tableMaterial.DefaultCellStyle.Font = new Font("Arial", 11F, FontStyle.Regular);
            tableMaterial.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Apariencia de filas
            tableMaterial.RowTemplate.Height = 28;
            tableMaterial.CellBorderStyle = DataGridViewCellBorderStyle.None;

            // Zebra (filas alternadas)
            tableMaterial.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 240, 240);
            tableMaterial.AlternatingRowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void MaterialForm_Load(object sender, EventArgs e)
        {
            CargarMaterial();
            tableMaterial.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void txtNombreMaterial_TextChanged(object sender, EventArgs e)
        {
            FiltrarMaterial(txtNombreMaterial.Text);
        }

        private void btnNuevoMaterial_Click(object sender, EventArgs e)
        {
            RegistroMaterial frm = new RegistroMaterial(this);
            frm.Show();
        }

        private void btnEditarMaterial_Click(object sender, EventArgs e)
        {
            if (tableMaterial.CurrentRow == null || tableMaterial.CurrentRow.Index < 0)
            {
                MessageBox.Show("Selecciona un material de la tabla.");
                return;
            }

            string id = tableMaterial.CurrentRow.Cells["ID"].Value.ToString();
            RegistroMaterial frm = new RegistroMaterial(this, id); // modo edición
            frm.Show();
        }

        private void btnBorrarMaterial_Click(object sender, EventArgs e)
        {
            if (tableMaterial.CurrentRow == null || tableMaterial.CurrentRow.Index < 0)
            {
                MessageBox.Show("Selecciona un material de la tabla.");
                return;
            }

            string id = tableMaterial.CurrentRow.Cells["ID"].Value.ToString();
            string nombre = tableMaterial.CurrentRow.Cells["Nombre"].Value.ToString();

            DialogResult result = MessageBox.Show(
                $"¿Deseas borrar el material:\n\n\"{nombre}\" (ID: {id})?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result == DialogResult.No) return;

            try
            {
                using (var conn = conexionBD.Conectar())
                {
                    string query = "DELETE FROM material WHERE ID = @id";
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Material eliminado correctamente.");
                CargarMaterial();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar el material: " + ex.Message);
            }
        }

        public void CargarMaterial()
        {
            try
            {
                using (var connection = conexionBD.Conectar())
                {
                    string query = "SELECT ID, Nombre, Estado, Marca, Categoria, Stock FROM material";
                    MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    tableMaterial.DataSource = null;
                    tableMaterial.Columns.Clear();
                    tableMaterial.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar materiales: " + ex.Message);
            }

            if (tableMaterial.Columns.Count >= 6)
            {
                tableMaterial.Columns[0].Width = 50;   // ID
                tableMaterial.Columns[1].Width = 180;  // Nombre
                tableMaterial.Columns[2].Width = 120;  // Estado físico
                tableMaterial.Columns[3].Width = 120;  // Marca
                tableMaterial.Columns[4].Width = 120;  // Categoría
                tableMaterial.Columns[5].Width = 80;   // Stock
            }

            for (int i = 0; i < tableMaterial.Columns.Count; i++)
            {
                tableMaterial.Columns[i].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                tableMaterial.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
        }

        private void FiltrarMaterial(string texto)
        {
            try
            {
                using (var connection = conexionBD.Conectar())
                {
                    string query = @"SELECT ID, Nombre, Estado, Marca, Categoria, Stock
                                     FROM material
                                     WHERE Nombre LIKE @texto OR Estado LIKE @texto OR Marca LIKE @texto OR Categoria LIKE @texto";
                    using (MySqlCommand cmd = new MySqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@texto", "%" + texto + "%");
                        MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        tableMaterial.DataSource = null;
                        tableMaterial.Columns.Clear();
                        tableMaterial.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al filtrar materiales: " + ex.Message);
            }

            if (tableMaterial.Columns.Count >= 6)
            {
                tableMaterial.Columns[0].Width = 50;
                tableMaterial.Columns[1].Width = 180;
                tableMaterial.Columns[2].Width = 120;
                tableMaterial.Columns[3].Width = 120;
                tableMaterial.Columns[4].Width = 120;
                tableMaterial.Columns[5].Width = 80;
            }

            for (int i = 0; i < tableMaterial.Columns.Count; i++)
            {
                tableMaterial.Columns[i].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                tableMaterial.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
        }
    }
}
