﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using LectorPrueba.MySQL;
using MySql.Data.MySqlClient;

namespace LectorPrueba
{
    public partial class Multas : Form
    {
        private Conexion conexionBD = new Conexion();
        private string boletaAlumno;

        public Multas()
        {
            InitializeComponent();
        }


        private void txtBuscarBoleta_TextChanged(object sender, EventArgs e)
        {
            boletaAlumno = txtBuscarBoleta.Text.Trim();
            CargarMultas();
        }

        private void CargarMultas()
        {
            decimal total = 0;
            boletaAlumno = txtBuscarBoleta.Text.Trim();

            try
            {
                using (var conn = conexionBD.Conectar())
                {
                    string query = @"
                SELECT m.* 
                FROM multa m
                JOIN prestamo p ON m.ID_Prestamo = p.ID_Prestamo
                WHERE p.Boleta = @boleta";

                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@boleta", boletaAlumno);
                        using (var adapter = new MySqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            tablaMultas.DataSource = dt;

                            foreach (DataRow row in dt.Rows)
                            {
                                if (decimal.TryParse(row["Monto"].ToString(), out decimal monto))
                                    total += monto;
                            }

                            txtTotal.Text = total.ToString("0.00");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar multas: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void txtEfectivo_TextChanged(object sender, EventArgs e)
        {
            CargarMultas();
            if (decimal.TryParse(txtEfectivo.Text, out decimal efectivo) &&
                decimal.TryParse(txtTotal.Text, out decimal totalMulta))
            {
                decimal cambio = efectivo - totalMulta;
                txtCambio.Text = cambio >= 0 ? cambio.ToString("0.00") : "0.00";
            }
            else
            {
                txtCambio.Text = "0.00";
            }
        }

        private void btnPagar_Click(object sender, EventArgs e)
        {
            if (!decimal.TryParse(txtEfectivo.Text, out decimal efectivo))
            {
                MessageBox.Show("💵 Ingresa una cantidad válida en efectivo.", "Efectivo inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(txtTotal.Text, out decimal totalMulta))
            {
                MessageBox.Show("⚠️ No se puede obtener el total de multas.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (efectivo < totalMulta)
            {
                MessageBox.Show("❌ El efectivo recibido es menor al total a pagar.", "Pago insuficiente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = conexionBD.Conectar())
                {
                    string updateMultas = @"
                    UPDATE multa m
                    JOIN prestamo p ON m.ID_Prestamo = p.ID_Prestamo
                    SET m.Estado = 'Pagado'
                    WHERE m.Estado = 'Pendiente' AND p.Boleta = @boleta";
                                    ;

                    using (var cmd = new MySqlCommand(updateMultas, conn))
                    {
                        cmd.Parameters.AddWithValue("@boleta", boletaAlumno);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("✅ Pago registrado con éxito.", "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al registrar el pago: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
       
    }
}