﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DPUruNet;
using LectorPrueba.MySQL;
using MySql.Data.MySqlClient;

namespace UareUSampleCSharp
{
    public partial class Usuarios : Form
    {
        private Form_Main _formMain;
        private string boletaAlumno = null;
        private Conexion conexionBD = new Conexion();


        public Usuarios(Form_Main formMain)
        {
            InitializeComponent();

            _formMain = formMain;
            this.Load += new EventHandler(Usuarios_Load);

            // Configuración general
            tableUsuarios.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tableUsuarios.ReadOnly = true;
            tableUsuarios.AllowUserToAddRows = false;
            tableUsuarios.AllowUserToDeleteRows = false;
            tableUsuarios.MultiSelect = false;
            tableUsuarios.RowHeadersVisible = false;
            tableUsuarios.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Estilo de encabezados
            tableUsuarios.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12F, FontStyle.Bold);
            tableUsuarios.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(14, 150, 218);
            tableUsuarios.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            tableUsuarios.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tableUsuarios.EnableHeadersVisualStyles = false;

            // Estilo de celdas normales
            tableUsuarios.DefaultCellStyle.Font = new Font("Arial", 11F, FontStyle.Regular);
            tableUsuarios.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Estilo de filas
            tableUsuarios.RowTemplate.Height = 28;
            tableUsuarios.CellBorderStyle = DataGridViewCellBorderStyle.None;

            // Zebra
            tableUsuarios.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 240, 240);
            tableUsuarios.AlternatingRowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }


        private void label1_Click(object sender, EventArgs e) { }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {
            FiltrarUsuarios(txtNombre.Text);
        }



        private void tableUsuarios_CellContentClick(object sender, DataGridViewCellEventArgs e) {
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            if (_formMain.CurrentReader == null)
            {
                MessageBox.Show(
                "🖐️ Primero debes seleccionar un lector de huellas desde la configuración.",
                "Lector no seleccionado",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning

            );
                return;
            }


            using (var aviso = new AvisoPrivacidadForm())
            {
                var result = aviso.ShowDialog();

                if (result == DialogResult.OK)
                {
                    RegistroUsuarios frm = new RegistroUsuarios(_formMain, this);
                    frm.Show();
                }
            }
        }




        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (_formMain.CurrentReader == null)
            {
                MessageBox.Show(
                    "🖐️ Primero debes seleccionar un lector de huellas desde la configuración.",
                    "Lector no seleccionado",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                return;
            }

            if (tableUsuarios.CurrentRow == null || tableUsuarios.CurrentRow.Index < 0)
            {
                MessageBox.Show("Selecciona un usuario de la tabla.");
                return;
            }

            string boletaSeleccionada = tableUsuarios.CurrentRow.Cells["Boleta"].Value.ToString();

            Verification verificacion = new Verification();
            verificacion._sender = _formMain;
            verificacion.BoletaEsperada = boletaSeleccionada; // 🔐 solo esa boleta puede validar

            if (verificacion.ShowDialog() == DialogResult.OK)
            {
                boletaAlumno = verificacion.BoletaVerificada;

                if (boletaAlumno == boletaSeleccionada)
                {
                    // Huella coincide con el alumno seleccionado

                    RegistroUsuarios registroForm = new RegistroUsuarios(_formMain, this, boletaAlumno);
                    registroForm.Show();
                }
                else
                {
                    MessageBox.Show("❌ La huella no coincide con el usuario seleccionado.");
                }
            }
            else
            {
                MessageBox.Show("❌ No se completó la verificación de huella.");
            }
        }


        private void btnBorrar_Click(object sender, EventArgs e)
        {
            if (tableUsuarios.CurrentRow == null || tableUsuarios.CurrentRow.Index < 0)
            {
                MessageBox.Show("Selecciona un usuario de la tabla.");
                return;
            }

            string boleta = tableUsuarios.CurrentRow.Cells["Boleta"].Value.ToString();
            string nombreCompleto = tableUsuarios.CurrentRow.Cells["Nombre"].Value.ToString() + " " +
                                    tableUsuarios.CurrentRow.Cells["A_Paterno"].Value.ToString() + " " +
                                    tableUsuarios.CurrentRow.Cells["A_Materno"].Value.ToString();

            try
            {
                using (var conn = conexionBD.Conectar())
                {
                    // 🔎 Verificar si tiene préstamos activos
                    string checkQuery = "SELECT COUNT(*) FROM prestamo WHERE Boleta = @boleta AND Estado = 'Activo'";
                    using (var checkCmd = new MySqlCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@boleta", boleta);
                        int prestamosActivos = Convert.ToInt32(checkCmd.ExecuteScalar());

                        if (prestamosActivos > 0)
                        {
                            MessageBox.Show("❌ Este alumno tiene préstamos activos y no puede ser eliminado.",
                                            "Eliminación denegada",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    // ✅ Confirmar eliminación
                    DialogResult result = MessageBox.Show(
                        $"¿Estás seguro que deseas borrar al alumno:\n\n{nombreCompleto} ({boleta})?",
                        "Confirmar eliminación",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Warning
                    );

                    if (result == DialogResult.No)
                        return;

                    // 🗑️ Eliminar el alumno
                    string deleteQuery = "DELETE FROM alumno WHERE Boleta = @boleta";
                    using (var cmd = new MySqlCommand(deleteQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@boleta", boleta);
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                            MessageBox.Show("Alumno eliminado correctamente.");
                        else
                            MessageBox.Show("No se pudo eliminar el alumno.");
                    }
                }

                RecargarUsuarios();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar: " + ex.Message);
            }
        }



        private void Usuarios_Load(object sender, EventArgs e)
        {
            RecargarUsuarios();
        }

        private void FiltrarUsuarios(string texto)
        {
            try
            {
                using (var conn = conexionBD.Conectar())
                {
                    string query = @"SELECT Boleta, Nombre, A_Paterno, A_Materno, Telefono
                                     FROM alumno
                                     WHERE Nombre LIKE @texto OR A_Paterno LIKE @texto OR A_Materno LIKE @texto";

                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@texto", "%" + texto + "%");
                        MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        tableUsuarios.DataSource = null;
                        tableUsuarios.Columns.Clear();
                        tableUsuarios.DataSource = dt;

                        tableUsuarios.Columns[0].Width = 100;
                        tableUsuarios.Columns[1].Width = 150;
                        tableUsuarios.Columns[2].Width = 150;
                        tableUsuarios.Columns[3].Width = 150;
                        tableUsuarios.Columns[4].Width = 120;

                        foreach (DataGridViewColumn col in tableUsuarios.Columns)
                        {
                            col.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al filtrar usuarios: " + ex.Message);
            }
        }

        public void RecargarUsuarios()
        {
            try
            {
                using (var conn = conexionBD.Conectar())
                {
                    string query = "SELECT Boleta, Nombre, A_Paterno, A_Materno, Telefono FROM alumno";
                    MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    tableUsuarios.DataSource = null;
                    tableUsuarios.Columns.Clear();
                    tableUsuarios.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al recargar usuarios: " + ex.Message);
            }
        }
    }
}
