﻿using System;
using System.Windows.Forms;
using LectorPrueba.MySQL;
using MySql.Data.MySqlClient;

namespace UareUSampleCSharp
{
    public partial class RegistroMaterial : Form
    {
        private Material _formPadre;
        private string idEdicion = null;
        private Conexion conexionBD = new Conexion();

        private bool esEdicion => idEdicion != null;

        public RegistroMaterial(Material padre)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            _formPadre = padre;
        }

        public RegistroMaterial(Material padre, string id)
            : this(padre)
        {
            idEdicion = id;
        }

        private void RegistroMaterial_Load(object sender, EventArgs e)
        {
            if (esEdicion)
            {
                this.Text = "Editar Material";
                btnGuar.Text = "Guardar Cambios";
                txtID.ReadOnly = true;
                CargarDatosMaterial();
            }
            else
            {
                this.Text = "Registrar Material";
                btnGuar.Text = "Registrar";
            }
        }

        private void CargarDatosMaterial()
        {
            using (var conn = conexionBD.Conectar())
            {
                string query = "SELECT * FROM material WHERE ID = @id";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", idEdicion);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtID.Text = reader["ID"].ToString();
                            txtNombre.Text = reader["Nombre"].ToString();
                            txtEstado.Text = reader["Estado"].ToString();
                            txtMarca.Text = reader["Marca"].ToString();
                            txtCategoria.Text = reader["Categoria"].ToString();
                            txtStock.Text = reader["Stock"].ToString();
                        }
                    }
                }
            }
        }

        private void btnGuar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtID.Text) ||
                string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtEstado.Text) ||
                string.IsNullOrWhiteSpace(txtMarca.Text) ||
                string.IsNullOrWhiteSpace(txtCategoria.Text) ||
                string.IsNullOrWhiteSpace(txtStock.Text))
            {
                MessageBox.Show("Por favor llena todos los campos.");
                return;
            }

            if (!int.TryParse(txtStock.Text.Trim(), out int stock) || stock < 0)
            {
                MessageBox.Show("El stock debe ser un número entero mayor o igual a 0.");
                return;
            }

            using (var conn = conexionBD.Conectar())
            {
                if (esEdicion)
                {
                    DialogResult result = MessageBox.Show(
                        "¿Estás seguro de que deseas guardar los cambios?",
                        "Confirmar actualización",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question
                    );

                    if (result == DialogResult.No)
                        return;

                    string updateQuery = @"UPDATE material SET 
                        Nombre = @nombre, Estado = @estado, Marca = @marca, Categoria = @categoria, Stock = @stock
                        WHERE ID = @id";

                    using (var cmd = new MySqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", txtID.Text.Trim());
                        cmd.Parameters.AddWithValue("@nombre", txtNombre.Text.Trim());
                        cmd.Parameters.AddWithValue("@estado", txtEstado.Text.Trim());
                        cmd.Parameters.AddWithValue("@marca", txtMarca.Text.Trim());
                        cmd.Parameters.AddWithValue("@categoria", txtCategoria.Text.Trim());
                        cmd.Parameters.AddWithValue("@stock", stock);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("✅ Material actualizado correctamente.");
                }
                else
                {
                    string verificarQuery = "SELECT COUNT(*) FROM material WHERE ID = @id";
                    using (var cmd = new MySqlCommand(verificarQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", txtID.Text.Trim());
                        int count = Convert.ToInt32(cmd.ExecuteScalar());
                        if (count > 0)
                        {
                            MessageBox.Show("Ya existe un material con ese ID.");
                            return;
                        }
                    }

                    string insertQuery = @"INSERT INTO material 
                        (ID, Nombre, Estado, Marca, Categoria, Stock)
                        VALUES (@id, @nombre, @estado, @marca, @categoria, @stock)";

                    using (var cmd = new MySqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", txtID.Text.Trim());
                        cmd.Parameters.AddWithValue("@nombre", txtNombre.Text.Trim());
                        cmd.Parameters.AddWithValue("@estado", txtEstado.Text.Trim());
                        cmd.Parameters.AddWithValue("@marca", txtMarca.Text.Trim());
                        cmd.Parameters.AddWithValue("@categoria", txtCategoria.Text.Trim());
                        cmd.Parameters.AddWithValue("@stock", stock);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Material registrado correctamente.");
                }
            }

            _formPadre?.CargarMaterial();
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
