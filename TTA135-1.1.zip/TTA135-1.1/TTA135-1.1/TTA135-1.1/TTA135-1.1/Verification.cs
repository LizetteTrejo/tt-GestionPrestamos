﻿using System;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using DPUruNet;
using FmdObject = DPUruNet.Fmd;
using FmdFormat = DPUruNet.Constants.Formats.Fmd;
using Mysqlx;
using LectorPrueba.MySQL;

namespace UareUSampleCSharp
{
    public partial class Verification : Form
    {
        public Form_Main _sender { get; set; }
        private const int PROBABILITY_ONE = 0x7FFFFFFF;
        private FmdObject huellaCapturada;
        private Conexion conexionBD = new Conexion();

        public string BoletaVerificada { get; private set; }


        public Verification()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;

        }

        private void Verification_Load(object sender, EventArgs e)
        {
            if (_sender != null)
            {
                _sender.OpenReader();
                _sender.StartCaptureAsync(OnCaptured);
                SendMessage("Pon un dedo en el lector.");
            }

        }

        private void Verification_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (_sender != null)
            {
                _sender.CancelCaptureAndCloseReader(OnCaptured);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (huellaCapturada == null)
            {
                MessageBox.Show("Primero debes capturar una huella.");
                return;
            }
            using (var conn = conexionBD.Conectar())
            {
                string query = "SELECT Boleta, Nombre, A_Paterno, A_Materno, Telefono, Huella_Dactilar FROM alumno";
                using (var cmd = new MySqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string boleta = reader["Boleta"].ToString();
                        string nombre = reader["Nombre"].ToString();
                        string apaterno = reader["A_Paterno"].ToString();
                        string amaterno = reader["A_Materno"].ToString();
                        string telefono = reader["Telefono"].ToString();
                        string huellaXML = reader["Huella_Dactilar"].ToString(); // XML como string

                        try
                        {
                            FmdObject huellaGuardada = FmdObject.DeserializeXml(huellaXML);

                            CompareResult result = Comparison.Compare(huellaCapturada, 0, huellaGuardada, 0);
                            if (result.ResultCode == Constants.ResultCode.DP_SUCCESS && result.Score < (PROBABILITY_ONE / 1000))
                            {
                                MessageBox.Show(
                                $"✅ Huella verificada.\nBoleta: {boleta}\nNombre: {nombre} {apaterno} {amaterno}\nTel: {telefono}",
                                "Verificación exitosa",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information
);


                                BoletaVerificada = boleta;                // Guarda la boleta
                                this.DialogResult = DialogResult.OK;       // Permite a ShowDialog() retornar OK
                                this.Close();                              // Cierra el formulario
                                return;
                            }

                        }
                        catch
                        {
                            SendMessage("Pon un dedo en el lector.");
                            continue;
                        }
                    }
                }
            }

            MessageBox.Show("❌ Huella no encontrada.");
            SendMessage("Pon un dedo en el lector.");
        }

        private void OnCaptured(CaptureResult captureResult)
        {
            try
            {
                if (!_sender.CheckCaptureResult(captureResult))
                    return;

                SendMessage("Huella capturada.");

                var result = FeatureExtraction.CreateFmdFromFid(captureResult.Data, FmdFormat.ANSI);
                if (result.ResultCode == Constants.ResultCode.DP_SUCCESS)
                {
                    huellaCapturada = result.Data;
                }
                else
                {
                    SendMessage("Error durante la captura:\n\n");
                    System.Threading.Thread.Sleep(1500); // Espera 1.5 segundos
                    SendMessage("Pon un dedo en el lector.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error durante la captura: " + ex.Message);
            }
        }

        private void SendMessage(string message)
        {
            if (txtVerify.InvokeRequired)
            {
                txtVerify.Invoke(new Action(() => txtVerify.Text = message));
            }
            else
            {
                txtVerify.Text = message;
            }
        }

    }
}
