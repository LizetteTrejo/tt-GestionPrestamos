﻿using System;
using System.Text;
using System.Windows.Forms;
using DPUruNet;
using MySql.Data.MySqlClient;

namespace UareUSampleCSharp
{
    public partial class Login : Form
    {
        public Form_Main _sender;
        private Fmd huellaCapturada;

        public Login()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;

        }


        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void lbllogin_Click(object sender, EventArgs e)
        {

        }

        private void lblleerhuella_Click(object sender, EventArgs e)
        {

        }
    }
}