﻿using System.Drawing;

namespace UareUSampleCSharp
{
    partial class Form_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }



        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.btnConfig = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnVerify = new System.Windows.Forms.Button();
            this.txtReaderSelected = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnAdmin = new System.Windows.Forms.Button();
            this.btnreportes = new System.Windows.Forms.Button();
            this.btnmaterial = new System.Windows.Forms.Button();
            this.btnlibros = new System.Windows.Forms.Button();
            this.btnusuarios = new System.Windows.Forms.Button();
            this.btnprestamos = new System.Windows.Forms.Button();
            this.btninicio = new System.Windows.Forms.Button();
            this.btndevoluciones = new System.Windows.Forms.Button();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.flowLayoutPanel1.Controls.Add(this.label2);
            this.flowLayoutPanel1.Controls.Add(this.btnConfig);
            this.flowLayoutPanel1.Controls.Add(this.label1);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(294, -3);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(750, 79);
            this.flowLayoutPanel1.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(20, 40);
            this.label2.Margin = new System.Windows.Forms.Padding(20, 40, 3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(311, 22);
            this.label2.TabIndex = 0;
            this.label2.Text = "Gestión de préstamos de biblioteca";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnConfig
            // 
            this.btnConfig.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(111)))), ((int)(((byte)(159)))));
            this.btnConfig.FlatAppearance.BorderSize = 0;
            this.btnConfig.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfig.Image = global::LectorPrueba.Properties.Resources.config;
            this.btnConfig.Location = new System.Drawing.Point(693, 3);
            this.btnConfig.Margin = new System.Windows.Forms.Padding(359, 3, 3, 3);
            this.btnConfig.Name = "btnConfig";
            this.btnConfig.Size = new System.Drawing.Size(54, 47);
            this.btnConfig.TabIndex = 27;
            this.btnConfig.UseVisualStyleBackColor = false;
            this.btnConfig.Click += new System.EventHandler(this.btnConfig_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(20, 102);
            this.label1.Margin = new System.Windows.Forms.Padding(20, 40, 3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(311, 22);
            this.label1.TabIndex = 28;
            this.label1.Text = "Gestión de préstamos de biblioteca";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.flowLayoutPanel3.Controls.Add(this.label4);
            this.flowLayoutPanel3.Location = new System.Drawing.Point(294, 73);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(750, 70);
            this.flowLayoutPanel3.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(20, 20);
            this.label4.Margin = new System.Windows.Forms.Padding(20, 20, 3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(144, 29);
            this.label4.TabIndex = 0;
            this.label4.Text = "label Fecha";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(294, 143);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(750, 490);
            this.panel1.TabIndex = 26;
            // 
            // btnVerify
            // 
            this.btnVerify.BackColor = System.Drawing.Color.White;
            this.btnVerify.Enabled = false;
            this.btnVerify.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.btnVerify.ForeColor = System.Drawing.Color.Black;
            this.btnVerify.Location = new System.Drawing.Point(85, 82);
            this.btnVerify.Name = "btnVerify";
            this.btnVerify.Size = new System.Drawing.Size(105, 28);
            this.btnVerify.TabIndex = 11;
            this.btnVerify.Text = "IDENTIFICAR";
            this.btnVerify.UseVisualStyleBackColor = false;
            this.btnVerify.Click += new System.EventHandler(this.btnVerify_Click);
            // 
            // txtReaderSelected
            // 
            this.txtReaderSelected.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(111)))), ((int)(((byte)(159)))));
            this.txtReaderSelected.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtReaderSelected.Enabled = false;
            this.txtReaderSelected.Font = new System.Drawing.Font("Arial", 8F);
            this.txtReaderSelected.ForeColor = System.Drawing.Color.Transparent;
            this.txtReaderSelected.Location = new System.Drawing.Point(12, 38);
            this.txtReaderSelected.Name = "txtReaderSelected";
            this.txtReaderSelected.ReadOnly = true;
            this.txtReaderSelected.Size = new System.Drawing.Size(258, 13);
            this.txtReaderSelected.TabIndex = 7;
            this.txtReaderSelected.Text = "No se a seleccionado lector de huella";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(8, 13);
            this.label6.Margin = new System.Windows.Forms.Padding(20, 40, 3, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(166, 22);
            this.label6.TabIndex = 1;
            this.label6.Text = "Lector de huella:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSalir
            // 
            this.btnSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnSalir.FlatAppearance.BorderSize = 0;
            this.btnSalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalir.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.ForeColor = System.Drawing.Color.White;
            this.btnSalir.Image = global::LectorPrueba.Properties.Resources.exit;
            this.btnSalir.Location = new System.Drawing.Point(0, 586);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.btnSalir.MaximumSize = new System.Drawing.Size(294, 45);
            this.btnSalir.MinimumSize = new System.Drawing.Size(294, 45);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Padding = new System.Windows.Forms.Padding(24, 0, 0, 0);
            this.btnSalir.Size = new System.Drawing.Size(294, 45);
            this.btnSalir.TabIndex = 28;
            this.btnSalir.Text = "   Salir";
            this.btnSalir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSalir.UseVisualStyleBackColor = false;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnAdmin
            // 
            this.btnAdmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnAdmin.FlatAppearance.BorderSize = 0;
            this.btnAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdmin.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdmin.ForeColor = System.Drawing.Color.White;
            this.btnAdmin.Image = global::LectorPrueba.Properties.Resources.admin;
            this.btnAdmin.Location = new System.Drawing.Point(0, 532);
            this.btnAdmin.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.btnAdmin.MaximumSize = new System.Drawing.Size(294, 45);
            this.btnAdmin.MinimumSize = new System.Drawing.Size(294, 45);
            this.btnAdmin.Name = "btnAdmin";
            this.btnAdmin.Padding = new System.Windows.Forms.Padding(24, 0, 0, 0);
            this.btnAdmin.Size = new System.Drawing.Size(294, 45);
            this.btnAdmin.TabIndex = 27;
            this.btnAdmin.Text = "   Admins";
            this.btnAdmin.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAdmin.UseVisualStyleBackColor = false;
            this.btnAdmin.Click += new System.EventHandler(this.btnAdmin_Click);
            // 
            // btnreportes
            // 
            this.btnreportes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnreportes.FlatAppearance.BorderSize = 0;
            this.btnreportes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnreportes.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreportes.ForeColor = System.Drawing.Color.White;
            this.btnreportes.Image = global::LectorPrueba.Properties.Resources.report;
            this.btnreportes.Location = new System.Drawing.Point(0, 477);
            this.btnreportes.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.btnreportes.MaximumSize = new System.Drawing.Size(294, 45);
            this.btnreportes.MinimumSize = new System.Drawing.Size(294, 45);
            this.btnreportes.Name = "btnreportes";
            this.btnreportes.Padding = new System.Windows.Forms.Padding(24, 0, 0, 0);
            this.btnreportes.Size = new System.Drawing.Size(294, 45);
            this.btnreportes.TabIndex = 25;
            this.btnreportes.Text = "   Reportes";
            this.btnreportes.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnreportes.UseVisualStyleBackColor = false;
            this.btnreportes.Click += new System.EventHandler(this.btnreportes_Click);
            // 
            // btnmaterial
            // 
            this.btnmaterial.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnmaterial.FlatAppearance.BorderSize = 0;
            this.btnmaterial.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnmaterial.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmaterial.ForeColor = System.Drawing.Color.White;
            this.btnmaterial.Image = global::LectorPrueba.Properties.Resources.material;
            this.btnmaterial.Location = new System.Drawing.Point(0, 421);
            this.btnmaterial.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.btnmaterial.MaximumSize = new System.Drawing.Size(294, 45);
            this.btnmaterial.MinimumSize = new System.Drawing.Size(294, 45);
            this.btnmaterial.Name = "btnmaterial";
            this.btnmaterial.Padding = new System.Windows.Forms.Padding(24, 0, 0, 0);
            this.btnmaterial.Size = new System.Drawing.Size(294, 45);
            this.btnmaterial.TabIndex = 24;
            this.btnmaterial.Text = "   Material";
            this.btnmaterial.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnmaterial.UseVisualStyleBackColor = false;
            this.btnmaterial.Click += new System.EventHandler(this.btnmaterial_Click);
            // 
            // btnlibros
            // 
            this.btnlibros.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnlibros.FlatAppearance.BorderSize = 0;
            this.btnlibros.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlibros.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlibros.ForeColor = System.Drawing.Color.White;
            this.btnlibros.Image = global::LectorPrueba.Properties.Resources.book;
            this.btnlibros.Location = new System.Drawing.Point(0, 365);
            this.btnlibros.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.btnlibros.MaximumSize = new System.Drawing.Size(294, 45);
            this.btnlibros.MinimumSize = new System.Drawing.Size(294, 45);
            this.btnlibros.Name = "btnlibros";
            this.btnlibros.Padding = new System.Windows.Forms.Padding(19, 0, 0, 0);
            this.btnlibros.Size = new System.Drawing.Size(294, 45);
            this.btnlibros.TabIndex = 23;
            this.btnlibros.Text = "   Libros";
            this.btnlibros.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnlibros.UseVisualStyleBackColor = false;
            this.btnlibros.Click += new System.EventHandler(this.btnlibros_Click);
            // 
            // btnusuarios
            // 
            this.btnusuarios.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnusuarios.FlatAppearance.BorderSize = 0;
            this.btnusuarios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnusuarios.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnusuarios.ForeColor = System.Drawing.Color.White;
            this.btnusuarios.Image = global::LectorPrueba.Properties.Resources.user;
            this.btnusuarios.Location = new System.Drawing.Point(0, 309);
            this.btnusuarios.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.btnusuarios.MaximumSize = new System.Drawing.Size(294, 45);
            this.btnusuarios.MinimumSize = new System.Drawing.Size(294, 45);
            this.btnusuarios.Name = "btnusuarios";
            this.btnusuarios.Padding = new System.Windows.Forms.Padding(26, 0, 0, 0);
            this.btnusuarios.Size = new System.Drawing.Size(294, 45);
            this.btnusuarios.TabIndex = 22;
            this.btnusuarios.Text = "   Usuarios";
            this.btnusuarios.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnusuarios.UseVisualStyleBackColor = false;
            this.btnusuarios.Click += new System.EventHandler(this.btnusuarios_Click);
            // 
            // btnprestamos
            // 
            this.btnprestamos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnprestamos.FlatAppearance.BorderSize = 0;
            this.btnprestamos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnprestamos.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprestamos.ForeColor = System.Drawing.Color.White;
            this.btnprestamos.Image = global::LectorPrueba.Properties.Resources.calendarminus;
            this.btnprestamos.Location = new System.Drawing.Point(0, 197);
            this.btnprestamos.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.btnprestamos.MaximumSize = new System.Drawing.Size(294, 45);
            this.btnprestamos.MinimumSize = new System.Drawing.Size(294, 45);
            this.btnprestamos.Name = "btnprestamos";
            this.btnprestamos.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.btnprestamos.Size = new System.Drawing.Size(294, 45);
            this.btnprestamos.TabIndex = 21;
            this.btnprestamos.Text = "   Préstamos";
            this.btnprestamos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnprestamos.UseVisualStyleBackColor = false;
            this.btnprestamos.Click += new System.EventHandler(this.btnprestamos_Click);
            // 
            // btninicio
            // 
            this.btninicio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btninicio.FlatAppearance.BorderSize = 0;
            this.btninicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btninicio.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninicio.ForeColor = System.Drawing.Color.White;
            this.btninicio.Image = global::LectorPrueba.Properties.Resources.home;
            this.btninicio.Location = new System.Drawing.Point(0, 143);
            this.btninicio.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.btninicio.MaximumSize = new System.Drawing.Size(294, 45);
            this.btninicio.MinimumSize = new System.Drawing.Size(294, 45);
            this.btninicio.Name = "btninicio";
            this.btninicio.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btninicio.Size = new System.Drawing.Size(294, 45);
            this.btninicio.TabIndex = 20;
            this.btninicio.Text = "   Inicio";
            this.btninicio.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btninicio.UseVisualStyleBackColor = false;
            this.btninicio.Click += new System.EventHandler(this.btninicio_Click);
            // 
            // btndevoluciones
            // 
            this.btndevoluciones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btndevoluciones.FlatAppearance.BorderSize = 0;
            this.btndevoluciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndevoluciones.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndevoluciones.ForeColor = System.Drawing.Color.White;
            this.btndevoluciones.Image = global::LectorPrueba.Properties.Resources.calendarplus;
            this.btndevoluciones.Location = new System.Drawing.Point(0, 253);
            this.btndevoluciones.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.btndevoluciones.MaximumSize = new System.Drawing.Size(294, 45);
            this.btndevoluciones.MinimumSize = new System.Drawing.Size(294, 45);
            this.btndevoluciones.Name = "btndevoluciones";
            this.btndevoluciones.Padding = new System.Windows.Forms.Padding(38, 0, 0, 0);
            this.btndevoluciones.Size = new System.Drawing.Size(294, 45);
            this.btndevoluciones.TabIndex = 2;
            this.btndevoluciones.Text = "   Devoluciones";
            this.btndevoluciones.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btndevoluciones.UseVisualStyleBackColor = false;
            this.btndevoluciones.Click += new System.EventHandler(this.btndevoluciones_Click);
            // 
            // Form_Main
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(111)))), ((int)(((byte)(159)))));
            this.ClientSize = new System.Drawing.Size(1044, 631);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnAdmin);
            this.Controls.Add(this.txtReaderSelected);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnreportes);
            this.Controls.Add(this.btnmaterial);
            this.Controls.Add(this.btnlibros);
            this.Controls.Add(this.btnusuarios);
            this.Controls.Add(this.btnprestamos);
            this.Controls.Add(this.btninicio);
            this.Controls.Add(this.btndevoluciones);
            this.Controls.Add(this.flowLayoutPanel3);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.btnVerify);
            this.Font = new System.Drawing.Font("Bauhaus 93", 14.25F);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1060, 670);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1060, 670);
            this.Name = "Form_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "TT A135";
            this.Load += new System.EventHandler(this.Form_Main_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btndevoluciones;
        private System.Windows.Forms.Button btninicio;
        private System.Windows.Forms.Button btnprestamos;
        private System.Windows.Forms.Button btnusuarios;
        private System.Windows.Forms.Button btnlibros;
        private System.Windows.Forms.Button btnmaterial;
        private System.Windows.Forms.Button btnreportes;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnConfig;
        internal System.Windows.Forms.Button btnVerify;
        internal System.Windows.Forms.TextBox txtReaderSelected;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnAdmin;
        private System.Windows.Forms.Button btnSalir;
    }
}