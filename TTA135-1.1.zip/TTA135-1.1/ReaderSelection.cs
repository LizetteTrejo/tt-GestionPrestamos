﻿using System;
using System.Windows.Forms;
using DPUruNet;

namespace UareUSampleCSharp
{
    public partial class ReaderSelection : Form
    {
        private ReaderCollection _readers;

        // 👉 Referencia opcional al formulario principal si se necesita
        public Form_Main Sender { get; set; }

        // 👉 Lector seleccionado (usado por Login o cualquier otro form)
        public Reader SelectedReader { get; private set; }

        public ReaderSelection()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void ReaderSelection_Load(object sender, EventArgs e)
        {
            btnRefresh_Click(this, new EventArgs());
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            cboReaders.Text = string.Empty;
            cboReaders.Items.Clear();
            cboReaders.SelectedIndex = -1;

            try
            {
                _readers = ReaderCollection.GetReaders();

                foreach (Reader reader in _readers)
                {
                    cboReaders.Items.Add(reader.Description.Name);
                }

                if (cboReaders.Items.Count > 0)
                {
                    cboReaders.SelectedIndex = 0;
                    btnSelect.Enabled = true;
                }
                else
                {
                    btnSelect.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message + "\r\n\r\nAsegúrate de que el servicio de DigitalPersona esté activo.",
                    "No se pudo acceder a los lectores");
            }
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (_readers != null && cboReaders.SelectedIndex >= 0)
            {
                SelectedReader = _readers[cboReaders.SelectedIndex];

                // Si el formulario padre necesita el lector directamente (opcional)
                if (Sender != null)
                {
                    if (Sender.CurrentReader != null)
                    {
                        Sender.CurrentReader.Dispose();
                    }

                    Sender.CurrentReader = SelectedReader;
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

