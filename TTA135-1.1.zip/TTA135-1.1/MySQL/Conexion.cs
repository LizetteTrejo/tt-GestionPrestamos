﻿using MySql.Data.MySqlClient;

namespace LectorPrueba.MySQL
{
    public class Conexion
    {
        private MySqlConnection connection;

        // Este método es accesible desde cualquier parte
        public MySqlConnection Conectar()
        {
            connection = new MySqlConnection("Server=btgeigrnuorucipfwo9e-mysql.services.clever-cloud.com;Database=btgeigrnuorucipfwo9e;Uid=uyhwmbjt7kckz5pe;Pwd=4qSjVtSWahZyrMdbqNJU;");
            connection.Open();
            return connection;
        }
    }
}
