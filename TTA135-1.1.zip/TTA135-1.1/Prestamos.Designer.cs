﻿using System.Windows.Forms;

namespace UareUSampleCSharp
{
    partial class Prestamos
    {
        private System.ComponentModel.IContainer components = null;



        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnHuella = new System.Windows.Forms.Button();
            this.btnPrestamo = new System.Windows.Forms.Button();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.lblFechaInicio = new System.Windows.Forms.Label();
            this.lblFechaFinal = new System.Windows.Forms.Label();
            this.lblDiasTotales = new System.Windows.Forms.Label();
            this.cmbTipoRecurso = new System.Windows.Forms.ComboBox();
            this.tablaRecursos = new System.Windows.Forms.DataGridView();
            this.txtBuscar = new System.Windows.Forms.TextBox();
            this.lblSeleccionRecurso = new System.Windows.Forms.Label();
            this.DatosAlumno = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tablaRecursos)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(24, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 29);
            this.label3.TabIndex = 0;
            this.label3.Text = "Préstamos";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(25, 290);
            this.label5.Margin = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(189, 19);
            this.label5.TabIndex = 3;
            this.label5.Text = "Elige Fecha Devolucion";
            // 
            // btnHuella
            // 
            this.btnHuella.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(150)))), ((int)(((byte)(218)))));
            this.btnHuella.FlatAppearance.BorderSize = 0;
            this.btnHuella.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHuella.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHuella.ForeColor = System.Drawing.Color.White;
            this.btnHuella.Location = new System.Drawing.Point(539, 402);
            this.btnHuella.Name = "btnHuella";
            this.btnHuella.Size = new System.Drawing.Size(191, 32);
            this.btnHuella.TabIndex = 5;
            this.btnHuella.Text = "Solicitar huella dactilar";
            this.btnHuella.UseVisualStyleBackColor = false;
            this.btnHuella.Click += new System.EventHandler(this.btnHuella_Click);
            // 
            // btnPrestamo
            // 
            this.btnPrestamo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(111)))), ((int)(((byte)(159)))));
            this.btnPrestamo.FlatAppearance.BorderSize = 0;
            this.btnPrestamo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrestamo.Font = new System.Drawing.Font("Arial", 14.25F);
            this.btnPrestamo.ForeColor = System.Drawing.Color.White;
            this.btnPrestamo.Location = new System.Drawing.Point(539, 447);
            this.btnPrestamo.Name = "btnPrestamo";
            this.btnPrestamo.Size = new System.Drawing.Size(191, 32);
            this.btnPrestamo.TabIndex = 6;
            this.btnPrestamo.Text = "Realizar préstamo";
            this.btnPrestamo.UseVisualStyleBackColor = false;
            this.btnPrestamo.Click += new System.EventHandler(this.btnPrestamo_Click);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(29, 309);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 7;
            // 
            // lblFechaInicio
            // 
            this.lblFechaInicio.AccessibleName = "";
            this.lblFechaInicio.AutoSize = true;
            this.lblFechaInicio.Font = new System.Drawing.Font("Arial", 12F);
            this.lblFechaInicio.Location = new System.Drawing.Point(277, 309);
            this.lblFechaInicio.Name = "lblFechaInicio";
            this.lblFechaInicio.Size = new System.Drawing.Size(88, 18);
            this.lblFechaInicio.TabIndex = 8;
            this.lblFechaInicio.Text = "FechaInicio";
            // 
            // lblFechaFinal
            // 
            this.lblFechaFinal.AutoSize = true;
            this.lblFechaFinal.Font = new System.Drawing.Font("Arial", 12F);
            this.lblFechaFinal.Location = new System.Drawing.Point(277, 341);
            this.lblFechaFinal.Name = "lblFechaFinal";
            this.lblFechaFinal.Size = new System.Drawing.Size(86, 18);
            this.lblFechaFinal.TabIndex = 9;
            this.lblFechaFinal.Text = "FechaFinal";
            // 
            // lblDiasTotales
            // 
            this.lblDiasTotales.AutoSize = true;
            this.lblDiasTotales.Font = new System.Drawing.Font("Arial", 12F);
            this.lblDiasTotales.Location = new System.Drawing.Point(277, 372);
            this.lblDiasTotales.Name = "lblDiasTotales";
            this.lblDiasTotales.Size = new System.Drawing.Size(90, 18);
            this.lblDiasTotales.TabIndex = 10;
            this.lblDiasTotales.Text = "DiasTotales";
            // 
            // cmbTipoRecurso
            // 
            this.cmbTipoRecurso.Font = new System.Drawing.Font("Arial", 12F);
            this.cmbTipoRecurso.FormattingEnabled = true;
            this.cmbTipoRecurso.Location = new System.Drawing.Point(29, 63);
            this.cmbTipoRecurso.Name = "cmbTipoRecurso";
            this.cmbTipoRecurso.Size = new System.Drawing.Size(121, 26);
            this.cmbTipoRecurso.TabIndex = 11;
            // 
            // tablaRecursos
            // 
            this.tablaRecursos.BackgroundColor = System.Drawing.Color.White;
            this.tablaRecursos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tablaRecursos.GridColor = System.Drawing.Color.White;
            this.tablaRecursos.Location = new System.Drawing.Point(29, 95);
            this.tablaRecursos.Name = "tablaRecursos";
            this.tablaRecursos.Size = new System.Drawing.Size(701, 183);
            this.tablaRecursos.TabIndex = 12;
            // 
            // txtBuscar
            // 
            this.txtBuscar.Font = new System.Drawing.Font("Arial", 14.25F);
            this.txtBuscar.Location = new System.Drawing.Point(171, 60);
            this.txtBuscar.Name = "txtBuscar";
            this.txtBuscar.Size = new System.Drawing.Size(559, 29);
            this.txtBuscar.TabIndex = 13;
            // 
            // lblSeleccionRecurso
            // 
            this.lblSeleccionRecurso.AutoSize = true;
            this.lblSeleccionRecurso.Font = new System.Drawing.Font("Arial", 10F);
            this.lblSeleccionRecurso.Location = new System.Drawing.Point(277, 284);
            this.lblSeleccionRecurso.Name = "lblSeleccionRecurso";
            this.lblSeleccionRecurso.Size = new System.Drawing.Size(119, 16);
            this.lblSeleccionRecurso.TabIndex = 14;
            this.lblSeleccionRecurso.Text = "LIBRO/MATERIAL";
            // 
            // DatosAlumno
            // 
            this.DatosAlumno.AutoSize = true;
            this.DatosAlumno.Font = new System.Drawing.Font("Arial", 10F);
            this.DatosAlumno.Location = new System.Drawing.Point(277, 402);
            this.DatosAlumno.Name = "DatosAlumno";
            this.DatosAlumno.Size = new System.Drawing.Size(91, 16);
            this.DatosAlumno.TabIndex = 15;
            this.DatosAlumno.Text = "DatosAlumno";
            // 
            // Prestamos
            // 
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(754, 491);
            this.Controls.Add(this.DatosAlumno);
            this.Controls.Add(this.lblSeleccionRecurso);
            this.Controls.Add(this.txtBuscar);
            this.Controls.Add(this.tablaRecursos);
            this.Controls.Add(this.cmbTipoRecurso);
            this.Controls.Add(this.lblDiasTotales);
            this.Controls.Add(this.lblFechaFinal);
            this.Controls.Add(this.lblFechaInicio);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.btnPrestamo);
            this.Controls.Add(this.btnHuella);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.MaximumSize = new System.Drawing.Size(770, 530);
            this.MinimumSize = new System.Drawing.Size(770, 530);
            this.Name = "Prestamos";
            this.Load += new System.EventHandler(this.Prestamos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tablaRecursos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label5;
        private Button btnHuella;
        private Button btnPrestamo;
        private MonthCalendar monthCalendar1;
        private Label lblFechaInicio;
        private Label lblFechaFinal;
        private Label lblDiasTotales;
        private ComboBox cmbTipoRecurso;
        private DataGridView tablaRecursos;
        private TextBox txtBuscar;
        private Label lblSeleccionRecurso;
        private Label DatosAlumno;
    }
}
