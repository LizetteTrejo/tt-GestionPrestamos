﻿using System;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DPUruNet;
using LectorPrueba.MySQL;
using MySql.Data.MySqlClient;

namespace UareUSampleCSharp
{
    public partial class Reportes : Form
    {
        public Form_Main _sender;
        private Conexion conexionBD = new Conexion();

        public Reportes()
        {
            InitializeComponent();
            this.Load += Reportes_Load; // <-- esto es clave
            // Configurar apariencia del DataGridView
            tableReportes.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(14, 150, 218);
            tableReportes.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            tableReportes.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12, FontStyle.Bold);
            tableReportes.DefaultCellStyle.Font = new Font("Arial", 12, FontStyle.Regular);
        }

        private void Reportes_Load(object sender, EventArgs e)
        {
            ActualizarEstadosPrestamos();
            ConfigurarDataGridView();
            BuscarPrestamosPorBoleta(""); // Cargar todos los préstamos al inicio
            tableReportes.RowPrePaint += tableReportes_RowPrePaint;

        }

        private void ConfigurarDataGridView()
        {
            tableReportes.RowHeadersVisible = false;
            tableReportes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            tableReportes.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tableReportes.MultiSelect = false;
            tableReportes.ReadOnly = true;
            tableReportes.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12F, FontStyle.Bold);
            tableReportes.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(14, 150, 218);
            tableReportes.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            tableReportes.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; // 👈 ALINEACIÓN CENTRADA
            tableReportes.EnableHeadersVisualStyles = false;
            tableReportes.DefaultCellStyle.Font = new Font("Arial", 11F, FontStyle.Regular);
            tableReportes.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tableReportes.RowTemplate.Height = 28;
            tableReportes.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            tableReportes.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 240, 240);
            tableReportes.AlternatingRowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            this.tableReportes.BorderStyle = BorderStyle.None;

        }
        private void tableReportes_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            var row = tableReportes.Rows[e.RowIndex];

            if (row.Cells["Estado"].Value == null)
                return;

            string estado = row.Cells["Estado"].Value.ToString();

            DataGridViewCell celdaEstado = row.Cells["Estado"];

            if (estado == "Devuelto")
            {
                celdaEstado.Style.BackColor = Color.LightBlue; // Azul
                return;
            }

            if (estado == "Atrasado")
            {
                celdaEstado.Style.BackColor = Color.LightCoral; // Rojo
                return;
            }

            if (estado == "Por vencer")
            {
                celdaEstado.Style.BackColor = Color.Khaki; // Amarillo
                return;
            }

            if (estado == "Activo")
            {
                if (row.Cells["Entrada"].Value == null)
                    return;

                DateTime fechaLimite;
                if (DateTime.TryParse(row.Cells["Entrada"].Value.ToString(), out fechaLimite))
                {
                    TimeSpan diferencia = fechaLimite.Date - DateTime.Today;

                    if (diferencia.TotalDays < 0)
                    {
                        celdaEstado.Style.BackColor = Color.LightCoral; // Rojo: vencido
                    }
                    else if (diferencia.TotalDays <= 2)
                    {
                        celdaEstado.Style.BackColor = Color.Khaki; // Amarillo: próximo a vencer
                    }
                    else
                    {
                        celdaEstado.Style.BackColor = Color.LightGreen; // Verde: normal
                    }
                }
            }
        }



        private void CheckTipo_CheckedChanged(object sender, EventArgs e)
        {
            // Desactivar los otros si uno se activa
            if (sender == checkLibro && checkLibro.Checked)
            {
                checkMaterial.Checked = false;
                checkAmbos.Checked = false;
            }
            else if (sender == checkMaterial && checkMaterial.Checked)
            {
                checkLibro.Checked = false;
                checkAmbos.Checked = false;
            }
            else if (sender == checkAmbos && checkAmbos.Checked)
            {
                checkLibro.Checked = false;
                checkMaterial.Checked = false;
            }

            BuscarPrestamosPorBoleta(txtBoletaUsuario.Text.Trim());
        }



        private void BuscarPrestamosPorBoleta(string boletaParcial)
        {
            StringBuilder query = new StringBuilder();

            if (checkLibro.Checked || checkAmbos.Checked)
            {
                query.Append(@"
    SELECT p.Boleta, pl.ISBN AS Recurso, l.Titulo AS Nombre_Recurso, 
           p.Fecha_Prestamo AS 'Salida', p.Fecha_Devolucion AS 'Entrada', 
           p.Estado, 'Libro' AS Tipo
    FROM prestamo p
    JOIN prestamo_libro pl ON p.ID_Prestamo = pl.ID_Prestamo
    JOIN libro l ON pl.ISBN = l.ISBN
    WHERE CAST(p.Boleta AS CHAR) LIKE @boleta");
            }

            if (checkMaterial.Checked || checkAmbos.Checked)
            {
                if (query.Length > 0)
                    query.Append(" UNION ALL ");

                query.Append(@"
    SELECT p.Boleta, pm.ID_Material AS Recurso, m.Nombre AS Nombre_Recurso, 
           p.Fecha_Prestamo AS 'Salida', p.Fecha_Devolucion AS 'Entrada', 
           p.Estado, 'Material' AS Tipo
    FROM prestamo p
    JOIN prestamo_material pm ON p.ID_Prestamo = pm.ID_Prestamo
    JOIN material m ON pm.ID_Material = m.ID
    WHERE CAST(p.Boleta AS CHAR) LIKE @boleta");
            }

            try
            {
                using (var conn = conexionBD.Conectar()) // 🔵 Usamos tu clase Conexion
                {
                    MySqlCommand cmd = new MySqlCommand(query.ToString(), conn);
                    cmd.Parameters.AddWithValue("@boleta", "%" + boletaParcial + "%");
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    tableReportes.DataSource = dt;

                    // Ajustar las columnas
                    if (tableReportes.Columns.Contains("Tipo"))
                        tableReportes.Columns["Tipo"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

                    if (tableReportes.Columns.Contains("Boleta"))
                    {
                        tableReportes.Columns["Boleta"].DisplayIndex = 0;
                        tableReportes.Columns["Boleta"].Width = 90;
                    }

                    if (tableReportes.Columns.Contains("Nombre_Recurso"))
                    {
                        tableReportes.Columns["Nombre_Recurso"].DisplayIndex = 1;
                        tableReportes.Columns["Nombre_Recurso"].Width = 150;
                    }

                    if (tableReportes.Columns.Contains("Recurso"))
                    {
                        tableReportes.Columns["Recurso"].HeaderText = "ID o ISBN";
                        tableReportes.Columns["Recurso"].DisplayIndex = 2;
                        tableReportes.Columns["Recurso"].Width = 120;
                    }

                    if (tableReportes.Columns.Contains("Salida"))
                    {
                        tableReportes.Columns["Salida"].DisplayIndex = 3;
                        tableReportes.Columns["Salida"].Width = 100;
                    }

                    if (tableReportes.Columns.Contains("Entrada"))
                    {
                        tableReportes.Columns["Entrada"].HeaderText = "Devolucion";
                        tableReportes.Columns["Entrada"].DisplayIndex = 4;
                        tableReportes.Columns["Entrada"].Width = 100;
                    }

                    if (tableReportes.Columns.Contains("Estado"))
                    {
                        tableReportes.Columns["Estado"].DisplayIndex = 5;
                        tableReportes.Columns["Estado"].Width = 90;
                    }

                    if (tableReportes.Columns.Contains("Tipo"))
                    {
                        tableReportes.Columns["Tipo"].DisplayIndex = 6;
                        tableReportes.Columns["Tipo"].Width = 80;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener datos: " + ex.Message);
            }
        }

        private void txtBoletaUsuario_TextChanged(object sender, EventArgs e)
        {
            BuscarPrestamosPorBoleta(txtBoletaUsuario.Text.Trim());
        }
        private void ActualizarEstadosPrestamos()
        {
            try
            {
                using (var conn = conexionBD.Conectar())
                {

                    string updateAtrasados = @"
                UPDATE prestamo
                SET Estado = 'Atrasado'
                WHERE Estado = 'Activo' AND Fecha_Devolucion < CURDATE();";

                    string updatePorVencer = @"
                UPDATE prestamo
                SET Estado = 'Por vencer'
                WHERE Estado = 'Activo' AND DATEDIFF(Fecha_Devolucion, CURDATE()) BETWEEN 0 AND 3;";

                    using (var cmdAtrasado = new MySqlCommand(updateAtrasados, conn))
                    {
                        cmdAtrasado.ExecuteNonQuery();
                    }

                    using (var cmdPorVencer = new MySqlCommand(updatePorVencer, conn))
                    {
                        cmdPorVencer.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar estados: " + ex.Message);
            }
        }




    }
}

