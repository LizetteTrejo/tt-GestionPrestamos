﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using DPUruNet;
using MySql.Data.MySqlClient;

namespace UareUSampleCSharp
{
    public partial class Admin : Form
    {

        public Admin()
        {
            InitializeComponent();
            tableAdmins.RowHeadersVisible = false; // Oculta columna gris
            tableAdmins.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; // Columnas se ajustan
            tableAdmins.SelectionMode = DataGridViewSelectionMode.FullRowSelect; // Selección de fila completa
            tableAdmins.MultiSelect = false; // No permite múltiples filas seleccionadas
            tableAdmins.ReadOnly = true; // Solo lectura

            // Estilo de encabezados
            tableAdmins.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12F, FontStyle.Bold);
            tableAdmins.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(14, 150, 218);
            tableAdmins.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            tableAdmins.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tableAdmins.EnableHeadersVisualStyles = false; // Permite aplicar estilos personalizados

            // Estilo de celdas normales
            tableAdmins.DefaultCellStyle.Font = new Font("Arial", 11F, FontStyle.Regular);
            tableAdmins.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Estilo de filas
            tableAdmins.RowTemplate.Height = 28; // Altura uniforme
            tableAdmins.CellBorderStyle = DataGridViewCellBorderStyle.None; // ❌ Sin líneas entre filas

            // Estilo de filas alternadas (zebra)
            tableAdmins.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 240, 240);
            tableAdmins.AlternatingRowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;


        }

        
    }
}