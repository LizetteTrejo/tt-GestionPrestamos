﻿using System;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using DPUruNet;
using FmdObject = DPUruNet.Fmd;
using FmdFormat = DPUruNet.Constants.Formats.Fmd;
using Mysqlx;
using LectorPrueba.MySQL;

namespace UareUSampleCSharp
{
    public partial class Verification : Form
    {
        public string BoletaEsperada { get; set; } = null;
        public bool EsEdicion { get; set; } = false;

        public Form_Main _sender { get; set; }
        private const int PROBABILITY_ONE = 0x7FFFFFFF;
        private FmdObject huellaCapturada;
        private Conexion conexionBD = new Conexion();

        public string BoletaVerificada { get; private set; }


        public Verification()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;

        }

        private void Verification_Load(object sender, EventArgs e)
        {
            if (_sender != null)
            {
                _sender.OpenReader();
                _sender.StartCaptureAsync(OnCaptured);
                SendMessage("Pon un dedo en el lector.");
            }

        }

        private void Verification_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (_sender != null)
            {
                _sender.CancelCaptureAndCloseReader(OnCaptured);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (huellaCapturada == null)
            {
                MessageBox.Show("⚠️ Primero debes capturar una huella.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var conn = conexionBD.Conectar())
            using (var cmd = new MySqlCommand("SELECT Boleta, Nombre, A_Paterno, A_Materno, Telefono, Huella_Dactilar FROM alumno", conn))
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    string boleta = reader["Boleta"].ToString();
                    string nombreCompleto = $"{reader["Nombre"]} {reader["A_Paterno"]} {reader["A_Materno"]}";
                    string telefono = reader["Telefono"].ToString();
                    string huellaXML = reader["Huella_Dactilar"].ToString();

                    if (string.IsNullOrWhiteSpace(huellaXML)) continue;

                    try
                    {
                        var huellaGuardada = FmdObject.DeserializeXml(huellaXML);
                        var resultado = Comparison.Compare(huellaCapturada, 0, huellaGuardada, 0);

                        if (resultado.ResultCode == Constants.ResultCode.DP_SUCCESS &&
                            resultado.Score < (PROBABILITY_ONE / 1000))
                        {
                            // Validación si se espera una boleta específica
                            if (!string.IsNullOrEmpty(BoletaEsperada) && boleta != BoletaEsperada)
                            {
                                MessageBox.Show("❌ La huella no coincide con el alumno seleccionado.",
                                                "Acceso denegado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                SendMessage("Pon un dedo en el lector.");
                                return;
                            }


                            MessageBox.Show(
                                    $"✅ Huella verificada.\nBoleta: {boleta}\nNombre: {nombreCompleto}\nTeléfono: {telefono}",
                                    "Verificación exitosa",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                            BoletaVerificada = boleta;

                            DialogResult = DialogResult.OK;
                            Close();
                            return;
                        }
                    }
                    catch
                    {
                        SendMessage("Pon un dedo en el lector.");
                        continue;
                    }
                }
            }

            MessageBox.Show("❌ Huella no encontrada.", "Error de verificación", MessageBoxButtons.OK, MessageBoxIcon.Error);
            SendMessage("Pon un dedo en el lector.");
        }



        private void OnCaptured(CaptureResult captureResult)
        {
            try
            {
                if (!_sender.CheckCaptureResult(captureResult))
                    return;

                SendMessage("Huella capturada.");

                var result = FeatureExtraction.CreateFmdFromFid(captureResult.Data, FmdFormat.ANSI);
                if (result.ResultCode == Constants.ResultCode.DP_SUCCESS)
                {
                    huellaCapturada = result.Data;
                }
                else
                {
                    SendMessage("Error durante la captura:\n\n");
                    System.Threading.Thread.Sleep(1500); // Espera 1.5 segundos
                    SendMessage("Pon un dedo en el lector.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error durante la captura: " + ex.Message);
            }
        }

        private void SendMessage(string message)
        {
            if (txtVerify.InvokeRequired)
            {
                txtVerify.Invoke(new Action(() => txtVerify.Text = message));
            }
            else
            {
                txtVerify.Text = message;
            }
        }

    }
}
