﻿using System;
using System.Windows.Forms;
using System.Drawing;
using MySql.Data.MySqlClient;
using LectorPrueba.MySQL;
using DPUruNet;

namespace UareUSampleCSharp
{
    public partial class Admin : Form
    {
        private Login _login;

        public Admin(Login login)
        {
            InitializeComponent();
            _login = login;
            this.StartPosition = FormStartPosition.CenterScreen;
            InicializarTabla();
            RecargarAdministradores();
        }

        private void InicializarTabla()
        {
            tableAdmins.RowHeadersVisible = false;
            tableAdmins.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            tableAdmins.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tableAdmins.MultiSelect = false;
            tableAdmins.ReadOnly = true;
            tableAdmins.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12F, FontStyle.Bold);
            tableAdmins.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(14, 150, 218);
            tableAdmins.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            tableAdmins.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tableAdmins.EnableHeadersVisualStyles = false;
            tableAdmins.DefaultCellStyle.Font = new Font("Arial", 11F, FontStyle.Regular);
            tableAdmins.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tableAdmins.RowTemplate.Height = 28;
            tableAdmins.CellBorderStyle = DataGridViewCellBorderStyle.None;
            tableAdmins.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 240, 240);
            tableAdmins.AlternatingRowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void RecargarAdministradores()
        {
            tableAdmins.Rows.Clear();

            using (var conn = new Conexion().Conectar())
            {
                string query = "SELECT ID, Nombre, A_Paterno, A_Materno, Telefono FROM administrador";
                using (var cmd = new MySqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        tableAdmins.Rows.Add(
                            reader["ID"].ToString(),
                            reader["Nombre"].ToString(),
                            reader["A_Paterno"].ToString(),
                            reader["A_Materno"].ToString(),
                            reader["Telefono"].ToString()
                        );
                    }
                }
            }
        }

        private void btnNuevoAdmin_Click(object sender, EventArgs e)
        {
            if (_login.CurrentReader == null)
            {
                MessageBox.Show("⚠️ Lector no disponible. No se puede registrar un nuevo administrador.");
                return;
            }

            using (var formNuevo = new RegistroRoot(_login, null))
            {
                formNuevo.ShowDialog();
            }

            RecargarAdministradores();
        }

        private void btnEditarAdmin_Click(object sender, EventArgs e)
        {
            if (tableAdmins.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecciona un administrador para editar.", "Editar administrador", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string idSeleccionado = tableAdmins.SelectedRows[0].Cells["Column5"].Value.ToString();

            if (_login.CurrentReader == null)
            {
                MessageBox.Show("❌ No se puede editar el administrador: lector no disponible.");
                return;
            }

            using (var formEditar = new RegistroRoot(_login, idSeleccionado))
            {
                formEditar.ShowDialog();
            }

            RecargarAdministradores();
        }

        private void btnBorrarAdmin_Click(object sender, EventArgs e)
        {
            if (tableAdmins.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecciona un administrador para borrar.", "Borrar administrador", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string idSeleccionado = tableAdmins.SelectedRows[0].Cells["Column5"].Value.ToString();

            DialogResult confirm = MessageBox.Show($"¿Estás seguro de que deseas borrar al administrador con ID {idSeleccionado}?",
                                                   "Confirmar borrado",
                                                   MessageBoxButtons.YesNo,
                                                   MessageBoxIcon.Question);

            if (confirm != DialogResult.Yes)
                return;

            using (var conn = new Conexion().Conectar())
            {
                string verificarPrestamos = "SELECT COUNT(*) FROM prestamo WHERE ID_Administrador = @id";
                using (var cmdVerificar = new MySqlCommand(verificarPrestamos, conn))
                {
                    cmdVerificar.Parameters.AddWithValue("@id", idSeleccionado);
                    int prestamosAsociados = Convert.ToInt32(cmdVerificar.ExecuteScalar());

                    if (prestamosAsociados > 0)
                    {
                        MessageBox.Show("❌ No puedes eliminar este administrador porque tiene préstamos registrados.",
                                        "Acción no permitida",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Warning);
                        return;
                    }
                }

                string deleteQuery = "DELETE FROM administrador WHERE ID = @id";
                using (var cmd = new MySqlCommand(deleteQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@id", idSeleccionado);
                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Administrador eliminado correctamente.", "Borrado exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            RecargarAdministradores();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("¿Estás seguro de que deseas salir?",
                                                  "Confirmar salida",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void Admin_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                if (_login.CurrentReader != null && _login.CurrentReader.Status.Status == Constants.ReaderStatuses.DP_STATUS_BUSY)
                    _login.CurrentReader.CancelCapture();
            }
            catch { }
        }
    }
}
