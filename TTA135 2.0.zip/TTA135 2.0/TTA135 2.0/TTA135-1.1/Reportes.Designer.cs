﻿using System.Windows.Forms;

namespace UareUSampleCSharp
{
    partial class Reportes
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.CheckBox checkLibro;
        private System.Windows.Forms.CheckBox checkMaterial;
        private System.Windows.Forms.CheckBox checkAmbos;



        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBoletaUsuario = new System.Windows.Forms.TextBox();
            this.tableReportes = new System.Windows.Forms.DataGridView();
            this.checkLibro = new System.Windows.Forms.CheckBox();
            this.checkMaterial = new System.Windows.Forms.CheckBox();
            this.checkAmbos = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.tableReportes)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(24, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Reportes";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 14.25F);
            this.label2.Location = new System.Drawing.Point(26, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(166, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "Boleta del usuario:";
            // 
            // txtBoletaUsuario
            // 
            this.txtBoletaUsuario.Font = new System.Drawing.Font("Arial", 14.25F);
            this.txtBoletaUsuario.Location = new System.Drawing.Point(29, 93);
            this.txtBoletaUsuario.Name = "txtBoletaUsuario";
            this.txtBoletaUsuario.Size = new System.Drawing.Size(577, 29);
            this.txtBoletaUsuario.TabIndex = 2;
            this.txtBoletaUsuario.TextChanged += new System.EventHandler(this.txtBoletaUsuario_TextChanged);
            // 
            // tableReportes
            // 
            this.tableReportes.BackgroundColor = System.Drawing.Color.White;
            this.tableReportes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableReportes.GridColor = System.Drawing.Color.White;
            this.tableReportes.Location = new System.Drawing.Point(12, 158);
            this.tableReportes.Name = "tableReportes";
            this.tableReportes.Size = new System.Drawing.Size(730, 304);
            this.tableReportes.TabIndex = 13;
            // 
            // checkLibro
            // 
            this.checkLibro.AutoSize = true;
            this.checkLibro.Font = new System.Drawing.Font("Arial", 10F);
            this.checkLibro.Location = new System.Drawing.Point(640, 114);
            this.checkLibro.Name = "checkLibro";
            this.checkLibro.Size = new System.Drawing.Size(58, 20);
            this.checkLibro.TabIndex = 0;
            this.checkLibro.Text = "Libro";
            this.checkLibro.CheckedChanged += new System.EventHandler(this.CheckTipo_CheckedChanged);
            // 
            // checkMaterial
            // 
            this.checkMaterial.AutoSize = true;
            this.checkMaterial.Font = new System.Drawing.Font("Arial", 10F);
            this.checkMaterial.Location = new System.Drawing.Point(640, 88);
            this.checkMaterial.Name = "checkMaterial";
            this.checkMaterial.Size = new System.Drawing.Size(76, 20);
            this.checkMaterial.TabIndex = 1;
            this.checkMaterial.Text = "Material";
            this.checkMaterial.CheckedChanged += new System.EventHandler(this.CheckTipo_CheckedChanged);
            // 
            // checkAmbos
            // 
            this.checkAmbos.AutoSize = true;
            this.checkAmbos.Checked = true;
            this.checkAmbos.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkAmbos.Font = new System.Drawing.Font("Arial", 10F);
            this.checkAmbos.Location = new System.Drawing.Point(640, 62);
            this.checkAmbos.Name = "checkAmbos";
            this.checkAmbos.Size = new System.Drawing.Size(69, 20);
            this.checkAmbos.TabIndex = 2;
            this.checkAmbos.Text = "Ambos";
            this.checkAmbos.CheckedChanged += new System.EventHandler(this.CheckTipo_CheckedChanged);
            // 
            // Reportes
            // 
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(754, 491);
            this.Controls.Add(this.checkLibro);
            this.Controls.Add(this.checkMaterial);
            this.Controls.Add(this.checkAmbos);
            this.Controls.Add(this.tableReportes);
            this.Controls.Add(this.txtBoletaUsuario);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximumSize = new System.Drawing.Size(770, 530);
            this.MinimumSize = new System.Drawing.Size(770, 530);
            this.Name = "Reportes";
            ((System.ComponentModel.ISupportInitialize)(this.tableReportes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }



        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtBoletaUsuario;
        private DataGridView tableReportes;
    }
}
