﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using LectorPrueba.MySQL;
using MySql.Data.MySqlClient;

namespace LectorPrueba
{
    public partial class Multas : Form
    {
        private Conexion conexionBD = new Conexion();
        private string boletaAlumno;

        public Multas(string boleta)
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen; // Centrar el formulario

            boletaAlumno = boleta;
            txtBuscarBoleta.Text = boleta;


            CargarMultas();

            // Configuración general
            tablaMultas.RowHeadersVisible = false;
            tablaMultas.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            tablaMultas.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tablaMultas.MultiSelect = false;
            tablaMultas.ReadOnly = true;

            tablaMultas.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 12F, FontStyle.Bold);
            tablaMultas.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(14, 150, 218);
            tablaMultas.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            tablaMultas.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            tablaMultas.EnableHeadersVisualStyles = false;

            tablaMultas.DefaultCellStyle.Font = new Font("Arial", 11F, FontStyle.Regular);
            tablaMultas.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            tablaMultas.RowTemplate.Height = 28;
            tablaMultas.CellBorderStyle = DataGridViewCellBorderStyle.None;
            tablaMultas.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 240, 240);
            tablaMultas.AlternatingRowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            boletaAlumno = txtBuscarBoleta.Text.Trim();

            if (string.IsNullOrWhiteSpace(boletaAlumno))
            {
                MessageBox.Show("⚠️ Ingresa una boleta para buscar.", "Campo vacío", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            CargarMultas();
        }

        private void CargarMultas()
        {
            decimal total = 0;
            boletaAlumno = txtBuscarBoleta.Text.Trim();

            try
            {
                using (var conn = conexionBD.Conectar())
                {
                    string query = @"
                SELECT m.* 
                FROM multa m
                JOIN prestamo p ON m.ID_Prestamo = p.ID_Prestamo
                WHERE p.Boleta = @boleta
                  AND p.Estado = 'Devuelto'
                  AND m.Estado = 'Pendiente'";

                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@boleta", boletaAlumno);
                        using (var adapter = new MySqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            tablaMultas.DataSource = dt;

                            foreach (DataRow row in dt.Rows)
                            {
                                if (decimal.TryParse(row["Monto"].ToString(), out decimal monto))
                                {
                                    total += monto;
                                }
                            }

                            txtTotal.Text = total.ToString("0.00");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar multas: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void txtEfectivo_TextChanged(object sender, EventArgs e)
        {
            if (decimal.TryParse(txtEfectivo.Text, out decimal efectivo) &&
                decimal.TryParse(txtTotal.Text, out decimal totalMulta))
            {
                decimal cambio = efectivo - totalMulta;
                txtCambio.Text = cambio >= 0 ? cambio.ToString("0.00") : "0.00";
            }
            else
            {
                txtCambio.Text = "0.00";
            }
        }

        private void btnPagar_Click(object sender, EventArgs e)
        {
            if (!decimal.TryParse(txtEfectivo.Text, out decimal efectivo))
            {
                MessageBox.Show("💵 Ingresa una cantidad válida en efectivo.", "Efectivo inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(txtTotal.Text, out decimal totalMulta))
            {
                MessageBox.Show("⚠️ No se puede obtener el total de multas.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (efectivo < totalMulta)
            {
                MessageBox.Show("❌ El efectivo recibido es menor al total a pagar.", "Pago insuficiente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (tablaMultas.Rows.Count == 0)
            {
                MessageBox.Show("⚠️ No hay multas pendientes para pagar.", "Sin multas", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                using (var conn = conexionBD.Conectar())
                {
                    string updateMultas = @"
                UPDATE multa m
                JOIN prestamo p ON m.ID_Prestamo = p.ID_Prestamo
                SET m.Estado = 'Pagado'
                WHERE m.Estado = 'Pendiente' AND p.Boleta = @boleta";

                    using (var cmd = new MySqlCommand(updateMultas, conn))
                    {
                        cmd.Parameters.AddWithValue("@boleta", boletaAlumno);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("✅ Pago registrado con éxito.", "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK; // Importante para saber que se pagó
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al registrar el pago: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnCancelar_Click(object sender, EventArgs e)
        {
            var confirm = MessageBox.Show(
                "¿Seguro que deseas cancelar el pago de multas?",
                "Cancelar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm == DialogResult.Yes)
            {
                txtBuscarBoleta.Text = "";
                tablaMultas.DataSource = null;
                tablaMultas.Rows.Clear();
                txtTotal.Text = "0.00";
                txtEfectivo.Text = "";
                txtCambio.Text = "0.00";
                boletaAlumno = null;
            }
        }
    }
}
