﻿using DPUruNet;
using LectorPrueba;
using LectorPrueba.MySQL;
using MySql.Data.MySqlClient;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.Threading.Tasks;



namespace UareUSampleCSharp
{
    public partial class Form_Main : Form
    {
        private string idAdmin;
        private string nombreAdmin;
        public string IDAdmin => idAdmin;


        public Dictionary<int, Fmd> Fmds
        {
            get { return fmds; }
            set { fmds = value; }
        }
        private Dictionary<int, Fmd> fmds = new Dictionary<int, Fmd>();


        public bool Reset
        {
            get { return reset; }
            set { reset = value; }
        }
        private bool reset;

        public Form_Main(string idAdmin, string nombreAdmin)
        {
            using (Tracer tracer = new Tracer("Form_Main::Form_Main"))
            {

                InitializeComponent();
                this.idAdmin = idAdmin;
                this.nombreAdmin = nombreAdmin;

                lblidAdmin.Text = $"Admin ID: {idAdmin}"; // Ejemplo: mostrarlo en un Label
                lblNombreAdmin.Text = $"Bienvenido: {nombreAdmin}"; // Asegúrate de tener este label

                this.StartPosition = FormStartPosition.CenterScreen;

                btnVerify.Visible = false;
                txtReaderSelected.ReadOnly = true;
                txtReaderSelected.Enabled = true;
                txtReaderSelected.ForeColor = Color.White;

                string rutaIcono = Path.Combine(Application.StartupPath, "Resources", "logo.ico");
                this.Icon = new Icon(rutaIcono);

                DateTime fechaActual = DateTime.Now;
                string fechaFormateada = fechaActual.ToString("dddd, dd 'de' MMMM 'de' yyyy", new CultureInfo("es-ES"));
                fechaFormateada = char.ToUpper(fechaFormateada[0]) + fechaFormateada.Substring(1);
                label4.Text = fechaFormateada;



                // 🔽 Cargar automáticamente el formulario de inicio
                AbrirFormularioEnPanel(new Inicio());
            }
        }

        private System.Windows.Forms.Timer timerInactividad;
        private int segundosInactivos = 0;
        private const int LIMITE_INACTIVIDAD = 180;


        private async void Form_Main_Load(object sender, EventArgs e)
        {
            timerInactividad = new System.Windows.Forms.Timer();
            timerInactividad.Interval = 1000;
            timerInactividad.Tick += TimerInactividad_Tick;
            timerInactividad.Start();

            await ActualizarMontosMultasPendientes();  // <- Asegúrate de que sea await
            await GenerarMultasAtrasadas();
            await ActualizarEstadosPrestamos();

            // Detectar actividad del mouse y teclado
            this.MouseMove += ReiniciarContadorInactividad;
            this.KeyPress += ReiniciarContadorInactividad;
        }


        private void TimerInactividad_Tick(object sender, EventArgs e)
        {
            segundosInactivos++;

            if (segundosInactivos >= LIMITE_INACTIVIDAD)
            {
                timerInactividad.Stop(); // Detener el temporizador
                CerrarSesionPorInactividad();
            }
        }
        private void ReiniciarContadorInactividad(object sender, EventArgs e)
        {
            segundosInactivos = 0;
        }

        private void CerrarSesionPorInactividad()
        {
            this.Hide();
            Login loginForm = new Login();
            loginForm.ShowDialog();
            this.Close();
        }


        private async Task ActualizarMontosMultasPendientes()
        {
            try
            {
                using (var conn = new Conexion().Conectar())
                {
                    DateTime fechaHoy = DateTime.Today;

                    string query = @"
                SELECT m.ID_Prestamo, p.Fecha_Devolucion, a.Telefono,
                    COALESCE(l.Titulo, m2.Nombre) AS Recurso
                FROM multa m
                JOIN prestamo p ON m.ID_Prestamo = p.ID_Prestamo
                JOIN alumno a ON p.Boleta = a.Boleta
                LEFT JOIN prestamo_libro pl ON p.ID_Prestamo = pl.ID_Prestamo
                LEFT JOIN libro l ON pl.ISBN = l.ISBN
                LEFT JOIN prestamo_material pm ON p.ID_Prestamo = pm.ID_Prestamo
                LEFT JOIN material m2 ON pm.ID_Material = m2.ID
                WHERE m.Estado = 'Pendiente'";

                    using (var cmd = new MySqlCommand(query, conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            long idPrestamo = Convert.ToInt64(reader["ID_Prestamo"]);
                            DateTime fechaDevolucion = Convert.ToDateTime(reader["Fecha_Devolucion"]);
                            string telefono = reader["Telefono"].ToString();
                            string recurso = reader["Recurso"].ToString();

                            int diasAtraso = (fechaHoy - fechaDevolucion).Days;
                            float nuevoMonto = diasAtraso * 7f;

                            await ActualizarMontoMulta(idPrestamo, nuevoMonto);

                            string mensaje = $"⚠️ Tu préstamo del recurso \"{recurso}\" sigue generando multa. Monto actualizado: ${nuevoMonto} MXN. Evita pagar más, devuélvelo pronto.";
                            await EnviarWhatsAppSimple(telefono, mensaje);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Error al actualizar montos de multas: " + ex.Message);
            }
        }



        public Reader CurrentReader
        {
            get { return currentReader; }
            set
            {
                currentReader = value;
                SendMessage(Action.UpdateReaderState, value);
            }
        }
        private Reader currentReader;

        #region Click Event Handlers
        private ReaderSelection _readerSelection;
        private void btnReaderSelect_Click(System.Object sender, System.EventArgs e)
        {
            using (Tracer tracer = new Tracer("Form_Main::btnReaderSelect_Click"))
            {

                if (_readerSelection == null)
                {
                    _readerSelection = new ReaderSelection();
                    _readerSelection.Sender = this;
                }

                _readerSelection.ShowDialog();

                _readerSelection.Dispose();
                _readerSelection = null;
            }
        }

        private Verification _verification;
        private void btnVerify_Click(System.Object sender, System.EventArgs e)
        {
            if (_verification == null)
            {
                _verification = new Verification();
                _verification._sender = this;
            }

            _verification.ShowDialog();

            _verification.Dispose();
            _verification = null;
        }

        public bool OpenReader()
        {
            using (Tracer tracer = new Tracer("Form_Main::OpenReader"))
            {
                reset = false;
                Constants.ResultCode result = Constants.ResultCode.DP_DEVICE_FAILURE;

                // Open reader
                result = currentReader.Open(Constants.CapturePriority.DP_PRIORITY_COOPERATIVE);

                if (result != Constants.ResultCode.DP_SUCCESS)
                {
                    MessageBox.Show("Error:  " + result);
                    reset = true;
                    return false;
                }

                return true;
            }
        }
        public bool StartCaptureAsync(Reader.CaptureCallback OnCaptured)
        {
            using (Tracer tracer = new Tracer("Form_Main::StartCaptureAsync"))
            {
                // Activate capture handler
                currentReader.On_Captured += new Reader.CaptureCallback(OnCaptured);

                // Call capture
                if (!CaptureFingerAsync())
                {
                    return false;
                }

                return true;
            }
        }


        public void CancelCaptureAndCloseReader(Reader.CaptureCallback OnCaptured)
        {
            using (Tracer tracer = new Tracer("Form_Main::CancelCaptureAndCloseReader"))
            {
                if (currentReader != null)
                {
                    currentReader.CancelCapture();

                    // Dispose of reader handle and unhook reader events.
                    currentReader.Dispose();

                    if (reset)
                    {
                        CurrentReader = null;
                    }
                }
            }
        }


        public void GetStatus()
        {
            using (Tracer tracer = new Tracer("Form_Main::GetStatus"))
            {
                Constants.ResultCode result = currentReader.GetStatus();

                if ((result != Constants.ResultCode.DP_SUCCESS))
                {
                    reset = true;
                    throw new Exception("" + result);
                }

                if ((currentReader.Status.Status == Constants.ReaderStatuses.DP_STATUS_BUSY))
                {
                    Thread.Sleep(50);
                }
                else if ((currentReader.Status.Status == Constants.ReaderStatuses.DP_STATUS_NEED_CALIBRATION))
                {
                    currentReader.Calibrate();
                }
                else if ((currentReader.Status.Status != Constants.ReaderStatuses.DP_STATUS_READY))
                {
                    throw new Exception("Reader Status - " + currentReader.Status.Status);
                }
            }
        }


        public bool CheckCaptureResult(CaptureResult captureResult)
        {
            using (Tracer tracer = new Tracer("Form_Main::CheckCaptureResult"))
            {
                if (captureResult.Data == null || captureResult.ResultCode != Constants.ResultCode.DP_SUCCESS)
                {
                    if (captureResult.ResultCode != Constants.ResultCode.DP_SUCCESS)
                    {
                        reset = true;
                        throw new Exception(captureResult.ResultCode.ToString());
                    }
                    if ((captureResult.Quality != Constants.CaptureQuality.DP_QUALITY_CANCELED))
                    {
                        throw new Exception("Quality - " + captureResult.Quality);
                    }
                    return false;
                }

                return true;
            }
        }


        public bool CaptureFingerAsync()
        {
            using (Tracer tracer = new Tracer("Form_Main::CaptureFingerAsync"))
            {
                try
                {
                    GetStatus();

                    Constants.ResultCode captureResult = currentReader.CaptureAsync(Constants.Formats.Fid.ANSI, Constants.CaptureProcessing.DP_IMG_PROC_DEFAULT, currentReader.Capabilities.Resolutions[0]);
                    if (captureResult != Constants.ResultCode.DP_SUCCESS)
                    {
                        reset = true;
                        throw new Exception("" + captureResult);
                    }

                    return true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error:  " + ex.Message);
                    return false;
                }
            }
        }

        public Bitmap CreateBitmap(byte[] bytes, int width, int height)
        {
            byte[] rgbBytes = new byte[bytes.Length * 3];

            for (int i = 0; i <= bytes.Length - 1; i++)
            {
                rgbBytes[(i * 3)] = bytes[i];
                rgbBytes[(i * 3) + 1] = bytes[i];
                rgbBytes[(i * 3) + 2] = bytes[i];
            }
            Bitmap bmp = new Bitmap(width, height, PixelFormat.Format24bppRgb);

            BitmapData data = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb);

            for (int i = 0; i <= bmp.Height - 1; i++)
            {
                IntPtr p = new IntPtr(data.Scan0.ToInt64() + data.Stride * i);
                System.Runtime.InteropServices.Marshal.Copy(rgbBytes, i * bmp.Width * 3, p, bmp.Width * 3);
            }

            bmp.UnlockBits(data);

            return bmp;
        }

        #region SendMessage
        private enum Action
        {
            UpdateReaderState
        }
        private delegate void SendMessageCallback(Action state, object payload);


        private void SendMessage(Action state, object payload)
        {
            using (Tracer tracer = new Tracer("Form_Main::SendMessage"))
            {
                if (this.txtReaderSelected.InvokeRequired)
                {
                    SendMessageCallback d = new SendMessageCallback(SendMessage);
                    this.Invoke(d, new object[] { state, payload });
                }
                else
                {
                    switch (state)
                    {
                        case Action.UpdateReaderState:
                            if ((Reader)payload != null)
                            {
                                txtReaderSelected.Text = ((Reader)payload).Description.Name;
                                btnVerify.Enabled = true;
                                btnVerify.Visible = true; // <-- AÑADE ESTO AQUÍ
                            }
                            else
                            {
                                txtReaderSelected.Text = String.Empty;
                                btnVerify.Enabled = false;
                                btnVerify.Visible = false;

                            }
                            break;
                        default:
                            break;
                    }
                }
            }
        }


        private void AbrirFormularioEnPanel(object formularioHijo)
        {
            panel1.Controls.Clear(); // Limpia todo

            Form fh = formularioHijo as Form;
            fh.TopLevel = false;
            fh.FormBorderStyle = FormBorderStyle.None;
            fh.Dock = DockStyle.Fill;

            panel1.Controls.Add(fh);
            panel1.Tag = fh;
            fh.Show();
        }

        private async Task ActualizarEstadosPrestamos()
        {
            try
            {
                using (var conn = new Conexion().Conectar())
                {
                    DateTime fechaHoy = DateTime.Now.Date;

                    // 1. Actualizar estados
                    using (var updateCmd1 = new MySqlCommand(@"
                UPDATE prestamo
                SET Estado = 'Por vencer'
                WHERE Estado = 'Activo' AND DATEDIFF(Fecha_Devolucion, @fecha) BETWEEN 0 AND 3", conn))
                    {
                        updateCmd1.Parameters.AddWithValue("@fecha", fechaHoy);
                        updateCmd1.ExecuteNonQuery();
                    }

                    using (var updateCmd2 = new MySqlCommand(@"
                UPDATE prestamo
                SET Estado = 'Atrasado'
                WHERE Estado IN ('Activo', 'Por vencer') AND Fecha_Devolucion < @fecha", conn))
                    {
                        updateCmd2.Parameters.AddWithValue("@fecha", fechaHoy);
                        updateCmd2.ExecuteNonQuery();
                    }

                    // 2. Enviar mensajes solo a préstamos en estado "Por vencer"
                    string queryPorVencer = @"
                SELECT DISTINCT p.Boleta, a.Telefono, p.Fecha_Devolucion,
                                COALESCE(l.Titulo, m.Nombre) AS Recurso
                FROM prestamo p
                JOIN alumno a ON p.Boleta = a.Boleta
                LEFT JOIN prestamo_libro pl ON p.ID_Prestamo = pl.ID_Prestamo
                LEFT JOIN libro l ON pl.ISBN = l.ISBN
                LEFT JOIN prestamo_material pm ON p.ID_Prestamo = pm.ID_Prestamo
                LEFT JOIN material m ON pm.ID_Material = m.ID
                WHERE p.Estado = 'Por vencer' AND DATEDIFF(p.Fecha_Devolucion, @fecha) BETWEEN 0 AND 3";

                    using (var cmd1 = new MySqlCommand(queryPorVencer, conn))
                    {
                        cmd1.Parameters.AddWithValue("@fecha", fechaHoy);
                        using (var reader = cmd1.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string telefono = reader["Telefono"].ToString();
                                string recurso = reader["Recurso"].ToString();
                                DateTime fechaDevolucion = Convert.ToDateTime(reader["Fecha_Devolucion"]);
                                int diasRestantes = (fechaDevolucion - fechaHoy).Days;

                                string mensaje = $"📢 Tu préstamo del recurso \"{recurso}\" vence en {diasRestantes} día(s). Devuélvelo pronto para evitar una multa.";
                                await EnviarWhatsAppSimple(telefono, mensaje);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Error al actualizar estados: " + ex.Message);
            }
        }




        private async Task GenerarMultasAtrasadas()
        {
            try
            {
                using (var conn = new Conexion().Conectar())
                {
                    DateTime fechaHoy = DateTime.Now.Date;

                    string query = @"
                SELECT p.ID_Prestamo, p.Fecha_Devolucion
                FROM prestamo p
                LEFT JOIN multa m ON p.ID_Prestamo = m.ID_Prestamo
                WHERE p.Estado = 'Atrasado'
                  AND m.ID_Prestamo IS NULL
                  AND DATEDIFF(@fecha, p.Fecha_Devolucion) > 0";

                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@fecha", fechaHoy);

                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                long idPrestamo = Convert.ToInt64(reader["ID_Prestamo"]);
                                DateTime fechaDevolucion = Convert.ToDateTime(reader["Fecha_Devolucion"]);
                                int diasAtraso = (fechaHoy - fechaDevolucion).Days;
                                float monto = diasAtraso * 7f;

                                // Solo esta llamada es suficiente (ya incluye notificación al alumno)
                                await RegistrarMulta(idPrestamo, fechaDevolucion, monto);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Error al generar multas: " + ex.Message);
            }
        }

        public async Task EnviarWhatsAppSimple(string telefono, string mensaje)
        {
            string url = "https://api.ultramsg.com/instance122699/messages/chat";
            var client = new RestSharp.RestClient(url);

            var request = new RestSharp.RestRequest(url, Method.Post);
            request.AddHeader("content-type", "application/x-www-form-urlencoded");

            request.AddParameter("token", "pwgq2ev3zmoe7aao");
            request.AddParameter("to", "+52" + telefono);
            request.AddParameter("body", mensaje);

            RestResponse response = await client.ExecuteAsync(request);
            if (!response.IsSuccessful)
            {
                MessageBox.Show("❌ No se pudo enviar mensaje: " + response.Content);
            }
        }
        private async Task RegistrarMulta(long idPrestamo, DateTime fechaDevolucion, float monto)
        {
            string nombreRecurso = "recurso desconocido";
            string telefono = null;

            using (var conn = new Conexion().Conectar())
            {
                // Obtener nombre del recurso (libro o material)
                string queryNombre = @"
            SELECT l.Titulo AS Nombre FROM prestamo_libro pl
            JOIN libro l ON pl.ISBN = l.ISBN
            WHERE pl.ID_Prestamo = @id
            UNION
            SELECT m.Nombre FROM prestamo_material pm
            JOIN material m ON pm.ID_Material = m.ID
            WHERE pm.ID_Prestamo = @id";

                using (var cmd = new MySqlCommand(queryNombre, conn))
                {
                    cmd.Parameters.AddWithValue("@id", idPrestamo);
                    object result = cmd.ExecuteScalar();
                    if (result != null)
                        nombreRecurso = result.ToString();
                }

                // Obtener teléfono del alumno asociado al préstamo
                string queryTelefono = @"
            SELECT a.Telefono
            FROM prestamo p
            JOIN alumno a ON p.Boleta = a.Boleta
            WHERE p.ID_Prestamo = @id";

                using (var cmd = new MySqlCommand(queryTelefono, conn))
                {
                    cmd.Parameters.AddWithValue("@id", idPrestamo);
                    object result = cmd.ExecuteScalar();
                    if (result != null)
                        telefono = result.ToString();
                }

                // Insertar multa
                string insertMulta = @"
            INSERT INTO multa (ID_Prestamo, Fecha_Emision, Fecha_Devolucion, Estado, Monto)
            VALUES (@id, @fecha, @devolucion, 'Pendiente', @monto)";
                using (var cmd = new MySqlCommand(insertMulta, conn))
                {
                    cmd.Parameters.AddWithValue("@id", idPrestamo);
                    cmd.Parameters.AddWithValue("@fecha", DateTime.Today);
                    cmd.Parameters.AddWithValue("@devolucion", fechaDevolucion);
                    cmd.Parameters.AddWithValue("@monto", monto);
                    cmd.ExecuteNonQuery();
                }
            }

            // Enviar WhatsApp solo si se tiene número
            if (!string.IsNullOrWhiteSpace(telefono))
            {
                string mensaje = $"⚠️ Tu préstamo del recurso \"{nombreRecurso}\" ha generado una multa de ${monto:0.00} MXN. Paga lo antes posible para evitar sanciones adicionales.";
                await EnviarWhatsAppSimple(telefono, mensaje);
            }
        }
        private async Task ActualizarMontoMulta(long idPrestamo, float nuevoMonto)
        {
            using (var conn = new Conexion().Conectar())
            {
                string update = "UPDATE multa SET Monto = @monto WHERE ID_Prestamo = @id AND Estado = 'Pendiente'";
                using (var cmd = new MySqlCommand(update, conn))
                {
                    cmd.Parameters.AddWithValue("@monto", nuevoMonto);
                    cmd.Parameters.AddWithValue("@id", idPrestamo);
                    await cmd.ExecuteNonQueryAsync();
                }
            }
        }









        private void btndevoluciones_Click(object sender, EventArgs e)
        {
            AbrirFormularioEnPanel(new Devoluciones(this));
        }

        private void btninicio_Click(object sender, EventArgs e)
        {
            AbrirFormularioEnPanel(new Inicio());
        }

        private void btnprestamos_Click(object sender, EventArgs e)
        {
            AbrirFormularioEnPanel(new Prestamos(this));

        }

        private void btnusuarios_Click(object sender, EventArgs e)
        {
            AbrirFormularioEnPanel(new Usuarios(this));

        }

        private void btnlibros_Click(object sender, EventArgs e)
        {
            AbrirFormularioEnPanel(new Libros());
        }

        private void btnmaterial_Click(object sender, EventArgs e)
        {
            AbrirFormularioEnPanel(new Material());
        }

        private void btnreportes_Click(object sender, EventArgs e)
        {
            AbrirFormularioEnPanel(new Reportes());
        }

        private void btnConfig_Click(object sender, EventArgs e)
        {
            using (Tracer tracer = new Tracer("Form_Main::btnReaderSelect_Click"))
            {

                if (_readerSelection == null)
                {
                    _readerSelection = new ReaderSelection();
                    _readerSelection.Sender = this;
                }

                _readerSelection.ShowDialog();

                _readerSelection.Dispose();
                _readerSelection = null;
            }
        }


        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(14, 111, 159);
            DialogResult resultado = MessageBox.Show("¿Seguro que deseas cerrar sesión?",
                                              "Confirmar salida",
                                              MessageBoxButtons.YesNo,
                                              MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                //Application.Restart(); // 🔁 Reinicia toda la aplicación
                this.Hide();
                Login loginForm = new Login();
                loginForm.Show();
            }
        }

        private void btnMulta_Click(object sender, EventArgs e)
        {
            AbrirFormularioEnPanel(new Multas(""));
            

        }


    }
}

#endregion

#endregion
