﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using DPUruNet;
using FmdObject = DPUruNet.Fmd;
using FmdFormat = DPUruNet.Constants.Formats.Fmd;
using LectorPrueba.MySQL;
using System.Security.Cryptography;
using System.Text;


namespace UareUSampleCSharp
{
    public partial class Verification : Form
    {
        public string BoletaEsperada { get; set; } = null;
        public bool EsEdicion { get; set; } = false;

        private static readonly byte[] Key = Encoding.UTF8.GetBytes("1234567890abcdef"); // 16 bytes
        private static readonly byte[] IV = Encoding.UTF8.GetBytes("abcdef1234567890");  // 16 bytes
        public Form_Main _sender { get; set; }
        private const int PROBABILITY_ONE = 0x7FFFFFFF;
        private FmdObject huellaCapturada;
        private Conexion conexionBD = new Conexion();

        public string BoletaVerificada { get; private set; }


        public Verification()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;

        }

        private void Verification_Load(object sender, EventArgs e)
        {
            if (_sender != null)
            {
                _sender.OpenReader();
                _sender.StartCaptureAsync(OnCaptured);
                SendMessage("Pon un dedo en el lector.");
            }

        }

        private void Verification_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (_sender != null)
            {
                _sender.CancelCaptureAndCloseReader(OnCaptured);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public static string AesDecrypt(string cipherTextBase64)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = Key;
                aes.IV = IV;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                ICryptoTransform decryptor = aes.CreateDecryptor();
                byte[] encryptedBytes = Convert.FromBase64String(cipherTextBase64);
                byte[] decrypted = decryptor.TransformFinalBlock(encryptedBytes, 0, encryptedBytes.Length);

                return Encoding.UTF8.GetString(decrypted);
            }
        }
        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (huellaCapturada == null)
            {
                MessageBox.Show("⚠️ Primero debes capturar una huella.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var conn = conexionBD.Conectar())
            using (var cmd = new MySqlCommand("SELECT Boleta, Nombre, A_Paterno, A_Materno, Telefono, HuellaAES FROM alumno WHERE HuellaAES IS NOT NULL", conn))
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    string boleta = reader["Boleta"].ToString();
                    string nombreCompleto = $"{reader["Nombre"]} {reader["A_Paterno"]} {reader["A_Materno"]}";
                    string telefono = reader["Telefono"].ToString();
                    string huellaCifrada = reader["HuellaAES"].ToString();

                    try
                    {
                        string huellaDescifrada = AesDecrypt(huellaCifrada); // 🔓 Descifra el XML
                        var huellaGuardada = FmdObject.DeserializeXml(huellaDescifrada); // 🔄

                        var resultado = Comparison.Compare(huellaCapturada, 0, huellaGuardada, 0);

                        if (resultado.ResultCode == Constants.ResultCode.DP_SUCCESS &&
                            resultado.Score < (PROBABILITY_ONE / 1000))
                        {
                            // Si se está esperando una boleta específica (por ejemplo, al editar), validarla
                            if (!string.IsNullOrEmpty(BoletaEsperada) && boleta != BoletaEsperada)
                            {
                                MessageBox.Show("❌ La huella no coincide con el alumno seleccionado.",
                                                "Acceso denegado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                SendMessage("Pon un dedo en el lector.");
                                return;
                            }

                            MessageBox.Show(
                                $"✅ Huella verificada.\nBoleta: {boleta}\nNombre: {nombreCompleto}\nTeléfono: {telefono}",
                                "Verificación exitosa",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);

                            BoletaVerificada = boleta;
                            DialogResult = DialogResult.OK;
                            Close();
                            return;
                        }
                    }
                    catch
                    {
                        SendMessage("Pon un dedo en el lector.");
                        continue;
                    }
                }
            }

            MessageBox.Show("❌ Huella no encontrada.", "Error de verificación", MessageBoxButtons.OK, MessageBoxIcon.Error);
            SendMessage("Pon un dedo en el lector.");
        }



        private void OnCaptured(CaptureResult captureResult)
        {
            try
            {
                if (!_sender.CheckCaptureResult(captureResult))
                    return;

                SendMessage("Huella capturada.");

                var result = FeatureExtraction.CreateFmdFromFid(captureResult.Data, FmdFormat.ANSI);
                if (result.ResultCode == Constants.ResultCode.DP_SUCCESS)
                {
                    huellaCapturada = result.Data;
                }
                else
                {
                    SendMessage("Error durante la captura:\n\n");
                    System.Threading.Thread.Sleep(1500); // Espera 1.5 segundos
                    SendMessage("Pon un dedo en el lector.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error durante la captura: " + ex.Message);
            }
        }

        private void SendMessage(string message)
        {
            if (txtVerify.InvokeRequired)
            {
                txtVerify.Invoke(new Action(() => txtVerify.Text = message));
            }
            else
            {
                txtVerify.Text = message;
            }
        }

    }
}
