﻿using System;
using System.Windows.Forms;

namespace UareUSampleCSharp
{
    static class Program
    {
        [STAThread] // ✅ IMPORTANTE: Debe ser STAThread, no MTAThread
        static void Main()
        {
#if (!WindowsCE)
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
#endif

            
           using (var loginForm = new Login()) // 🟡 Usamos el formulario de Login como entrada
             {
                 if (loginForm.ShowDialog() == DialogResult.OK)
                 {
                     Application.Run(new Form_Main(loginForm.IDVerificado, loginForm.NombreVerificado));

                 }
                 else
                 {
                     Application.Exit(); // ❌ Si el login falla o se cierra, termina el programa
                 }
             }
        //    Application.Run(new Form_Main("1", "Administrador"));

        }
    }
}
