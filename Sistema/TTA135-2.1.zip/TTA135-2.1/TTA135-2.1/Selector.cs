﻿using LectorPrueba.MySQL;
using System;
using System.Windows.Forms;
using System.Threading.Tasks;

using UareUSampleCSharp;

namespace LectorPrueba
{
    public partial class Selector : Form
    {
        private Form_Main _formMain;
        private string boletaAlumno = null;
        private Conexion conexionBD = new Conexion();

        public Selector(Form_Main formMain, string boletaSeleccionada)
        {
            InitializeComponent();
            _formMain = formMain;
            boletaAlumno = boletaSeleccionada;
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private async void btnContinuar_Click(object sender, EventArgs e)
        {
            if (rbdSelector.Checked) // 🔐 Verificación por huella
            {
                if (_formMain.CurrentReader == null)
                {
                    MessageBox.Show(
                        "🖐️ Primero debes seleccionar un lector de huellas desde la configuración.",
                        "Lector no seleccionado",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    return;
                }

                if (string.IsNullOrWhiteSpace(boletaAlumno))
                {
                    MessageBox.Show("⚠️ No se recibió la boleta del usuario.");
                    return;
                }

                Verification verificacion = new Verification
                {
                    _sender = _formMain,
                    BoletaEsperada = boletaAlumno
                };

                if (verificacion.ShowDialog() == DialogResult.OK)
                {

                    string boletaVerificada = verificacion.BoletaVerificada;

                    if (boletaVerificada == boletaAlumno)
                    {
                        RegistroUsuarios registroForm = new RegistroUsuarios(_formMain, null, boletaAlumno);
                        this.Close(); // 👈 Cierra el Selector
                        await Task.Delay(500);
                        registroForm.Show();
                        
                    }
                    else
                    {
                        MessageBox.Show("❌ La huella no coincide con el usuario seleccionado.");
                    }
                }
                else
                {
                    MessageBox.Show("❌ No se completó la verificación de huella.");
                }
            }
            else if (rbdContrasena.Checked) // 🔒 Verificación por contraseña
            {
                if (string.IsNullOrWhiteSpace(boletaAlumno))
                {
                    MessageBox.Show("⚠️ No se recibió la boleta del usuario.");
                    return;
                }

                VerificationContra contraForm = new VerificationContra(boletaAlumno);
                if (contraForm.ShowDialog() == DialogResult.OK)
                {
                    RegistroUsuarios registroForm = new RegistroUsuarios(_formMain, null, boletaAlumno);
                    this.Close(); // 👈 Cierra el Selector
                    await Task.Delay(500);
                    registroForm.Show();
                    
                }
                else
                {
                    MessageBox.Show("❌ Verificación de contraseña cancelada o incorrecta.");
                }
            }
            else
            {
                MessageBox.Show("⚠️ Debes seleccionar un método de verificación.");
            }
        }

    }
}
