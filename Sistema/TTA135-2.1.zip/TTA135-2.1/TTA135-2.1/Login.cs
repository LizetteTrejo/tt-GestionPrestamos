﻿// ---------------- Login.cs ----------------
using DPUruNet;
using LectorPrueba.MySQL;
using MySql.Data.MySqlClient;
using System;
using System.Drawing;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using static DPUruNet.Constants;
using static Mysqlx.Expect.Open.Types.Condition.Types;
using static UareUSampleCSharp.RegistroUsuarios;
using FmdFormat = DPUruNet.Constants.Formats.Fmd;
using FmdObject = DPUruNet.Fmd;

namespace UareUSampleCSharp
{
    public partial class Login : Form
    {
        private const int PROBABILITY_ONE = 0x7FFFFFFF;
        private FmdObject huellaCapturada;
        private Conexion conexionBD = new Conexion();

        private static readonly byte[] Key = Encoding.UTF8.GetBytes("1234567890abcdef"); // 16 bytes
        private static readonly byte[] IV = Encoding.UTF8.GetBytes("abcdef1234567890");  // 16 bytes
        public string BoletaVerificada { get; private set; }
        public string IDVerificado { get; private set; }
        public string NombreVerificado { get; private set; }

        public Reader CurrentReader { get; set; }
        private Reader.CaptureCallback captureCallback;

        public Login()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            lblleerhuella.TextAlign = ContentAlignment.MiddleCenter;
            this.FormClosed += Login_FormClosed;
        }


        private void Login_Load(object sender, EventArgs e)
        {
            SendMessage("⚙️ Haz clic en 'Config' para seleccionar el lector.");
        }

        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            CancelCaptureAndCloseReader();
        }

        private void StartCaptureAsync(Reader.CaptureCallback callback)
        {
            captureCallback = callback;
            if (CurrentReader != null)
            {
                CurrentReader.On_Captured -= captureCallback;
                CurrentReader.On_Captured += captureCallback;

                var captureResult = CurrentReader.CaptureAsync(
                    Constants.Formats.Fid.ANSI,
                    Constants.CaptureProcessing.DP_IMG_PROC_DEFAULT,
                    CurrentReader.Capabilities.Resolutions[0]);

                if (captureResult != Constants.ResultCode.DP_SUCCESS)
                {
                    MessageBox.Show("❌ Error al iniciar la captura.");
                }
            }
        }

        public void CancelCaptureAndCloseReader()
        {
            if (CurrentReader != null)
            {
                try { CurrentReader.CancelCapture(); } catch { }
                if (captureCallback != null)
                    CurrentReader.On_Captured -= captureCallback;
                try { CurrentReader.Dispose(); } catch { }
                CurrentReader = null;
            }
        }

        private void OnCaptured(CaptureResult captureResult)
        {
            try
            {
                if (captureResult == null || captureResult.Data == null ||
                    captureResult.ResultCode != Constants.ResultCode.DP_SUCCESS)
                {
                    SendMessage("❌ Captura inválida.");
                    return;
                }

                SendMessage("Huella capturada.");

                var result = FeatureExtraction.CreateFmdFromFid(captureResult.Data, FmdFormat.ANSI);
                if (result.ResultCode != Constants.ResultCode.DP_SUCCESS)
                {
                    SendMessage("❌ Error al procesar la huella.");
                    Thread.Sleep(1500);
                    SendMessage("Pon un dedo en el lector.");
                    return;
                }

                huellaCapturada = result.Data;
                VerificarHuella();
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Error durante la captura: " + ex.Message);
            }
        }

        private void VerificarHuella()
        {
            using (var conn = conexionBD.Conectar())
            {
                const string query = "SELECT ID, Nombre, A_Paterno, A_Materno, Telefono, HuellaAES FROM administrador";
                using (var cmd = new MySqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string id = reader["ID"].ToString();
                        string nombre = reader["Nombre"].ToString();
                        string apaterno = reader["A_Paterno"].ToString();
                        string amaterno = reader["A_Materno"].ToString();
                        string telefono = reader["Telefono"].ToString();
                        string huellaCifrada = reader["HuellaAES"].ToString();

                        try
                        {
                            string huellaXML = AesDecrypt(huellaCifrada); // 🔓 desencriptar
                            var huellaGuardada = FmdObject.DeserializeXml(huellaXML);

                            var result = Comparison.Compare(huellaCapturada, 0, huellaGuardada, 0);

                            if (result.ResultCode == Constants.ResultCode.DP_SUCCESS &&
                                result.Score < (PROBABILITY_ONE / 1000))
                            {
                                CancelCaptureAndCloseReader();

                                Invoke(new Action(() =>
                                {
                                    SendMessage("✅ Huella verificada.");
                                    MessageBox.Show(
                                        $"✅ Huella verificada.\nID: {id}\nNombre: {nombre} {apaterno} {amaterno}\nTel: {telefono}",
                                        "Acceso concedido",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);

                                    IDVerificado = id;
                                    NombreVerificado = $"{nombre} {apaterno} {amaterno}";

                                    this.DialogResult = DialogResult.OK;
                                    this.Close();
                                }));

                                return;
                            }
                        }
                        catch
                        {
                            continue;
                        }
                    }
                }
            }

            Invoke(new Action(() =>
            {
                SendMessage("❌ Huella no encontrada. Intenta nuevamente.");
            }));
        }

        private void SendMessage(string mensaje)
        {
            if (lblleerhuella.InvokeRequired)
                lblleerhuella.Invoke(new Action(() => lblleerhuella.Text = mensaje));
            else
                lblleerhuella.Text = mensaje;
        }
        public static string AesDecrypt(string cipherTextBase64)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = Key;
                aes.IV = IV;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                ICryptoTransform decryptor = aes.CreateDecryptor();
                byte[] encryptedBytes = Convert.FromBase64String(cipherTextBase64);
                byte[] decrypted = decryptor.TransformFinalBlock(encryptedBytes, 0, encryptedBytes.Length);

                return Encoding.UTF8.GetString(decrypted);
            }
        }

        private void btnConfig_Click(object sender, EventArgs e)
        {
            using (var readerSelect = new ReaderSelection())
            {
                if (readerSelect.ShowDialog() == DialogResult.OK && readerSelect.SelectedReader != null)
                {
                    CancelCaptureAndCloseReader();
                    CurrentReader = readerSelect.SelectedReader;

                    var openResult = CurrentReader.Open(Constants.CapturePriority.DP_PRIORITY_COOPERATIVE);
                    if (openResult != Constants.ResultCode.DP_SUCCESS)
                    {
                        MessageBox.Show("❌ No se pudo abrir el lector seleccionado.");
                        return;
                    }

                    StartCaptureAsync(OnCaptured);
                    SendMessage("✅ Lector seleccionado. Pon tu huella.");
                }
            }
        }

        private void btnRoot_Click(object sender, EventArgs e)
        {
            if (CurrentReader == null)
            {
                MessageBox.Show("❌ No has seleccionado un lector.");
                return;
            }

            string storedHash = "240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9";

            using (var passwordForm = new SuperPasswordForm())
            {
                passwordForm.DesdeRoot = true; // ✅ Le indicas que viene desde el botón Root

                if (passwordForm.ShowDialog() != DialogResult.OK || Encrypt.GetSHA256(passwordForm.EnteredPassword) != storedHash)
                {
                    MessageBox.Show("❌ Contraseña incorrecta. Acceso denegado.");
                    return;
                }
            }

            // Cancelar captura y remover evento antes de pasar a Admin
            try { CurrentReader.CancelCapture(); } catch { }
            if (captureCallback != null)
            {
                try { CurrentReader.On_Captured -= captureCallback; } catch { }
            }

            // Abrir formulario Admin
            using (var form = new Admin(this)) 

            {

                form.ShowDialog(); // Espera hasta que se cierre
            }

            // Reanudar captura después de cerrar Admin
            StartCaptureAsync(OnCaptured);
            SendMessage("✅ Lector listo. Coloca tu huella.");
        }

        private void linkContra_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var passwordForm = new SuperPasswordForm();
            passwordForm.DesdeRoot = false;

            if (passwordForm.ShowDialog() == DialogResult.OK)
            {
                string id = passwordForm.txtId.Text.Trim();
                string pass = passwordForm.EnteredPassword.Trim();

                if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(pass))
                {
                    MessageBox.Show("❌ Debes ingresar tu ID y contraseña.");
                    return;
                }

                string hash = Encrypt.GetSHA256(pass);

                using (var conn = conexionBD.Conectar())
                {
                    const string query = @"SELECT ID, Nombre, A_Paterno, A_Materno, Telefono 
                                   FROM administrador 
                                   WHERE ID = @id AND Pswrd = @hash";
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@hash", hash);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string nombre = reader["Nombre"].ToString();
                                string apaterno = reader["A_Paterno"].ToString();
                                string amaterno = reader["A_Materno"].ToString();
                                string telefono = reader["Telefono"].ToString();

                                CancelCaptureAndCloseReader();

                                IDVerificado = id;
                                NombreVerificado = $"{nombre} {apaterno} {amaterno}";

                                MessageBox.Show(
                                    $"✅ Acceso concedido.\nID: {id}\nNombre: {NombreVerificado}\nTel: {telefono}",
                                    "Inicio de sesión",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);

                                // ✅ Señal de éxito para que Program.cs (o quien sea) abra el formulario principal
                                this.DialogResult = DialogResult.OK;
                                this.Close();
                                return;
                            }
                            else
                            {
                                MessageBox.Show("❌ ID o contraseña incorrectos.");
                            }
                        }
                    }
                }
            }
        }


    }
}
