﻿using System;
using MySql.Data.MySqlClient;

namespace LectorPrueba.MySQL
{
    public class Interaccion : Conexion
    {
        public bool verificarConexion()
        {
            try
            {
                using (MySqlConnection conn = Conectar())
                {
                    return conn.State == System.Data.ConnectionState.Open;
                }
            }
            catch
            {
                return false;
            }
        }
    }
}
