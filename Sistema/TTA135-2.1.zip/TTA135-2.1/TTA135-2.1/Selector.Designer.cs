﻿namespace LectorPrueba
{
    partial class Selector
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.rbdSelector = new System.Windows.Forms.RadioButton();
            this.rbdContrasena = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.btnContinuar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rbdSelector
            // 
            this.rbdSelector.AutoSize = true;
            this.rbdSelector.Location = new System.Drawing.Point(26, 58);
            this.rbdSelector.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbdSelector.Name = "rbdSelector";
            this.rbdSelector.Size = new System.Drawing.Size(69, 22);
            this.rbdSelector.TabIndex = 0;
            this.rbdSelector.TabStop = true;
            this.rbdSelector.Text = "Huella";
            this.rbdSelector.UseVisualStyleBackColor = true;
            // 
            // rbdContrasena
            // 
            this.rbdContrasena.AutoSize = true;
            this.rbdContrasena.Location = new System.Drawing.Point(26, 100);
            this.rbdContrasena.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbdContrasena.Name = "rbdContrasena";
            this.rbdContrasena.Size = new System.Drawing.Size(107, 22);
            this.rbdContrasena.TabIndex = 1;
            this.rbdContrasena.TabStop = true;
            this.rbdContrasena.Text = "Contraseña";
            this.rbdContrasena.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "Elije tu método de verificación";
            // 
            // btnContinuar
            // 
            this.btnContinuar.BackColor = System.Drawing.Color.White;
            this.btnContinuar.FlatAppearance.BorderSize = 0;
            this.btnContinuar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnContinuar.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContinuar.ForeColor = System.Drawing.Color.Black;
            this.btnContinuar.Location = new System.Drawing.Point(40, 143);
            this.btnContinuar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnContinuar.Name = "btnContinuar";
            this.btnContinuar.Size = new System.Drawing.Size(180, 42);
            this.btnContinuar.TabIndex = 3;
            this.btnContinuar.Text = "Continuar";
            this.btnContinuar.UseVisualStyleBackColor = false;
            this.btnContinuar.Click += new System.EventHandler(this.btnContinuar_Click);
            // 
            // Selector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(111)))), ((int)(((byte)(159)))));
            this.ClientSize = new System.Drawing.Size(270, 198);
            this.Controls.Add(this.btnContinuar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rbdContrasena);
            this.Controls.Add(this.rbdSelector);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Selector";
            this.Text = "Selector de Verificación";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbdSelector;
        private System.Windows.Forms.RadioButton rbdContrasena;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnContinuar;
    }
}
