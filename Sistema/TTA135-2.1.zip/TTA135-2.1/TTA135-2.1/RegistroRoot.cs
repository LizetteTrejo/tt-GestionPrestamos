﻿using DPUruNet;
using LectorPrueba.MySQL;
using MySql.Data.MySqlClient;
using System;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using static Mysqlx.Expect.Open.Types.Condition.Types;
using static UareUSampleCSharp.RegistroUsuarios;
using FmdFormat = DPUruNet.Constants.Formats.Fmd;
using FmdObject = DPUruNet.Fmd;

namespace UareUSampleCSharp
{
    public partial class RegistroRoot : Form
    {
        private Login _senderLogin = null;
        private Conexion conexionBD = new Conexion();
        private string idEdicion = null;
        private bool esEdicion => idEdicion != null;

        private Reader currentReader;
        private FmdObject huellaCapturada;
        private Reader.CaptureCallback captureCallback;
        private const int PROBABILITY_ONE = 0x7FFFFFFF;

        private static readonly byte[] Key = Encoding.UTF8.GetBytes("1234567890abcdef"); // 16 bytes
        private static readonly byte[] IV = Encoding.UTF8.GetBytes("abcdef1234567890");  // 16 bytes

        public RegistroRoot(Login senderLogin, string id)
        {
            InitializeComponent();
            _senderLogin = senderLogin;
            idEdicion = id;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Load += RegistroRoot_Load;
            this.FormClosed += RegistroRoot_FormClosed;
        }

        private void RegistroRoot_Load(object sender, EventArgs e)
        {
            txtStatus.Text = "";

            if (esEdicion)
            {
                chkHuella.Visible = false;
                txtStatus.Text = "Modo edición - lector apagado.";
                CargarDatosAdministrador();
                txtID.ReadOnly = true;
                btnRegistrar.Text = "Guardar Cambios";
            }
            else
            {
                bool lectorIniciado = false;

                if (_senderLogin != null && _senderLogin.CurrentReader != null)
                {
                    currentReader = _senderLogin.CurrentReader;
                    lectorIniciado = InicializarLector();
                }

                if (!lectorIniciado)
                {
                    MessageBox.Show("❌ No se pudo iniciar el lector en RegistroRoot.");
                    this.Close();
                }
                else
                {
                    txtStatus.Text = "Coloca tu dedo en el lector.";
                }
            }
        }

        private bool InicializarLector()
        {
            if (currentReader == null)
                return false;

            try { currentReader.CancelCapture(); } catch { }

            captureCallback = new Reader.CaptureCallback(OnCaptured);
            currentReader.On_Captured -= captureCallback;
            currentReader.On_Captured += captureCallback;

            var result = currentReader.CaptureAsync(
                Constants.Formats.Fid.ANSI,
                Constants.CaptureProcessing.DP_IMG_PROC_DEFAULT,
                currentReader.Capabilities.Resolutions[0]);

            return result == Constants.ResultCode.DP_SUCCESS;
        }

        private void OnCaptured(CaptureResult captureResult)
        {
            if (captureResult == null || captureResult.Data == null ||
                captureResult.ResultCode != Constants.ResultCode.DP_SUCCESS)
            {
                if (txtStatus.IsHandleCreated)
                {
                    txtStatus.Invoke(new MethodInvoker(() => txtStatus.Text = "❌ Captura inválida."));
                }
                return;
            }

            var result = FeatureExtraction.CreateFmdFromFid(captureResult.Data, FmdFormat.ANSI);
            if (result.ResultCode != Constants.ResultCode.DP_SUCCESS)
            {
                if (txtStatus.IsHandleCreated)
                {
                    txtStatus.Invoke(new MethodInvoker(() => txtStatus.Text = "❌ Error al procesar huella."));
                }
                return;
            }

            huellaCapturada = result.Data;

            if (huellaCapturada.Bytes == null || huellaCapturada.Bytes.Length < 100)
            {
                if (txtStatus.IsHandleCreated)
                {
                    txtStatus.Invoke(new MethodInvoker(() => txtStatus.Text = "⚠️ Huella capturada inválida."));
                }
                huellaCapturada = null;
                return;
            }

            if (txtStatus.IsHandleCreated)
            {
                txtStatus.Invoke(new MethodInvoker(() => txtStatus.Text = "✅ Huella capturada correctamente."));
            }
        }

        private void RegistroRoot_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (_senderLogin != null)
            {
                // Solo detener captura, no liberar el lector completamente
                try { _senderLogin.CurrentReader.CancelCapture(); } catch { }
                if (captureCallback != null)
                {
                    try { _senderLogin.CurrentReader.On_Captured -= captureCallback; } catch { }
                }
            }
            else if (currentReader != null)
            {
                try { currentReader.CancelCapture(); } catch { }
                try { currentReader.On_Captured -= captureCallback; } catch { }
                try { currentReader.Dispose(); } catch { }
                currentReader = null;
            }
        }


        private void CargarDatosAdministrador()
        {
            using (var conn = conexionBD.Conectar())
            {
                string query = "SELECT * FROM administrador WHERE ID = @id";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", idEdicion);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtID.Text = reader["ID"].ToString();
                            txtNombre.Text = reader["Nombre"].ToString();
                            txtAPaterno.Text = reader["A_Paterno"].ToString();
                            txtAMaterno.Text = reader["A_Materno"].ToString();
                            txtTelefono.Text = reader["Telefono"].ToString();
                        }
                    }
                }
            }
        }

        private static string AesEncrypt(string plainText)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = Key;
                aes.IV = IV;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                var encryptor = aes.CreateEncryptor();
                byte[] inputBytes = Encoding.UTF8.GetBytes(plainText);
                byte[] encryptedBytes = encryptor.TransformFinalBlock(inputBytes, 0, inputBytes.Length);

                return Convert.ToBase64String(encryptedBytes);
            }
        }
        public static string AesDecrypt(string cipherTextBase64)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = Key;
                aes.IV = IV;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                ICryptoTransform decryptor = aes.CreateDecryptor();
                byte[] encryptedBytes = Convert.FromBase64String(cipherTextBase64);
                byte[] decrypted = decryptor.TransformFinalBlock(encryptedBytes, 0, encryptedBytes.Length);

                return Encoding.UTF8.GetString(decrypted);
            }
        }


        private async void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtID.Text) ||
                string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtAPaterno.Text) ||
                string.IsNullOrWhiteSpace(txtAMaterno.Text) ||
                string.IsNullOrWhiteSpace(txtTelefono.Text) ||
                string.IsNullOrWhiteSpace(txtPassword.Text) ||
                string.IsNullOrWhiteSpace(txtConfirmPassword.Text))
            {
                MessageBox.Show("Por favor llena todos los campos.");
                return;
            }

            if (!esEdicion && chkHuella.Checked && huellaCapturada == null)
            {
                MessageBox.Show("Primero debes capturar una huella válida.");
                return;
            }

            if (!int.TryParse(txtID.Text.Trim(), out _))
            {
                MessageBox.Show("El ID debe ser numérico.");
                return;
            }

            if (txtPassword.Text != txtConfirmPassword.Text)
            {
                MessageBox.Show("Las contraseñas no coinciden.");
                return;
            }

            string id = txtID.Text.Trim();
            string nombre = txtNombre.Text.Trim();
            string apaterno = txtAPaterno.Text.Trim();
            string amaterno = txtAMaterno.Text.Trim();
            string telefono = txtTelefono.Text.Trim();
            string password = Encrypt.GetSHA256(txtPassword.Text.Trim());
            string xmlHuella = huellaCapturada != null ? FmdObject.SerializeXml(huellaCapturada) : string.Empty;
            string formatoHuella = FmdFormat.ANSI.ToString();
            bool guardarHuella = chkHuella.Checked;
            string huellaAES = guardarHuella && huellaCapturada != null ? AesEncrypt(xmlHuella) : null;

            if (!esEdicion && guardarHuella && xmlHuella.Length < 400)
            {
                MessageBox.Show("⚠️ La huella es demasiado corta. Captura nuevamente.");
                return;
            }

            using (var conn = conexionBD.Conectar())
            {
                if (esEdicion)
                {
                    DialogResult result = MessageBox.Show(
                        "¿Deseas guardar los cambios del administrador?",
                        "Confirmar actualización",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question
                    );

                    if (result == DialogResult.No)
                        return;

                    string updateQuery = @"UPDATE administrador 
                SET Nombre = @nombre, A_Paterno = @apaterno, A_Materno = @amaterno, 
                    Telefono = @telefono, Pswrd = @password
                WHERE ID = @id";

                    using (var cmd = new MySqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@nombre", nombre);
                        cmd.Parameters.AddWithValue("@apaterno", apaterno);
                        cmd.Parameters.AddWithValue("@amaterno", amaterno);
                        cmd.Parameters.AddWithValue("@telefono", telefono);
                        cmd.Parameters.AddWithValue("@password", password);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Administrador actualizado correctamente.");
                    this.Close();
                }
                else
                {
                    string verificarQuery = "SELECT COUNT(*) FROM administrador WHERE ID = @id";
                    using (var verificarCmd = new MySqlCommand(verificarQuery, conn))
                    {
                        verificarCmd.Parameters.AddWithValue("@id", id);
                        int count = Convert.ToInt32(verificarCmd.ExecuteScalar());
                        if (count > 0)
                        {
                            MessageBox.Show("Ya existe un administrador con ese ID.");
                            txtID.Clear();
                            return;
                        }
                    }

                    if (guardarHuella && huellaCapturada == null)
                    {
                        MessageBox.Show("⚠️ Captura una huella antes de continuar.");
                        return;
                    }

                    if (guardarHuella)
                    {
                        string selectHuellas = "SELECT ID, HuellaAES FROM administrador WHERE HuellaAES IS NOT NULL";
                        using (var verificarHuellaCmd = new MySqlCommand(selectHuellas, conn))
                        using (var reader = verificarHuellaCmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string idExistente = reader["ID"].ToString();
                                string huellaEncriptada = reader["HuellaAES"].ToString();

                                try
                                {
                                    string huellaDescifrada = AesDecrypt(huellaEncriptada);
                                    var huellaExistente = FmdObject.DeserializeXml(huellaDescifrada);
                                    var resultadoComparacion = Comparison.Compare(huellaCapturada, 0, huellaExistente, 0);

                                    if (resultadoComparacion.ResultCode == Constants.ResultCode.DP_SUCCESS &&
                                        resultadoComparacion.Score < (PROBABILITY_ONE / 1000))
                                    {
                                        MessageBox.Show($"❌ La huella ya está registrada para el ID: {idExistente}");
                                        txtStatus.Text = "⚠️ Huella capturada ya registrada. \nIntenta de nuevo.";
                                        return;
                                    }
                                }
                                catch
                                {
                                    continue;
                                }
                            }
                        }
                    }

                    string insertQuery = @"INSERT INTO administrador 
            (ID, Nombre, A_Paterno, A_Materno, Telefono, Pswrd, HuellaAES, FormatoHuella)
            VALUES (@id, @nombre, @apaterno, @amaterno, @telefono, @password, @huellaAES, @formato)";

                    using (var cmd = new MySqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@nombre", nombre);
                        cmd.Parameters.AddWithValue("@apaterno", apaterno);
                        cmd.Parameters.AddWithValue("@amaterno", amaterno);
                        cmd.Parameters.AddWithValue("@telefono", telefono);
                        cmd.Parameters.AddWithValue("@password", password);
                        cmd.Parameters.AddWithValue("@huellaAES", huellaAES != null ? (object)huellaAES : DBNull.Value);
                        cmd.Parameters.AddWithValue("@formato", guardarHuella ? (object)formatoHuella : DBNull.Value);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Administrador registrado correctamente.");
                    this.Close();

                    // Aquí podrías agregar alguna notificación o acción extra si deseas
                }
            }

            LimpiarCampos();
            huellaCapturada = null;
        }

        private void LimpiarCampos()
        {
            txtID.Clear();
            txtNombre.Clear();
            txtAPaterno.Clear();
            txtAMaterno.Clear();
            txtTelefono.Clear();
        }

        private void chkHuella_CheckedChanged(object sender, EventArgs e)
        {
            if (chkHuella.Checked)
            {
                txtStatus.Text = "📲 Por favor, captura la huella.";
            }
            else
            {
                txtStatus.Text = "🔒 El registro se hará sin huella.";
            }
        }

        private void txtStatus_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
