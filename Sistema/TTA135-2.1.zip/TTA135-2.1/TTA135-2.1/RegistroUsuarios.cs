﻿using DPUruNet;
using LectorPrueba.MySQL;
using MySql.Data.MySqlClient;

using RestSharp;
using System;

using System.Drawing;

using System.Security.Cryptography;
using System.Text;

using System.Threading.Tasks;
using System.Windows.Forms;

using FmdFormat = DPUruNet.Constants.Formats.Fmd;
using FmdObject = DPUruNet.Fmd;


namespace UareUSampleCSharp
{
    public partial class RegistroUsuarios : Form
    {
        public Form_Main _sender;
        private FmdObject huellaCapturada;
        private Usuarios _formUsuarios;
        private const int PROBABILITY_ONE = 0x7FFFFFFF;
        private Conexion conexionBD = new Conexion();

        private string boletaEdicion = null;
        private bool esEdicion => boletaEdicion != null;

        private static readonly byte[] Key = Encoding.UTF8.GetBytes("1234567890abcdef"); // 16 bytes
        private static readonly byte[] IV = Encoding.UTF8.GetBytes("abcdef1234567890");  // 16 bytes


        public RegistroUsuarios(Form_Main sender, Usuarios formUsuarios)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            _sender = sender;
            _formUsuarios = formUsuarios;
        }

        public RegistroUsuarios(Form_Main sender, Usuarios formUsuarios, string boleta)
            : this(sender, formUsuarios)
        {
            boletaEdicion = boleta;
        }

        private void RegistroUsuarios_Load(object sender, EventArgs e)
        {
            txtStatus.Text = string.Empty;

            if (_sender == null)
            {
                MessageBox.Show("ERROR: _sender es null.");
                this.Close();
                return;
            }
            if (esEdicion)
            {
                chkHuella.Visible = false;
                txtStatus.Text = "Huella guardada, lector apagado";
                CargarDatosAlumno();
                txtBoleta.ReadOnly = true;
                btnRegistrar.Text = "Guardar Cambios";
                
            }
            else
            {
                if (!_sender.OpenReader() || !_sender.StartCaptureAsync(this.OnCaptured))
                {
                    MessageBox.Show("No se pudo abrir el lector.");
                    this.Close();
                    return;
                }

                txtStatus.Text = "Coloca tu dedo en el lector.";
                this.ActiveControl = lblBoleta;
                SetPlaceholder(txtBoleta, "2021630000");
                SetPlaceholder(txtNombre, "Nombre");
                SetPlaceholder(txtAPaterno, "Apellido");
                SetPlaceholder(txtAMaterno, "Apellido");
                SetPlaceholder(txtTelefono, "5512345678");
                SetPlaceholder(txtPassword, "Mínimo 8 caracteres");
                SetPlaceholder(txtConfirmPassword, "Repite la contraseña");
            }

        }



        private void CargarDatosAlumno()
        {
            using (var conn = conexionBD.Conectar())
            {
                string query = "SELECT * FROM alumno WHERE Boleta = @boleta";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@boleta", boletaEdicion);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txtBoleta.Text = reader["Boleta"].ToString();
                            txtNombre.Text = reader["Nombre"].ToString();
                            txtAPaterno.Text = reader["A_Paterno"].ToString();
                            txtAMaterno.Text = reader["A_Materno"].ToString();
                            txtTelefono.Text = reader["Telefono"].ToString();
                            // No se carga la contraseña por seguridad
                        }
                    }
                }
            }
        }
        private void OnCaptured(CaptureResult captureResult)
        {
            if (_sender == null || !_sender.CheckCaptureResult(captureResult)) return;

            var result = FeatureExtraction.CreateFmdFromFid(captureResult.Data, FmdFormat.ANSI);

            if (result.ResultCode == Constants.ResultCode.DP_TOO_SMALL_AREA)
            {
                txtStatus.Invoke(new MethodInvoker(delegate
                {
                    txtStatus.Text = "❗ Área muy pequeña. \nReposiciona el dedo e intenta de nuevo.";
                }));
                return;
            }

            if (result.ResultCode != Constants.ResultCode.DP_SUCCESS)
            {
                txtStatus.Invoke(new MethodInvoker(delegate
                {
                    txtStatus.Text = "❌ Error al capturar huella: " + result.ResultCode;
                }));
                return;
            }

            huellaCapturada = result.Data;

            if (huellaCapturada.Bytes == null || huellaCapturada.Bytes.Length < 100)
            {
                txtStatus.Invoke(new MethodInvoker(delegate
                {
                    txtStatus.Text = "⚠️ Huella capturada inválida. \nIntenta de nuevo.";
                }));
                huellaCapturada = null;
                return;
            }

            txtStatus.Invoke(new MethodInvoker(delegate
            {
                txtStatus.Text = "✅ Huella capturada correctamente. \nYa puedes registrar.";
            }));
        }

        private async void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBoleta.Text) ||
                string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtAPaterno.Text) ||
                string.IsNullOrWhiteSpace(txtAMaterno.Text) ||
                string.IsNullOrWhiteSpace(txtTelefono.Text) ||
                string.IsNullOrWhiteSpace(txtPassword.Text) ||
                string.IsNullOrWhiteSpace(txtConfirmPassword.Text))
            {
                MessageBox.Show("Por favor llena todos los campos.");
                return;
            }

            if (!esEdicion && huellaCapturada == null)
            {
                MessageBox.Show("Primero debes capturar una huella válida.");
                return;
            }

            if (!int.TryParse(txtBoleta.Text.Trim(), out int _))
            {
                MessageBox.Show("La boleta debe ser un número válido.");
                return;
            }

            if (txtPassword.Text != txtConfirmPassword.Text)
            {
                MessageBox.Show("Las contraseñas no coinciden.");
                return;
            }

            string boleta = txtBoleta.Text.Trim();
            string nombre = txtNombre.Text.Trim();
            string apaterno = txtAPaterno.Text.Trim();
            string amaterno = txtAMaterno.Text.Trim();
            string telefono = txtTelefono.Text.Trim();
            string password = Encrypt.GetSHA256(txtPassword.Text.Trim());
            string xmlHuella = huellaCapturada != null ? FmdObject.SerializeXml(huellaCapturada) : string.Empty;
            string formatoHuella = FmdFormat.ANSI.ToString();

            bool guardarHuella = chkHuella.Checked;
            string huellaAES = guardarHuella && huellaCapturada != null ? AesEncrypt(xmlHuella) : null;

            if (!esEdicion && xmlHuella.Length < 400)
            {
                MessageBox.Show("⚠️ La huella es demasiado corta. Captura nuevamente.");
                return;
            }

            using (var conn = conexionBD.Conectar())
            {
                if (esEdicion)
                {
                    DialogResult result = MessageBox.Show(
                        "¿Deseas guardar los cambios del alumno?",
                        "Confirmar actualización",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question
                    );

                    if (result == DialogResult.No)
                        return;

                    string updateQuery = @"UPDATE alumno 
                SET Nombre = @nombre, A_Paterno = @apaterno, A_Materno = @amaterno, 
                    Telefono = @telefono, Pswrd = @password
                WHERE Boleta = @boleta";

                    using (var cmd = new MySqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@boleta", boleta);
                        cmd.Parameters.AddWithValue("@nombre", nombre);
                        cmd.Parameters.AddWithValue("@apaterno", apaterno);
                        cmd.Parameters.AddWithValue("@amaterno", amaterno);
                        cmd.Parameters.AddWithValue("@telefono", telefono);
                        cmd.Parameters.AddWithValue("@password", password);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Alumno actualizado correctamente.");

                    this.DialogResult = DialogResult.OK;
                    this.Close();

                }
                else
                {
                    string verificarQuery = "SELECT COUNT(*) FROM alumno WHERE Boleta = @boleta";
                    using (var verificarCmd = new MySqlCommand(verificarQuery, conn))
                    {
                        verificarCmd.Parameters.AddWithValue("@boleta", boleta);
                        int count = Convert.ToInt32(verificarCmd.ExecuteScalar());
                        if (count > 0)
                        {
                            MessageBox.Show("Ya existe un alumno con esa boleta.");
                            txtBoleta.Clear();
                            return;
                        }
                    }

                    if (guardarHuella && huellaCapturada == null)
                    {
                        MessageBox.Show("⚠️ Captura una huella antes de continuar.");
                        return;
                    }

                    huellaAES = guardarHuella && huellaCapturada != null ? AesEncrypt(xmlHuella) : null;

                    if (guardarHuella)
                    {
                        string selectHuellas = "SELECT Boleta, HuellaAES FROM alumno WHERE HuellaAES IS NOT NULL";

                        using (var verificarHuellaCmd = new MySqlCommand(selectHuellas, conn))
                        using (var reader = verificarHuellaCmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string boletaExistente = reader["Boleta"].ToString();
                                string huellaEncriptada = reader["HuellaAES"].ToString();

                                try
                                {
                                    string huellaDescifrada = AesDecrypt(huellaEncriptada);
                                    var huellaExistente = FmdObject.DeserializeXml(huellaDescifrada);
                                    var resultadoComparacion = Comparison.Compare(huellaCapturada, 0, huellaExistente, 0);

                                    if (resultadoComparacion.ResultCode == Constants.ResultCode.DP_SUCCESS &&
                                        resultadoComparacion.Score < (PROBABILITY_ONE / 1000))
                                    {
                                        MessageBox.Show($"❌ La huella ya está registrada para la boleta: {boletaExistente}");
                                        txtStatus.Text = "⚠️ Huella capturada ya registrada. \nIntenta de nuevo.";
                                        return;
                                    }
                                }
                                catch
                                {
                                    continue;
                                }
                            }
                        }
                    }

                    string insertQuery = @"INSERT INTO alumno 
            (Boleta, Nombre, A_Paterno, A_Materno, Telefono, Pswrd, HuellaAES, FormatoHuella)
            VALUES (@boleta, @nombre, @apaterno, @amaterno, @telefono, @password, @HuellaAES, @formato)";

                    using (var cmd = new MySqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@boleta", boleta);
                        cmd.Parameters.AddWithValue("@nombre", nombre);
                        cmd.Parameters.AddWithValue("@apaterno", apaterno);
                        cmd.Parameters.AddWithValue("@amaterno", amaterno);
                        cmd.Parameters.AddWithValue("@telefono", telefono);
                        cmd.Parameters.AddWithValue("@password", password);
                        cmd.Parameters.AddWithValue("@HuellaAES", huellaAES != null ? (object)huellaAES : DBNull.Value);
                        cmd.Parameters.AddWithValue("@formato", guardarHuella ? (object)formatoHuella : DBNull.Value);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Alumno registrado correctamente.");

                    this.DialogResult = DialogResult.OK;
                    this.Close();


                    // Enviar aviso de privacidad por WhatsApp
                    string urlPDF = "https://drive.google.com/uc?export=download&id=103KM82BaqpkWtbTQfoSgLGkngqJfX2kc";
                    string nombreArchivo = "Aviso_de_Privacidad.pdf";
                    string mensajeWhatsApp = "📄 Bienvenido a Gestión de Préstamos autenticado mediante huellas dactilares.\nAquí tienes tu aviso de privacidad. Consulta el archivo adjunto.";

                    await EnviarPDFWhatsAppUltraMsg(telefono, urlPDF, nombreArchivo, mensajeWhatsApp);
                }
            }

            LimpiarCampos();
            huellaCapturada = null;
        }

        private static string AesEncrypt(string plainText)
        {
            // Se crea un objeto AES
            using (Aes aes = Aes.Create())
            {
                //Obtener la clave y el vector de inicialización
                aes.Key = Key;
                aes.IV = IV;
                // Configurar el modo y el relleno
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                // Crear el objeto que hace el cifrado
                var encryptor = aes.CreateEncryptor();
                // Convertir el texto a bytes
                byte[] inputBytes = Encoding.UTF8.GetBytes(plainText);
                // Cifrar los bytes
                byte[] encryptedBytes = encryptor.TransformFinalBlock(inputBytes, 0, inputBytes.Length);
                // Convertir a Base64 y retornar
                return Convert.ToBase64String(encryptedBytes);
            }
        }
        public static string AesDecrypt(string cipherTextBase64)
        {
            //// Se crea un objeto AES
            using (Aes aes = Aes.Create())
            {
                // Asignar la clave y el IV
                aes.Key = Key;
                aes.IV = IV;
                // Configurar modo y relleno
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                // Crear el objeto para descifrar
                ICryptoTransform decryptor = aes.CreateDecryptor();
                // Convertir el texto base64 a bytes
                byte[] encryptedBytes = Convert.FromBase64String(cipherTextBase64);
                // Descifrar los bytes
                byte[] decrypted = decryptor.TransformFinalBlock(encryptedBytes, 0, encryptedBytes.Length);
                // Convertir los bytes descifrados a texto
                return Encoding.UTF8.GetString(decrypted);
            }
        }

        private void LimpiarCampos()
        {
            txtBoleta.Clear();
            txtNombre.Clear();
            txtAPaterno.Clear();
            txtAMaterno.Clear();
            txtTelefono.Clear();
            txtPassword.Clear();
            txtConfirmPassword.Clear();
        }

        private void RegistroUsuarios_FormClosed(object sender, FormClosedEventArgs e)
        {
            _sender?.CancelCaptureAndCloseReader(OnCaptured);
        }

        public class Encrypt
        {
            public static string GetSHA256(string str)
            {
                SHA256 sha256 = SHA256Managed.Create();
                ASCIIEncoding encoding = new ASCIIEncoding();
                byte[] stream = sha256.ComputeHash(encoding.GetBytes(str));
                StringBuilder sb = new StringBuilder();
                foreach (byte b in stream)
                    sb.AppendFormat("{0:x2}", b);
                return sb.ToString();
            }
        }

        private void SetPlaceholder(TextBox textbox, string placeholder)
        {
            textbox.ForeColor = Color.Gray;
            textbox.Text = placeholder;

            textbox.Enter += (s, e) => {
                if (textbox.Text == placeholder)
                {
                    textbox.Text = "";
                    textbox.ForeColor = Color.Black;
                }
            };

            textbox.Leave += (s, e) => {
                if (string.IsNullOrWhiteSpace(textbox.Text))
                {
                    textbox.Text = placeholder;
                    textbox.ForeColor = Color.Gray;
                }
            };
        }

        private void txtPassword_Enter(object sender, EventArgs e)
        {
            string mensaje = "La contraseña debe tener:\n" + "• Mínimo 8 caracteres\n" + "• Al menos un número\n" + "• Al menos un símbolo";
            toolTip1.ToolTipTitle = "Requisitos de la contraseña";
            toolTip1.ToolTipIcon = ToolTipIcon.Info;
            toolTip1.IsBalloon = true;

            int xOffset = txtPassword.Width + 10;
            int yOffset = -100;

            toolTip1.Show(mensaje, txtPassword, xOffset, yOffset, 5000);
        }

        private void txtPassword_Leave(object sender, EventArgs e)
        {
            toolTip1.Hide(txtPassword);
        }


        public async Task EnviarPDFWhatsAppUltraMsg(string telefono, string rutaPDF, string nombreArchivo, string mensaje)
        {
            string url = "https://api.ultramsg.com/instance122699/messages/document";
            var client = new RestSharp.RestClient(url);

            var request = new RestSharp.RestRequest(url, Method.Post);
            request.AddHeader("content-type", "application/x-www-form-urlencoded");

            request.AddParameter("token", "pwgq2ev3zmoe7aao");
            request.AddParameter("to", "+52" + telefono);
            request.AddParameter("filename", nombreArchivo);
            request.AddParameter("document", rutaPDF); // Enlace público directo
            request.AddParameter("caption", mensaje);

            RestResponse response = await client.ExecuteAsync(request);
            if (response.IsSuccessful)
            {
                MessageBox.Show("✅ Aviso de privacidad enviado por WhatsApp.");
            }
            else
            {
                MessageBox.Show("❌ Error al enviar PDF: " + response.Content);
            }
        }

        private void chkHuella_CheckedChanged(object sender, EventArgs e)
        {
            if (chkHuella.Checked)
            {
                txtStatus.Text = "📲 Por favor, captura la huella del alumno.";
            }
            else
            {
                txtStatus.Text = "🔒 El registro se hará sin huella.";
            }
        }

    }
}
