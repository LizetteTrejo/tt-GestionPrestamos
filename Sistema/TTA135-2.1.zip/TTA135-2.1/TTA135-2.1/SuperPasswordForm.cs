﻿using System;
using System.Windows.Forms;
using System.Drawing;

namespace UareUSampleCSharp
{
    public partial class SuperPasswordForm : Form
    {
        public string EnteredPassword => txtPassword.Text;

        public SuperPasswordForm()
        {
            InitializeComponent();
            this.Load += SuperPasswordForm_Load;

        }
        public bool DesdeRoot { get; set; }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();

        }
        private void SuperPasswordForm_Load(object sender, EventArgs e)
        {
            lblMessage.Text = "Contraseña Administrador";

            if (DesdeRoot)
            {
                lblMessage.Text = "🔐 Ingresa la contraseña de superusuario:";
                txtId.Visible = false; // o txtIdAdmin.Enabled = false;
                lblid.Visible = false;
            }
        }

        private void SuperPasswordForm_Load_1(object sender, EventArgs e)
        {

        }
    }
}
