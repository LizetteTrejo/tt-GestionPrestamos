﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
using MySql.Data.MySqlClient;
using LectorPrueba.MySQL;

using static UareUSampleCSharp.RegistroUsuarios;


namespace UareUSampleCSharp
{
    public partial class VerificationContra : Form

    {
        public string Boleta { get; private set; }
        public string NombreCompleto { get; private set; }

        private Conexion conexionBD = new Conexion();

        public VerificationContra(string boleta)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            txtBoleta.Text = boleta;

        }


        private void btnVerifica_Click(object sender, EventArgs e)
        {
            string boleta = txtBoleta.Text.Trim();
            string contrasena = txtContra.Text.Trim();

            if (string.IsNullOrEmpty(boleta) || string.IsNullOrEmpty(contrasena))
            {
                MessageBox.Show("📘 Ingresa tu boleta y contraseña.", "Campos vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string hash = Encrypt.GetSHA256(contrasena);

            using (var conn = conexionBD.Conectar())
            {
                string query = "SELECT Nombre, A_Paterno, A_Materno FROM alumno WHERE Boleta = @boleta AND Pswrd = @hash";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@boleta", boleta);
                    cmd.Parameters.AddWithValue("@hash", hash);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string nombre = reader["Nombre"].ToString();
                            string apaterno = reader["A_Paterno"].ToString();
                            string amaterno = reader["A_Materno"].ToString();

                            Boleta = boleta;
                            NombreCompleto = $"{nombre} {apaterno} {amaterno}";

                            DialogResult = DialogResult.OK;
                            Close();
                        }
                        else
                        {
                            MessageBox.Show("❌ Contraseña incorrecta. Intenta nuevamente.", "Acceso denegado", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }


    }
}
